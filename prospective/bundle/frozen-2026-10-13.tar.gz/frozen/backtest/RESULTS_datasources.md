# Data-source backtest: fplcache + football-data.co.uk (local only, nothing pushed)

Window 2023/24 GW5 → 2025/26 GW38 (110 decision GWs, 107 with transfers). Paired per-GW uplift (variant − reference; for MAE/RMSE shown as reduction, so positive = better), 95% bootstrap over GWs (2000 draws), ★ = CI excludes 0. Decision layer = the real `recommend_transfers` with transfer limits/hits, from `backtest.simulate`. Models: **engine** = `baseline`, default captain; **C3** = `minutes_v2` + price/position (b0) captain; **C1** = Vector's `vec_xg2` (GBM xG + P(play)×pts|play) + b0 captain. C1 data-source variants (`ds_backtest.py`, `VectorGBMPlus`) only append columns to Vector's feature matrix; same GBMs, hyper-parameters, retrain-every-4 cadence and t<test training rows.

## Headline table

| test | vs engine: XI pts/GW | vs C1: XI pts/GW | vs C1: captain pts/GW | vs C1: MAE reduction | verdict |
|---|---|---|---|---|---|
| Lookahead removal: deadline price + ownership only | engine +0.00, C3 +0.00 | +0.00 | +0.00 | 0.000 | **no lookahead found**: archive prices = deadline prices for 100% of rows; ownership only feeds the template metric |
| Deadline availability (status/chance_of_playing → start prob & xP scaling) | **+4.56 [+2.35, +6.66]★** (C3 +4.42★) | **+2.99 [+1.13, +4.77]★** | +0.19 [−0.52, +0.95] | +0.08★ | a real, large gain. This is new information, not leakage removal (the old 1.0 start prob was optimistic, not leaky) |
| fplcache as C1 features (avail, flagged, pen #1, set-piece taker, ownership %, Δprice) on the L1 base | +4.66 [+1.18, +8.05]★ | −0.46 [−3.31, +2.57] | +0.89 [−0.09, +1.84] | −0.03★ (worse) | no gain over C1 + availability scaling |
| football-data.co.uk odds as C1 features (implied GF/GA, CS prob) on the L1 base | **+6.09 [+2.37, +9.66]★** | +0.96 [−2.25, +4.47] | +0.95 [−0.17, +2.04] | 0.00 | best absolute (54.7 XI/GW), but the uplift over C1 L1 is not significant |

"L1" = deadline-realistic base (snapshot ownership + availability scaling), and every Step 2 row is scored on it. Absolute XI pts/GW: engine 44.08 → 48.65 L1, C3 47.10 → 51.52, C1 50.78 → 53.77, C1+odds 54.74, C1+fplcache 53.31.

**Recommendation:** adopt the fplcache deadline availability in the backtest and live parity checks (it changes the baseline by about +3 to +4.5 XI pts/GW, so earlier uplift numbers were measured on an over-optimistic base). Keep the odds features as a shadow candidate: they are directionally positive on captain and transfer gain in all 3 seasons, but not significant over C1. Drop the fplcache feature set beyond availability.

## Source checks
- **fplcache** (github.com/Randdalf/fplcache): the code licence is The Unlicense (public domain). The cached JSON is FPL's own bootstrap-static data, so FPL's terms govern any production use; backtest use is fine. Coverage runs from 2021-04 to 2026-10, with snapshots 4×/day (cron 00/06/12/18 UTC; filename = runner UTC time). For each GW I took the latest snapshot before (first kickoff − 90 min), then **asserted snapshot time < that snapshot's own `events[gw].deadline_time` and that the event was not finished**. 114/114 GWs passed. Staleness before the deadline: median 4.4 h, max 6.2 h. 99.5% of archive player-GW rows matched a snapshot `code`.
- **football-data.co.uk** E0 2023/24 to 2025/26: only pre-closing `AvgH/AvgD/AvgA` and `Avg>2.5/Avg<2.5` are used (closing columns are never read). Per notes.txt, "Betting odds for weekend games are collected Friday afternoons, and on Tuesday afternoons for midweek games." **Rule:** assumed collection time = 18:00 Europe/London on the Friday (Fri–Mon fixtures) or Tuesday (Tue–Thu fixtures) on or before the match. A fixture is dropped unless that time is strictly before the GW's real FPL deadline. This kept 976 and dropped 164 of 1,140 fixtures (68 / 49 / 47 by season; list in `fdcouk/dropped.csv`). Dropped fixtures get NaN features, and the GBM handles the missingness natively. Implied λ_home/λ_away come from a Poisson least-squares fit to de-margined P(H), P(A), P(>2.5). CS prob = exp(−λ_opp), summed over a DGW.

## Caveats (incl. selection bias)
- The 18:00 collection assumption is a judgement call. "Afternoon" could run past a Friday 18:30 UK deadline only if collection happened after 18:30, which the rule doesn't guard against. A stricter end-of-day rule would drop most Friday-deadline GWs.
- Odds are missing not at random: dropped fixtures are mostly midweek games or GWs whose deadline precedes the Tuesday collection. So odds features are absent exactly in congested GWs. Uplift is measured on all GWs, but the features only act on about 86% of fixtures.
- Availability scaling uses the repo's `status_multiplier` (d = 0.5, i/s/u/n = 0) or chance_of_playing/100, applied to xP, the b0 captain score and start_probability. The start-probability XI floor stays disabled, as in all prior harness runs. In the "fplcache features" variant the GBM sees `avail` directly. The no-scaling version is the headline; the xP×avail double-discount version is worse (−2.25 XI vs C1 L1, 2024/25 −7.2★).
- Snapshots are up to 6 h stale, so late team-news flags are missed. That is realistic for a fixed-schedule pipeline but understates a manager who checks at the deadline.
- Player universe = players with an archive row in the GW (incl. 0-minute rows). Players never registered in the archive are absent from both arms, so the comparison is paired and unbiased, but the absolute levels are not live-comparable.
- C1 still takes far more hits (−96 to −136 total) than the engine (0 / −20). The XI metric already nets these out, but the variance is high: per-season CIs overlap 0 in most cells.
- Reproduction: engine and C1 L0 exactly reproduce the earlier caches (44.08 / 50.78). C3 L0 came out at 47.10 vs 47.29 previously, from re-running the decision layer on the same cache (likely the grandfathering path added since). L1 comparisons are paired against the fresh L0 runs.
- Step 2 retrains C1 only. The engine (`ComponentPredictor`) has no hook for new features, so each "vs engine" row compares a C1 variant against the engine L1.

## Files
`fetch_fplcache.py`, `snap_table.py`, `ds_features.py`, `ds_backtest.py`, `ds_compare.py`; data in `fplcache/` and `fdcouk/`; caches `cache_c1_fc.parquet` and `cache_c1_odds.parquet`; decisions `decisions_L{0,1,1o,1s}_*.csv`. Full tables follow.

## Absolute levels

| run | XI pts/GW | captain pts/GW | net transfer gain/GW | MAE | RMSE | hit pts total |
|---|---|---|---|---|---|---|
| engine L0 | 44.08 | 4.66 | 1.37 | 1.119 | 2.108 | 0 |
| C3 L0 | 47.10 | 6.84 | 1.44 | 1.072 | 2.092 | 0 |
| C1 L0 | 50.78 | 6.19 | 2.32 | 1.010 | 1.990 | -96 |
| engine L1o | 44.08 | 4.66 | 1.37 | 1.119 | 2.108 | 0 |
| C3 L1o | 47.10 | 6.84 | 1.44 | 1.072 | 2.092 | 0 |
| C1 L1o | 50.78 | 6.19 | 2.32 | 1.010 | 1.990 | -96 |
| engine L1 | 48.65 | 4.68 | 2.20 | 0.943 | 2.046 | -20 |
| C3 L1 | 51.52 | 7.00 | 2.08 | 0.926 | 2.052 | -16 |
| C1 L1 | 53.77 | 6.38 | 3.08 | 0.931 | 1.953 | -120 |
| C1+fplcache feats (L1) | 53.31 | 7.27 | 3.29 | 0.966 | 1.951 | -96 |
| C1+fplcache feats, xP also ×avail (L1) | 51.52 | 6.85 | 3.36 | 0.956 | 1.947 | -104 |
| C1+odds feats (L1) | 54.74 | 7.33 | 3.87 | 0.928 | 1.949 | -136 |

### Step 1: lookahead removal (L1 − L0)

| variant | vs | MAE↓ | RMSE↓ | MAE 0 | MAE 1-2 | MAE 3-4 | MAE 5+ | captain pts/GW | XI pts incl C & hits | net transfer gain |
|---|---|---|---|---|---|---|---|---|---|---|
| ownership/price → deadline snapshot | engine L0 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C3 L0 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C1 L0 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| + deadline availability (full L1) | engine L0 | +0.18 [+0.17, +0.18]★ | +0.06 [+0.06, +0.07]★ | +0.28 [+0.27, +0.29]★ | +0.00 [+0.00, +0.01]★ | -0.01 [-0.02, -0.01]★ | -0.02 [-0.02, -0.02]★ | +0.02 [-0.61, +0.57] | +4.56 [+2.35, +6.66]★ | +0.82 [-0.09, +1.82] |
| + deadline availability (full L1) | C3 L0 | +0.15 [+0.14, +0.15]★ | +0.04 [+0.04, +0.04]★ | +0.24 [+0.23, +0.24]★ | -0.00 [-0.00, +0.00] | -0.01 [-0.02, -0.01]★ | -0.02 [-0.02, -0.01]★ | +0.16 [-0.35, +0.65] | +4.42 [+2.26, +6.57]★ | +0.64 [-0.13, +1.49] |
| + deadline availability (full L1) | C1 L0 | +0.08 [+0.07, +0.08]★ | +0.04 [+0.03, +0.04]★ | +0.13 [+0.12, +0.14]★ | +0.01 [+0.00, +0.01]★ | -0.01 [-0.01, -0.00]★ | -0.02 [-0.02, -0.02]★ | +0.19 [-0.52, +0.95] | +2.99 [+1.13, +4.77]★ | +0.77 [-0.30, +1.88] |

Per-season (XI pts, captain pts, MAE reduction):

| variant | vs | season | XI | captain | MAE↓ |
|---|---|---|---|---|---|
| ownership/price → deadline snapshot | engine L0 | 2023/24 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | engine L0 | 2024/25 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | engine L0 | 2025/26 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C3 L0 | 2023/24 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C3 L0 | 2024/25 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C3 L0 | 2025/26 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C1 L0 | 2023/24 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C1 L0 | 2024/25 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| ownership/price → deadline snapshot | C1 L0 | 2025/26 | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| + deadline availability (full L1) | engine L0 | 2023/24 | +0.76 [-3.26, +4.77] | +0.00 [-0.74, +0.79] | +0.15 [+0.14, +0.15]★ |
| + deadline availability (full L1) | engine L0 | 2024/25 | +3.11 [-0.45, +6.50] | -0.66 [-2.05, +0.37] | +0.17 [+0.16, +0.18]★ |
| + deadline availability (full L1) | engine L0 | 2025/26 | +9.42 [+6.16, +12.95]★ | +0.71 [-0.11, +1.58] | +0.21 [+0.20, +0.22]★ |
| + deadline availability (full L1) | C3 L0 | 2023/24 | +5.06 [+1.15, +9.26]★ | +0.91 [-0.41, +2.12] | +0.13 [+0.12, +0.13]★ |
| + deadline availability (full L1) | C3 L0 | 2024/25 | +3.74 [-0.47, +7.79] | -0.34 [-1.03, +0.05] | +0.14 [+0.14, +0.15]★ |
| + deadline availability (full L1) | C3 L0 | 2025/26 | +4.53 [+1.45, +7.82]★ | +0.00 [-0.71, +0.61] | +0.17 [+0.16, +0.17]★ |
| + deadline availability (full L1) | C1 L0 | 2023/24 | +2.97 [-0.09, +6.32] | +0.35 [-0.68, +1.44] | +0.09 [+0.08, +0.09]★ |
| + deadline availability (full L1) | C1 L0 | 2024/25 | +5.24 [+2.74, +7.82]★ | +0.79 [-0.05, +2.08] | +0.08 [+0.07, +0.08]★ |
| + deadline availability (full L1) | C1 L0 | 2025/26 | +0.76 [-2.87, +4.37] | -0.55 [-1.97, +0.97] | +0.07 [+0.07, +0.08]★ |

### Step 2: data sources as features (both on the L1 deadline-realistic base)

| variant | vs | MAE↓ | RMSE↓ | MAE 0 | MAE 1-2 | MAE 3-4 | MAE 5+ | captain pts/GW | XI pts incl C & hits | net transfer gain |
|---|---|---|---|---|---|---|---|---|---|---|
| C1+fplcache feats | engine L1 | -0.02 [-0.03, -0.01]★ | +0.09 [+0.08, +0.11]★ | -0.01 [-0.02, -0.00]★ | -0.47 [-0.49, -0.44]★ | +0.27 [+0.22, +0.31]★ | +1.04 [+0.99, +1.08]★ | +2.59 [+1.45, +3.82]★ | +4.66 [+1.18, +8.05]★ | +1.09 [-0.22, +2.38] |
| C1+fplcache feats | C1 L1 | -0.03 [-0.04, -0.03]★ | +0.00 [-0.00, +0.01] | -0.06 [-0.06, -0.05]★ | -0.07 [-0.08, -0.06]★ | +0.08 [+0.06, +0.09]★ | +0.17 [+0.15, +0.19]★ | +0.89 [-0.09, +1.84] | -0.46 [-3.31, +2.57] | +0.21 [-0.99, +1.51] |
| C1+fplcache feats (xP×avail) | engine L1 | -0.01 [-0.02, -0.00]★ | +0.10 [+0.08, +0.11]★ | +0.00 [-0.01, +0.01] | -0.46 [-0.48, -0.44]★ | +0.26 [+0.21, +0.31]★ | +1.02 [+0.97, +1.06]★ | +2.17 [+0.88, +3.47]★ | +2.87 [-0.95, +6.58] | +1.17 [-0.11, +2.62] |
| C1+fplcache feats (xP×avail) | C1 L1 | -0.02 [-0.03, -0.02]★ | +0.01 [+0.00, +0.01]★ | -0.04 [-0.05, -0.04]★ | -0.06 [-0.07, -0.05]★ | +0.07 [+0.05, +0.09]★ | +0.15 [+0.13, +0.17]★ | +0.47 [-0.35, +1.35] | -2.25 [-5.15, +0.52] | +0.28 [-1.07, +1.67] |
| C1+odds feats | engine L1 | +0.02 [+0.00, +0.03]★ | +0.10 [+0.08, +0.11]★ | +0.05 [+0.04, +0.06]★ | -0.40 [-0.42, -0.37]★ | +0.18 [+0.14, +0.23]★ | +0.88 [+0.81, +0.93]★ | +2.65 [+1.46, +3.85]★ | +6.09 [+2.37, +9.66]★ | +1.67 [+0.21, +3.12]★ |
| C1+odds feats | C1 L1 | +0.00 [-0.00, +0.01] | +0.00 [-0.00, +0.01] | +0.00 [+0.00, +0.01]★ | +0.00 [-0.01, +0.01] | -0.01 [-0.03, +0.01] | +0.01 [-0.01, +0.03] | +0.95 [-0.17, +2.04] | +0.96 [-2.25, +4.47] | +0.79 [-0.70, +2.31] |

Per-season (XI pts, captain pts, MAE reduction):

| variant | vs | season | XI | captain | MAE↓ |
|---|---|---|---|---|---|
| C1+fplcache feats | engine L1 | 2023/24 | +5.00 [-0.74, +10.85] | +3.18 [+0.68, +5.53]★ | -0.08 [-0.09, -0.07]★ |
| C1+fplcache feats | engine L1 | 2024/25 | +6.32 [+0.10, +12.63]★ | +3.63 [+1.68, +5.82]★ | -0.02 [-0.04, -0.01]★ |
| C1+fplcache feats | engine L1 | 2025/26 | +2.71 [-2.24, +7.53] | +1.03 [-0.47, +2.32] | +0.03 [+0.02, +0.04]★ |
| C1+fplcache feats | C1 L1 | 2023/24 | +2.18 [-2.29, +6.82] | +1.62 [+0.12, +3.21]★ | -0.04 [-0.04, -0.03]★ |
| C1+fplcache feats | C1 L1 | 2024/25 | -2.18 [-7.66, +3.95] | +1.00 [-0.95, +3.21] | -0.04 [-0.04, -0.03]★ |
| C1+fplcache feats | C1 L1 | 2025/26 | -1.11 [-5.68, +3.40] | +0.13 [-1.13, +1.26] | -0.03 [-0.03, -0.02]★ |
| C1+fplcache feats (xP×avail) | engine L1 | 2023/24 | +4.56 [-2.97, +11.85] | +3.47 [+0.82, +5.79]★ | -0.07 [-0.08, -0.05]★ |
| C1+fplcache feats (xP×avail) | engine L1 | 2024/25 | +1.34 [-5.55, +8.39] | +2.16 [-0.68, +4.82] | -0.01 [-0.03, -0.00]★ |
| C1+fplcache feats (xP×avail) | engine L1 | 2025/26 | +2.89 [-1.71, +7.63] | +1.03 [-0.42, +2.53] | +0.04 [+0.03, +0.05]★ |
| C1+fplcache feats (xP×avail) | C1 L1 | 2023/24 | +1.74 [-3.53, +6.82] | +1.91 [+0.21, +3.68]★ | -0.02 [-0.03, -0.02]★ |
| C1+fplcache feats (xP×avail) | C1 L1 | 2024/25 | -7.16 [-11.55, -2.95]★ | -0.47 [-1.89, +0.76] | -0.03 [-0.03, -0.02]★ |
| C1+fplcache feats (xP×avail) | C1 L1 | 2025/26 | -0.92 [-5.58, +3.55] | +0.13 [-1.08, +1.32] | -0.02 [-0.03, -0.02]★ |
| C1+odds feats | engine L1 | 2023/24 | +2.79 [-5.44, +10.68] | +2.76 [-0.06, +5.24] | -0.04 [-0.05, -0.02]★ |
| C1+odds feats | engine L1 | 2024/25 | +10.87 [+4.68, +16.97]★ | +3.95 [+1.87, +6.26]★ | +0.02 [+0.01, +0.03]★ |
| C1+odds feats | engine L1 | 2025/26 | +4.26 [-0.47, +8.66] | +1.24 [-0.13, +2.61] | +0.06 [+0.04, +0.07]★ |
| C1+odds feats | C1 L1 | 2023/24 | -0.03 [-6.38, +6.80] | +1.21 [-0.91, +3.32] | +0.01 [-0.00, +0.01] |
| C1+odds feats | C1 L1 | 2024/25 | +2.37 [-3.00, +8.61] | +1.32 [-0.45, +3.21] | +0.01 [+0.00, +0.01]★ |
| C1+odds feats | C1 L1 | 2025/26 | +0.45 [-4.45, +4.87] | +0.34 [-1.50, +2.13] | -0.00 [-0.01, +0.00] |
