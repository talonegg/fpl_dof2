# Round 3: odds-driven team layer (local review only, branch forge/odds-team-layer)

**Verdict: no winner.** No setup is significant overall at 95% *and* non-negative in every season, and
none survives Holm. Odds are clearly the better *team* forecaster (T2), but swapping them in as the
team layer does not turn into XI points; on the champion it is significantly **worse** (−2.52/GW,
unadjusted p=0.04, Holm 0.21). Keep the champion and C1 as they are; keep odds as a logged shadow input.

## Setup
* Harness: availability-aware walk-forward (deadline availability from fplcache applied first), 110 GWs
  2023/24–2025/26, the real transfer engine, price+position (C3/b0) captain, `round2.simulate`
  (no club-cap workaround; 0 infeasible GWs in every run). Paired per GW vs the same harness's base
  runs (`champ__base`, `chall__base`, `comp__base` from round 2). 95% GW-bootstrap CIs (2000 draws);
  p = two-sided bootstrap p on XI pts; Holm across the 5 comparisons of this round.
* Odds (`odds_team.py`): football-data.co.uk **pre-closing** columns only — Pinnacle PSH/PSD/PSA and
  P>2.5/P<2.5 preferred, market Avg fallback (PSC*/AvgC* never read). 1X2 de-vig by Shin (z solved;
  power fallback, never needed: 976/976 Shin); O/U proportional. Overround logged (mean 1X2 3.5–4.7%,
  O/U 3.7–4.8%). λ_home, λ_away: independent Poisson, least squares on P(H),P(D),P(A),P(>2.5),
  λ∈[0.2,4]. 1X2-only fallback with total fixed to the league-season prior is implemented but never
  triggered (every kept fixture had O/U).
* Collection-time rule unchanged: weekend odds assumed Fri 18:00 London, midweek Tue 18:00; dropped if
  not strictly before the GW deadline → the model's own team estimate is used.
* Arms
  * **Champion + odds**: `xp_v1.fixture_opposition` (and `horizon`'s import) patched in-process:
    CS = exp(−λ_opp), goals-conceded mean = λ_opp, attacking fixture factor = λ_team /
    (league_mean × attack(team)) clipped [0.3,3]; engine's team-strength opposition when no odds.
  * **C1 + odds**: `xgf_r, xga_r, opp_xgf_r, opp_xga_r` REPLACED by implied per-fixture goals for/against
    (train and test rows) where all of the team-GW's fixtures have odds; else original features.
  * **A + odds** (Vector's spec): CS = exp(−λ_opp); −E[floor(GC/2)] under Poisson(λ_opp) for GKP/DEF;
    player goals = λ_team × last-6-GW xG share (per 90 played, shrunk k=3 to a position×price-band prior
    fitted on prior GWs) × P(play); assists = λ_team × xA share × 0.75; GK saves ~ Poisson(λ_opp ×
    (SoT/goal − 1)) from prior-fixture league SoT/goal, scored E[floor(S/3)]; bonus, DC, P(play), P(60)
    as A. DGW summed per fixture; blank = 0. Team-GW not fully covered → A's own prediction.

## Results (paired uplift, candidate − reference; MAE/RMSE as reduction so + = better; ★ = CI excludes 0)

| candidate | vs | XI pts/GW | captain pts/GW | MAE↓ | RMSE↓ | abs XI | hit pts | p (boot) | p Holm | winner? |
|---|---|---|---|---|---|---|---|---|---|---|
| Champion + odds team layer | champion | -2.52 [-4.97, -0.28]★ | -0.71 [-1.66, +0.19] | +0.00 [+0.00, +0.01]★ | +0.00 [-0.00, +0.00] | 49.00 | -16 | 0.042 | 0.208 | no |
| C1 + odds team layer (team xG features replaced) | challenger | +0.84 [-2.42, +4.04] | +0.81 [-0.14, +1.62] | +0.00 [-0.00, +0.01] | -0.00 [-0.01, +0.01] | 54.61 | -148 | 0.612 | 1.000 | no |
| A + odds team layer | A | -1.45 [-4.65, +1.55] | +0.65 [-0.21, +1.58] | -0.05 [-0.06, -0.05]★ | +0.00 [-0.01, +0.01] | 52.62 | -128 | 0.355 | 1.000 | no |
| A + odds team layer | champion | +1.10 [-2.20, +4.23] | +0.83 [-0.13, +1.83] | -0.03 [-0.04, -0.02]★ | +0.13 [+0.12, +0.15]★ | 52.62 | -128 | 0.504 | 1.000 | no |
| A + odds team layer | challenger | -1.15 [-4.68, +2.34] | +1.45 [+0.24, +2.65]★ | -0.02 [-0.03, -0.02]★ | +0.03 [+0.02, +0.04]★ | 52.62 | -128 | 0.512 | 1.000 | no |

### Per season (XI pts / captain pts / MAE↓, paired uplift)

| candidate | vs | season | XI | captain | MAE↓ |
|---|---|---|---|---|---|
| Champion + odds team layer | champion | 2023/24 | -1.32 [-3.91, +1.24] | -0.18 [-1.00, +0.74] | +0.00 [+0.00, +0.01]★ |
| Champion + odds team layer | champion | 2024/25 | -5.76 [-10.26, -1.55]★ | -0.95 [-3.00, +0.58] | +0.00 [+0.00, +0.01]★ |
| Champion + odds team layer | champion | 2025/26 | -0.34 [-4.95, +4.16] | -0.95 [-2.92, +0.79] | +0.00 [+0.00, +0.01]★ |
| C1 + odds team layer (team xG features replaced) | challenger | 2023/24 | -0.56 [-7.38, +6.29] | +0.68 [-1.00, +2.47] | +0.00 [-0.00, +0.01] |
| C1 + odds team layer (team xG features replaced) | challenger | 2024/25 | +0.66 [-4.40, +5.74] | +0.63 [+0.00, +1.42] | -0.00 [-0.01, +0.01] |
| C1 + odds team layer (team xG features replaced) | challenger | 2025/26 | +2.26 [-3.39, +8.03] | +1.11 [-0.71, +2.92] | +0.00 [-0.00, +0.01] |
| A + odds team layer | A | 2023/24 | +0.18 [-5.29, +5.03] | +1.79 [+0.24, +3.50]★ | -0.06 [-0.07, -0.05]★ |
| A + odds team layer | A | 2024/25 | -5.00 [-10.32, +0.08] | -0.37 [-1.58, +0.89] | -0.06 [-0.07, -0.05]★ |
| A + odds team layer | A | 2025/26 | +0.63 [-4.21, +5.50] | +0.66 [-1.08, +2.39] | -0.04 [-0.05, -0.04]★ |
| A + odds team layer | champion | 2023/24 | -1.85 [-7.15, +3.71] | +0.91 [+0.03, +2.03]★ | -0.05 [-0.06, -0.03]★ |
| A + odds team layer | champion | 2024/25 | -0.55 [-5.74, +5.13] | +1.08 [-0.45, +2.71] | -0.05 [-0.06, -0.03]★ |
| A + odds team layer | champion | 2025/26 | +5.39 [-0.74, +11.13] | +0.50 [-1.63, +2.53] | +0.00 [-0.01, +0.02] |
| A + odds team layer | challenger | 2023/24 | -0.21 [-5.82, +5.00] | +1.97 [+0.21, +3.74]★ | +0.00 [-0.01, +0.02] |
| A + odds team layer | challenger | 2024/25 | -5.26 [-11.79, +1.76] | +1.00 [-1.18, +3.37] | -0.04 [-0.05, -0.03]★ |
| A + odds team layer | challenger | 2025/26 | +2.11 [-3.05, +7.47] | +1.42 [-0.61, +3.42] | -0.04 [-0.04, -0.03]★ |

### Error by actual-points bucket (reduction; + = better)

| candidate | vs | MAE 0 | MAE 1-2 | MAE 3-4 | MAE 5+ | RMSE 0 | RMSE 1-2 | RMSE 3-4 | RMSE 5+ |
|---|---|---|---|---|---|---|---|---|---|
| Champion + odds team layer | champion | +0.00 [+0.00, +0.00]★ | +0.01 [+0.01, +0.02]★ | +0.00 [-0.00, +0.01] | -0.01 [-0.02, -0.00]★ | +0.01 [+0.00, +0.01]★ | +0.02 [+0.02, +0.03]★ | +0.00 [-0.00, +0.01] | -0.01 [-0.02, -0.00]★ |
| C1 + odds team layer (team xG features replaced) | challenger | +0.00 [-0.00, +0.00] | +0.01 [+0.00, +0.02]★ | +0.00 [-0.02, +0.02] | -0.03 [-0.05, +0.00] | +0.00 [-0.00, +0.01] | +0.01 [-0.00, +0.03] | -0.01 [-0.03, +0.01] | -0.02 [-0.04, +0.01] |
| A + odds team layer | A | -0.05 [-0.05, -0.04]★ | -0.24 [-0.27, -0.22]★ | +0.07 [+0.04, +0.10]★ | +0.38 [+0.34, +0.42]★ | -0.11 [-0.12, -0.10]★ | -0.28 [-0.31, -0.25]★ | +0.05 [+0.03, +0.08]★ | +0.33 [+0.29, +0.36]★ |
| A + odds team layer | champion | -0.03 [-0.04, -0.02]★ | -0.55 [-0.58, -0.52]★ | +0.45 [+0.38, +0.50]★ | +1.21 [+1.15, +1.27]★ | -0.20 [-0.22, -0.19]★ | -0.67 [-0.71, -0.63]★ | +0.34 [+0.27, +0.40]★ | +1.07 [+1.01, +1.13]★ |
| A + odds team layer | challenger | -0.05 [-0.05, -0.04]★ | -0.11 [-0.14, -0.08]★ | +0.18 [+0.15, +0.22]★ | +0.25 [+0.20, +0.30]★ | -0.08 [-0.10, -0.06]★ | -0.07 [-0.11, -0.03]★ | +0.14 [+0.10, +0.18]★ | +0.25 [+0.21, +0.30]★ |

### Absolute levels

| run | XI | captain | MAE | RMSE | hit pts | GWs |
|---|---|---|---|---|---|---|
| champ__base | 51.52 | 7.00 | 0.926 | 2.052 | -16 | 110 |
| chall__base | 53.77 | 6.38 | 0.931 | 1.953 | -120 | 110 |
| comp__base | 54.07 | 7.17 | 0.903 | 1.920 | -104 | 110 |
| champ_ot__base | 49.00 | 6.29 | 0.923 | 2.049 | -16 | 110 |
| chall_ot__base | 54.61 | 7.19 | 0.930 | 1.954 | -148 | 110 |
| comp_ot__base | 52.62 | 7.83 | 0.956 | 1.920 | -128 | 110 |

### Coverage

```
         fixtures  with_odds  pinnacle_1x2  with_ou  shin  mean_overround_1x2  mean_overround_ou  bt_fixtures  bt_with_odds
season                                                                                                                     
2023/24       380        312           312      312   312              0.0346             0.0365          341           273
2024/25       380        331           331      331   331              0.0363             0.0372          380           331
2025/26       380        333           190      333   333              0.0468             0.0482          380           333
```

Team-GW coverage (all fixtures in that team's GW have pre-deadline odds) over the 110 decision GWs:
84.9% overall (2023/24 79.4%, 2024/25 86.9%, 2025/26 87.7%); fixture-level 937/1101 = 85.1%.
2025/26 Pinnacle pre-closing is present for 190/333 kept fixtures; the rest use the market average.

## T2: team forecast accuracy, odds layer vs current team model (lower = better)

Current team model = the xG-EWM team rates A and C1 use (λ_home = mean(home xGF rate, away xGA rate)).
Scored on the 946 kept fixtures with both available.

| season | fixtures | 1X2 Brier odds | 1X2 Brier model | 1X2 logloss odds | 1X2 logloss model | CS Brier odds | CS Brier model | CS logloss odds | CS logloss model |
|---|---|---|---|---|---|---|---|---|---|
| 2023/24 | 302 | 0.5322 | 0.5879 | 0.9073 | 0.9892 | 0.15 | 0.1541 | 0.4667 | 0.4827 |
| 2024/25 | 321 | 0.5971 | 0.6085 | 0.9971 | 1.0169 | 0.1738 | 0.1716 | 0.527 | 0.5228 |
| 2025/26 | 323 | 0.5989 | 0.6335 | 1.0013 | 1.0527 | 0.1746 | 0.1832 | 0.527 | 0.551 |
| all | 946 | 0.577 | 0.6104 | 0.9699 | 1.0203 | 0.1665 | 0.17 | 0.5077 | 0.5197 |

Odds win on 1X2 in every season and on CS in 2023/24 and 2025/26; CS is marginally worse in 2024/25.

## Multiple testing
This round: 5 comparisons (Holm above). Cumulative decision runs scored on these same 110 GWs:
about 36 in round 1 and data sources, 49 in round 2 (including the 16-run E grid), and 3 new here,
so about 88. Treat any single unadjusted ★ with that in mind.

## Caveats
* The champion swap goes through a monkey-patch of the engine's opposition function; the engine's
  team-strength fit itself is unchanged.
* The collection time is assumed (football-data.co.uk only says "Friday/Tuesday afternoon"). About 15%
  of fixtures fall back to the model's own team estimate.
* A+odds replaces A's learned goals/assists GBMs with share × λ. That raises MAE on 0–2-pt rows and
  lowers it on 3+ rows, so it spreads predictions out more. Its captain gain is consistent (+0.65 vs A,
  +1.45★ vs C1), but XI points are not.
* The SoT/goal saves mapping uses (ratio − 1), because saves = SoT − goals. Vector's text said ratio/3.
* Hit points went up for the odds C1 and A (−148 and −128 against −120 and −104).
* T2 compares team layers only; it does not compare the engine's own M2 ratings.

Code: `odds_team.py`, `ot_models.py`, `r3.py`, `r3_report.py`, `r3_t2.py`; artefacts in `r3/` and
`r2/dec_*_ot__base.csv`.
