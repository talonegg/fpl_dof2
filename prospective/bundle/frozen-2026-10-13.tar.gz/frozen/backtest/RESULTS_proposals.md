# Proposal re-scoring vs the fpl_dof2 engine baseline

Review-only. Engine baseline = fpl_dof2 `xp_v1` + `recommend_transfers` (see RESULTS_baseline.md). Every
variant is run through the same walk-forward folds, the same simulated squad rules (£100m, 1 FT, no chips) and the
same decision code; one change toggled at a time. Run: `python backtest/backtest.py --model <m> --policy <p>`, then
`compare.py`. Forecasts are cached per model (`cache_<m>.parquet`) so decision policies reuse identical predictions.

Paired per-GW uplift = sign × (variant − baseline); positive = better. 95% bootstrap CI over GWs (2000 draws). ★ = CI excludes 0. Seasons 2023/24 GW5 → 2025/26 GW38 (110 GWs; transfer gain 107 GWs).

## Key table (all seasons)

| variant | XI pts incl C & hits | captain pts | net transfer gain | xPts MAE all (↓ shown as reduction) | xPts MAE 60+ (reduction) |
|---|---|---|---|---|---|
| P1a vec_noxg (GBM, no xG) | +2.827 [-0.70, +6.22] | +0.409 [-0.85, +1.63] | +0.458 [-0.83, +1.80] | +0.095 [+0.08, +0.11]★ | -0.020 [-0.06, +0.02] |
| P1b vec_xg (boosted per-pos GBM +xG) | +4.436 [+0.84, +8.24]★ | +0.255 [-0.93, +1.43] | +0.458 [-0.78, +1.70] | +0.098 [+0.08, +0.12]★ | -0.018 [-0.06, +0.02] |
| P2a minutes_v2 (repo flag) | +1.591 [-0.08, +3.32] | +0.582 [+0.10, +1.12]★ | +0.252 [-0.79, +1.25] | +0.047 [+0.04, +0.05]★ | -0.028 [-0.03, -0.02]★ |
| P2b vec_xg2 (+xG, P(play)×pts|play) | +6.009 [+2.63, +9.38]★ | +0.836 [-0.55, +2.14] | +0.944 [-0.28, +2.20] | +0.109 [+0.09, +0.13]★ | -0.008 [-0.03, +0.02] |
| P3 team_strength_from_xg | -0.273 [-2.12, +1.75] | -0.300 [-1.10, +0.46] | +0.785 [-0.07, +1.72] | +0.004 [+0.00, +0.01]★ | +0.007 [+0.00, +0.01]★ |
| P4a captain MID/FWD by engine xPts | -0.245 [-0.77, +0.34] | -0.245 [-0.78, +0.32] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P4b captain = B0 (price+pos) on engine squad | +1.800 [+0.65, +2.96]★ | +1.800 [+0.68, +2.90]★ | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P5 calib + threshold t=0 | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P5 calib + threshold t=0.5 | -0.109 [-0.33, +0.00] | -0.055 [-0.16, +0.00] | +0.065 [-0.02, +0.22] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P5 calib + threshold t=1 | +0.382 [-0.85, +1.56] | -0.027 [-0.35, +0.28] | +0.187 [-0.73, +1.11] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P5 calib + threshold t=2 | -3.309 [-5.86, -0.44]★ | -0.473 [-1.36, +0.38] | -0.065 [-1.12, +0.94] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| P5 calib + threshold t=3 | -0.545 [-2.96, +1.80] | -0.300 [-1.31, +0.60] | +0.364 [-0.58, +1.36] | +0.000 [+0.00, +0.00] | +0.000 [+0.00, +0.00] |
| C1 vec_xg2 + B0 captain | +6.700 [+3.21, +9.96]★ | +1.527 [+0.17, +2.81]★ | +0.944 [-0.29, +2.07] | +0.109 [+0.09, +0.13]★ | -0.008 [-0.03, +0.02] |
| C2 vec_xg2 + B0 captain + calib t=1 | -7.436 [-11.31, -3.35]★ | +0.082 [-1.23, +1.41] | -1.383 [-2.34, -0.49]★ | +0.109 [+0.09, +0.13]★ | -0.008 [-0.03, +0.02] |
| C3 minutes_v2 + B0 captain | +3.209 [+1.08, +5.25]★ | +2.200 [+1.07, +3.32]★ | +0.252 [-0.80, +1.24] | +0.047 [+0.04, +0.05]★ | -0.028 [-0.03, -0.02]★ |
| C4 minutes_v2 + B0 captain + calib t=1 | +2.927 [+0.79, +5.24]★ | +1.736 [+0.65, +2.83]★ | +0.009 [-1.01, +0.96] | +0.047 [+0.04, +0.05]★ | -0.028 [-0.03, -0.02]★ |

## Per-season uplift (mean [95% CI])

### P1a vec_noxg (GBM, no xG)

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -1.94 [-8.65, +4.88] | +0.42 [-6.16, +6.76] | +9.50 [+5.29, +13.87]★ |
| captain pts | +0.32 [-2.18, +2.50] | -0.32 [-3.00, +2.18] | +1.21 [-0.16, +2.50] |
| net transfer gain | +0.48 [-1.64, +2.73] | -0.30 [-2.86, +2.05] | +1.19 [-0.92, +3.38] |
| xPts MAE all (↓ shown as reduction) | -0.01 [-0.03, +0.01] | +0.10 [+0.08, +0.12]★ | +0.18 [+0.17, +0.20]★ |
| xPts MAE 60+ (reduction) | -0.13 [-0.17, -0.10]★ | -0.01 [-0.09, +0.05] | +0.07 [-0.02, +0.12] |

### P1b vec_xg (boosted per-pos GBM +xG)

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -1.09 [-7.74, +6.12] | +2.32 [-3.71, +8.37] | +11.50 [+6.00, +17.45]★ |
| captain pts | +0.41 [-1.65, +2.29] | -0.63 [-3.24, +1.82] | +1.00 [-0.45, +2.50] |
| net transfer gain | +0.61 [-1.94, +3.24] | +0.19 [-1.97, +2.35] | +0.59 [-1.24, +2.46] |
| xPts MAE all (↓ shown as reduction) | -0.01 [-0.03, +0.01] | +0.10 [+0.09, +0.12]★ | +0.19 [+0.17, +0.21]★ |
| xPts MAE 60+ (reduction) | -0.12 [-0.15, -0.09]★ | -0.01 [-0.09, +0.05] | +0.07 [-0.01, +0.12] |

### P2a minutes_v2 (repo flag)

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -1.26 [-3.53, +0.97] | +1.79 [-1.34, +5.13] | +3.95 [+1.18, +6.74]★ |
| captain pts | +0.26 [-0.26, +0.85] | +0.87 [+0.08, +1.95]★ | +0.58 [-0.45, +1.50] |
| net transfer gain | +0.09 [-1.15, +1.30] | -0.30 [-2.08, +1.16] | +0.95 [-1.14, +3.11] |
| xPts MAE all (↓ shown as reduction) | +0.03 [+0.02, +0.03]★ | +0.05 [+0.05, +0.05]★ | +0.06 [+0.06, +0.07]★ |
| xPts MAE 60+ (reduction) | -0.03 [-0.03, -0.02]★ | -0.02 [-0.03, -0.02]★ | -0.04 [-0.04, -0.03]★ |

### P2b vec_xg2 (+xG, P(play)×pts|play)

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +0.44 [-6.03, +6.59] | +5.26 [-0.71, +11.61] | +11.74 [+7.18, +16.45]★ |
| captain pts | +1.03 [-1.15, +2.97] | +0.08 [-3.03, +2.97] | +1.42 [-0.18, +2.92] |
| net transfer gain | +0.67 [-1.61, +2.97] | -0.16 [-2.24, +1.95] | +2.30 [+0.51, +4.05]★ |
| xPts MAE all (↓ shown as reduction) | +0.02 [-0.00, +0.03] | +0.11 [+0.09, +0.12]★ | +0.19 [+0.17, +0.21]★ |
| xPts MAE 60+ (reduction) | -0.12 [-0.15, -0.09]★ | -0.01 [-0.05, +0.03] | +0.09 [+0.06, +0.12]★ |

### P3 team_strength_from_xg

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -0.82 [-5.03, +3.65] | -0.63 [-4.16, +2.61] | +0.58 [-1.55, +2.76] |
| captain pts | +0.12 [-2.15, +2.18] | -0.76 [-1.92, +0.16] | -0.21 [-0.63, +0.00] |
| net transfer gain | +2.06 [+0.52, +3.70]★ | -0.19 [-1.78, +1.84] | +0.62 [-0.51, +1.76] |
| xPts MAE all (↓ shown as reduction) | +0.01 [+0.00, +0.01]★ | +0.00 [+0.00, +0.00]★ | +0.00 [+0.00, +0.01]★ |
| xPts MAE 60+ (reduction) | +0.01 [-0.00, +0.02] | +0.01 [-0.00, +0.01] | +0.01 [+0.00, +0.01]★ |

### P4a captain MID/FWD by engine xPts

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +0.21 [-0.88, +1.38] | -0.47 [-1.24, -0.03]★ | -0.42 [-1.34, +0.61] |
| captain pts | +0.21 [-0.88, +1.38] | -0.47 [-1.24, -0.03]★ | -0.42 [-1.34, +0.58] |
| net transfer gain | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P4b captain = B0 (price+pos) on engine squad

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +1.38 [-1.09, +3.56] | +2.24 [+0.50, +4.24]★ | +1.74 [-0.08, +3.66] |
| captain pts | +1.38 [-1.09, +3.56] | +2.24 [+0.55, +4.21]★ | +1.74 [-0.18, +3.71] |
| net transfer gain | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P5 calib + threshold t=0

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| captain pts | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| net transfer gain | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P5 calib + threshold t=0.5

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -0.35 [-1.06, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| captain pts | -0.18 [-0.53, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| net transfer gain | +0.21 [-0.06, +0.70] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P5 calib + threshold t=1

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -0.85 [-1.88, -0.09]★ | +1.11 [-1.76, +3.76] | +0.76 [-0.92, +2.74] |
| captain pts | -0.21 [-0.59, +0.00] | +0.11 [-0.74, +0.97] | +0.00 [+0.00, +0.00] |
| net transfer gain | +0.48 [-0.12, +1.21] | -0.62 [-2.76, +1.32] | +0.73 [-0.68, +2.38] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P5 calib + threshold t=2

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -10.76 [-15.68, -5.82]★ | -2.53 [-7.95, +2.66] | +2.58 [-0.24, +5.53] |
| captain pts | -0.91 [-2.50, +0.15] | -0.82 [-3.08, +1.26] | +0.26 [-0.50, +1.16] |
| net transfer gain | +0.12 [-1.70, +2.00] | -0.76 [-2.95, +1.19] | +0.46 [-1.03, +1.97] |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### P5 calib + threshold t=3

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -3.32 [-7.50, +0.35] | -1.16 [-6.58, +3.47] | +2.55 [-0.47, +5.68] |
| captain pts | -0.76 [-2.44, +0.44] | -0.89 [-3.05, +1.11] | +0.71 [-0.18, +1.82] |
| net transfer gain | +0.00 [-1.82, +1.97] | -0.57 [-2.30, +1.05] | +1.62 [+0.16, +3.11]★ |
| xPts MAE all (↓ shown as reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |
| xPts MAE 60+ (reduction) | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] |

### C1 vec_xg2 + B0 captain

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +0.62 [-5.32, +6.38] | +6.37 [+0.45, +12.29]★ | +12.47 [+7.82, +17.34]★ |
| captain pts | +1.21 [-1.24, +3.35] | +1.18 [-1.55, +4.11] | +2.16 [+0.55, +3.82]★ |
| net transfer gain | +0.67 [-1.55, +3.00] | -0.16 [-2.27, +1.76] | +2.30 [+0.49, +4.08]★ |
| xPts MAE all (↓ shown as reduction) | +0.02 [-0.00, +0.03] | +0.11 [+0.09, +0.12]★ | +0.19 [+0.17, +0.21]★ |
| xPts MAE 60+ (reduction) | -0.12 [-0.15, -0.09]★ | -0.01 [-0.05, +0.03] | +0.09 [+0.06, +0.12]★ |

### C2 vec_xg2 + B0 captain + calib t=1

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -12.50 [-19.06, -6.50]★ | -14.68 [-22.03, -7.18]★ | +4.34 [-0.66, +9.26] |
| captain pts | +1.44 [-0.47, +3.32] | -0.76 [-3.71, +2.26] | -0.29 [-1.74, +1.32] |
| net transfer gain | -0.97 [-2.52, +0.70] | -2.41 [-4.43, -0.65]★ | -0.73 [-1.86, +0.38] |
| xPts MAE all (↓ shown as reduction) | +0.02 [-0.00, +0.03] | +0.11 [+0.09, +0.12]★ | +0.19 [+0.17, +0.21]★ |
| xPts MAE 60+ (reduction) | -0.12 [-0.15, -0.09]★ | -0.01 [-0.05, +0.03] | +0.09 [+0.06, +0.12]★ |

### C3 minutes_v2 + B0 captain

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | +0.18 [-2.82, +3.24] | +3.16 [-0.50, +7.18] | +5.97 [+2.60, +9.50]★ |
| captain pts | +1.71 [-0.53, +3.74] | +2.24 [+0.50, +4.26]★ | +2.61 [+0.92, +4.47]★ |
| net transfer gain | +0.09 [-1.15, +1.33] | -0.30 [-2.11, +1.22] | +0.95 [-1.11, +3.05] |
| xPts MAE all (↓ shown as reduction) | +0.03 [+0.02, +0.03]★ | +0.05 [+0.05, +0.05]★ | +0.06 [+0.06, +0.07]★ |
| xPts MAE 60+ (reduction) | -0.03 [-0.03, -0.02]★ | -0.02 [-0.03, -0.02]★ | -0.04 [-0.04, -0.03]★ |

### C4 minutes_v2 + B0 captain + calib t=1

| metric | 2023/24 | 2024/25 | 2025/26 |
|---|---|---|---|
| XI pts incl C & hits | -0.71 [-4.65, +2.65] | +4.61 [+1.16, +8.63]★ | +4.50 [+0.47, +8.79]★ |
| captain pts | +1.62 [-0.74, +3.88] | +1.82 [+0.32, +3.66]★ | +1.76 [-0.08, +3.55] |
| net transfer gain | +0.64 [-0.91, +2.18] | -0.86 [-2.89, +0.73] | +0.32 [-1.43, +1.89] |
| xPts MAE all (↓ shown as reduction) | +0.03 [+0.02, +0.03]★ | +0.05 [+0.05, +0.05]★ | +0.06 [+0.06, +0.07]★ |
| xPts MAE 60+ (reduction) | -0.03 [-0.03, -0.02]★ | -0.02 [-0.03, -0.02]★ | -0.04 [-0.04, -0.03]★ |

## Forecast error by actual-points bucket (per-GW, reduction vs baseline; positive = variant better)

| variant | MAE bucket 0 (reduction) | RMSE bucket 0 (reduction) | MAE bucket 1-2 (reduction) | RMSE bucket 1-2 (reduction) | MAE bucket 3-4 (reduction) | RMSE bucket 3-4 (reduction) | MAE bucket 5+ (reduction) | RMSE bucket 5+ (reduction) |
|---|---|---|---|---|---|---|---|---|
| vec_noxg | +0.185★ | +0.088★ | -0.385★ | -0.528★ | +0.189★ | +0.130★ | +0.800★ | +0.676★ |
| vec_xg | +0.188★ | +0.092★ | -0.381★ | -0.520★ | +0.180★ | +0.127★ | +0.806★ | +0.679★ |
| minutes_v2 | +0.077★ | +0.128★ | +0.043★ | +0.048★ | -0.071★ | -0.062★ | -0.094★ | -0.081★ |
| vec_xg2 | +0.200★ | +0.059★ | -0.400★ | -0.561★ | +0.184★ | +0.129★ | +0.871★ | +0.738★ |
| ts_xg | +0.003★ | +0.009★ | +0.014★ | +0.023★ | +0.000 | +0.002 | -0.016★ | -0.012★ |
| baseline | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |

Baseline absolute levels (per-GW mean): xi=44.082, cap=4.664, tx=1.374, mae_all=1.119, mae_60=2.358, rmse_all=2.108, rmse_60=3.636

## Notes per proposal

- **P1/P2b (Vector GBMs)** are ported into `MODELS` (`backtest/vector_models.py`) instead of joined from `predictions.parquet`, so all three seasons are covered (the parquet only has 2023/24–2024/25). Changes from Vector's version: keyed on player_code rather than name, stable club codes, history starts at 2023/24 (no 2022/23). Features, hyper-parameters and 4-GW retrain are unchanged. They predict per player-GW, split evenly across a double gameweek's fixture rows.
- **bt.py lookahead audit:** rolling features are `shift(1)` within player-season, team xG is `shift(1)` within season, prior-season means come from completed seasons, and training uses `t < test t`, so no leak in the GBM features. Same caveat as the engine: `value`/`nfix` come from the GW-t row (deadline price, fixture count). **`fpl_xP` (vaastav `xP`) is NOT ported**: its uplift (+34.7 XI pts/GW vs form) is implausibly large and vaastav's `xP` is scraped around or after the GW, so treat it as a likely leak.
- **P2a minutes_v2** surfaced an engine edge case: when a held player changes club and the squad goes over the 3-per-club cap, `recommend_transfers` raises InfeasibleError ('no legal starting XI'). FPL lets you keep that squad. The harness now treats the excess player as his own pseudo-club for that week (`club-cap grandfathering`); this triggered only in the minutes_v2 run (2025/26 from GW3). The live engine probably has the same bug.
- **P4** only overrides the captain and leaves transfers and XI unchanged, so XI uplift equals captain uplift.
- **P5** ratio = realised/predicted gross gain of executed transfers, cumulative over **prior GWs only** (clipped to [0,1], 1.0 until 5 xP of history). An option executes only if ratio×gross-gain + hit > t, otherwise roll. Ratio settled about 0.45–0.6, so the engine overstates transfer gain by about 2×. **Selection bias:** t was picked as the best of 5 grid points on the same 110 GWs, so the best uplift is optimistic. Even so, no grid point improves significantly, and t=2 is significantly worse.

  - t=0: transfers 110, hit GWs 0, median ratio 0.57, XI/GW 44.08
  - t=0.5: transfers 110, hit GWs 0, median ratio 0.61, XI/GW 43.97
  - t=1: transfers 109, hit GWs 0, median ratio 0.57, XI/GW 44.46
  - t=2: transfers 72, hit GWs 0, median ratio 0.45, XI/GW 40.77
  - t=3: transfers 59, hit GWs 0, median ratio 0.56, XI/GW 43.54

## Recommendation

1. **Ship candidate (in-engine, low risk): C3 = `discrimination.minutes_v2: true` + replace the captain choice with the price+position (B0) ranking within the chosen XI.** XI +3.2/GW [+1.1, +5.3]★, captain +2.2 [+1.0, +3.4]★, MAE for all players better★ but MAE for 60+ players slightly worse (−0.028★): it wins on minutes, not on points-given-play. The captain fix alone (P4b) is +1.8★. Fix the club-cap infeasibility bug first.
2. **Biggest upside, more work: C1 = Vector's two-stage GBM (+xG, P(play)×pts|play) + B0 captain.** XI +6.7/GW [+3.3, +9.9]★, captain +1.5★. But it is a non-explainable monolith (DP-10 trade-off), its MAE for 60+ players isn't better, and its hits are frequent. Treat it as a shadow model / research lead for the ranking head rather than a drop-in.
3. **Don't adopt:** team_strength_from_xg (P3, no decision gain), MID/FWD captain restriction (P4a), calibration/threshold (P5: no significant gain on its own; with vec_xg2 it is significantly harmful, C2 −7.4★).
4. The xG GBM without the minutes stage (P1b +4.4★) beats the no-xG GBM (P1a +2.8, ns), so the xG features carry real signal for the ranking.
