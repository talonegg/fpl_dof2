# Round 2 candidate backtests (local review only; nothing pushed)

Branch `forge/round2` (from `forge/availability-odds-shadow`). Window 2023/24 GW5 → 2025/26 GW38: 110 decision GWs, 107 with transfers. Deadline availability (fplcache, strictly before the deadline) applies to every run. Decision layer = the real `recommend_transfers` (1 FT, rolling to 5, −4 per extra, max 2 transfers/GW unless stated otherwise), start-prob floor off as in all prior runs. Paired per-GW uplift = candidate − reference, 95% bootstrap over GWs (2000 draws), ★ = CI excludes 0. MAE/RMSE are shown as a reduction, so + is better.

- **Champion** = `minutes_v2` engine cache + C3 price/position (b0) captain. It reproduces 51.52 XI/GW, −16 hits, exactly matching RESULTS_datasources "C3 L1".
- **Challenger** = C1 `vec_xg2` + b0 captain. It reproduces 53.77, −120 hits, exactly matching "C1 L1".
- Code: `round2.py` (overlays + decision loop), `r2_captain.py` (F/G), `comp_model.py` (A), `r2_compare.py`/`r2_report.py`. Outputs are in `r2/`.

## Winners (rule: overall XI CI > 0 AND point estimate ≥ 0 in every season)

**None.** Closest:
- **A component xPts vs champion:** +2.55 XI/GW [−0.43, +5.53], best absolute XI (54.07), best MAE/RMSE of all three models, and a significant +1.42 net transfer gain. It fails the rule because 2023/24 is −2.03 and the overall CI crosses 0. Against the challenger it's +0.30 (n.s.). Worth a shadow slot; not a switch.
- **C shrinkage:** +0.6/+0.75 XI (n.s.), mixed seasons.
- **G odds captain on the challenger:** +0.10 (n.s.), and 2023/24 is −0.18. Last round's positive captain signal came from odds as GBM features, not from a captain-only rule, and it does not replicate here.
- **Captain:** the C3 price/position rule stays best. Every F rule is ≤0, and pure mean-xP / F3 are significantly worse on the champion (−1.5 to −1.6).

## Candidate notes / definitions
- **A:** separate per-position HistGBMs (P(play), P(60|play), Poisson goals, assists, bonus, GK saves → E[floor(S/3)]), CS = exp(−λ) with λ from team rolling xGA and opponent rolling xGF, GK/DEF −E[floor(GC/2)], DC 2 pts × P(threshold: DEF CBIT≥10, others CBIRT≥12). These are summed with FPL scoring and use the C3 captain. The archive has `defensive_contribution`/CBIT fields **only for 2025/26** (0% coverage for 2023/24 and 2024/25), so DC is trained and applied only within 2025/26 prior GWs. Cards, OGs and pen saves/misses are omitted. A single model fills both the champion xPts slot and C1's slot (same decision layer), so it is scored against both.
- **B:** P(start) and P(60|start) HistGBMs (features: deadline avail, flagged, rotation index = std of last-6 minutes/90, rolling starts/minutes, price, prev-season minutes). Applied as an overlay: xp × r, r = q/mean(q over prior 6 GWs), clipped to [0, 1.5]. B1/B2 replace the avail scaling; B1a stacks on top of it. **B is clearly harmful:** the week-to-week swings in r make the challenger churn (−308 hit pts). This is a test of the overlay as implemented. A native minutes head inside each model was out of scope here.
- **C:** EB shrinkage for players with <6 prior 90s this season toward the prior-GW mean of low-minute players in position × price band (k = 3). Plus a **fixed ×0.9 promoted-team discount** (Championship strength was not obtainable leak-free in the archive). Promoted teams are hard-coded (public before the season).
- **D:** isotonic regression per position on prior-GW (xp, actual). It improves RMSE but hurts MAE and decisions. It compresses the top end, so the optimiser spreads differently and C1 takes fewer hits but scores less.
- **E:** coordinate search on **2023/24 only**, then tested on 2024/25 + 2025/26 only.
  - Hit thresholds +4/+6/+8 (`min_gain_over_hit` 0/2/4) were **identical** on both arms, so they never bind. The wiring was verified: a +24 threshold removes all hits.
  - Max transfers 3 (rolling is already cap 5 by the rules; the limit is how many banked FTs can be used): champion unchanged, challenger +0.56 on 2023/24.
  - Robust mean − λ·std (std = prior-GW residual SD by position × xP decile), λ 0.25/0.5: champion worse (selected = default, so the test uplift is 0 by construction). Challenger mt3 + λ0.25 was best on 2023/24 (52.82 vs 51.68).
  - On test it is **−5.30 [−8.50, −2.29]★**, a clean overfit on 2023/24.
  - **Not run:** horizon 3/5 and decay. The caches hold single-GW forecasts only, and a multi-GW forecast needs a refit of every model per (deadline, horizon). The 20-scenario median was also skipped.
- **F:** F1 = argmax logistic P(base ≥5, i.e. ≥10 incl. captain double) on (xp, b0) per position. F2 = HistGBM quantile-0.75 on (xp, b0). F3 = argmax xP, ties within 0.5 → highest-priced MID/FWD ≥ £9.0m. All are walk-forward, refit every 4 GWs on prior GWs.
- **G:** per-position OLS of actual on (b0, b0×implied GF, b0×CS prob, has-odds), prior GWs only. Pre-closing odds come from `fdcouk/team_odds.parquet`. Fixtures whose collection time is not before the deadline have no odds (about 14%).

## Club-cap crash
**Fixed in this branch.** `pipeline/src/fpl_dof/optimise/transfer.py` (commit 50a0dc0, #36) grandfathers over-cap held squads and binds the cap on buys only. `round2.simulate` has **no workaround** and catches nothing: the champion base was over the cap in 6 GWs, C shrink in 5 and B in 3, with **0 InfeasibleErrors** across all runs. The old harness `backtest.simulate` still carries the now-dead fallback branch and could be removed.

## Leakage
All fits use t < decision GW. Features are shifted rolling stats or deadline snapshots. I could not make two things leak-free: Championship strength (so I used a fixed discount), and odds for fixtures collected after the deadline (dropped). The odds collection time is still an assumption (18:00 UK; see RESULTS_datasources).

## Caveats
- **Selection bias:** about 20 configurations were tried against the same 110 GWs (E excepted). With no multiple-testing correction, even a marginal ★ would be weak evidence.
- A and the B models use my own specification choices (HGB settings, overlay form). Negative results for B/D reflect these implementations, not the ideas in general.
- Per-season CIs are wide (±5 XI pts), so non-negative-every-season is a noisy filter.
- **Runtime cuts:** E horizon/decay and the scenario median were not run. Everything else ran in full.
## Key table (paired uplift, candidate − reference; MAE/RMSE as reduction so + = better; 95% GW-bootstrap CI; ★ = CI excludes 0)

| candidate | vs | XI pts/GW | captain pts/GW | net transfer gain/GW | MAE↓ | RMSE↓ | abs XI | hits | winner? |
|---|---|---|---|---|---|---|---|---|---|
| F1 P(haul≥10 incl. C) | champion | -0.49 [-1.38, +0.36] | -0.49 [-1.40, +0.35] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 51.03 | -16 | no |
| F2 75th-pct score | champion | -0.65 [-1.48, +0.07] | -0.65 [-1.49, +0.08] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 50.86 | -16 | no |
| F3 mean xP + premium-attacker tie-break | champion | -1.53 [-2.65, -0.35]★ | -1.53 [-2.65, -0.38]★ | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 49.99 | -16 | no |
| (ref) mean xP argmax | champion | -1.60 [-2.73, -0.45]★ | -1.60 [-2.73, -0.45]★ | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 49.92 | -16 | no |
| G odds-aware captain | champion | -0.26 [-0.91, +0.29] | -0.26 [-0.93, +0.32] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 51.25 | -16 | no |
| B1 two-stage minutes (replaces avail scaling) | champion | -2.70 [-5.50, +0.21] | +0.20 [-0.78, +1.20] | +0.86 [-0.14, +1.95] | -0.05 [-0.06, -0.05]★ | +0.00 [-0.01, +0.01] | 48.82 | -72 | no |
| B2 B1 + 3× zero-pt weight if flagged | champion | -3.03 [-6.14, +0.00] | +0.04 [-0.95, +1.00] | +0.85 [-0.24, +1.98] | -0.06 [-0.06, -0.05]★ | +0.00 [-0.01, +0.01] | 48.49 | -60 | no |
| B1a B1 overlay on top of avail scaling | champion | -2.08 [-4.85, +0.64] | -0.07 [-1.06, +0.94] | +1.41 [+0.35, +2.55]★ | +0.00 [-0.00, +0.01] | +0.01 [-0.00, +0.02] | 49.44 | -88 | no |
| D isotonic per position | champion | -1.21 [-3.44, +0.89] | -0.19 [-0.78, +0.38] | -0.08 [-1.19, +1.00] | -0.10 [-0.11, -0.10]★ | +0.05 [+0.04, +0.05]★ | 50.31 | -56 | no |
| C EB shrinkage + promoted ×0.9 | champion | +0.64 [-1.63, +2.95] | -0.44 [-0.97, +0.10] | +0.34 [-0.81, +1.44] | -0.00 [-0.01, +0.00] | -0.01 [-0.02, -0.01]★ | 52.15 | -24 | no |
| A component xPts (+C3 captain) | champion | +2.55 [-0.43, +5.53] | +0.17 [-0.69, +1.01] | +1.42 [+0.04, +2.92]★ | +0.02 [+0.02, +0.03]★ | +0.13 [+0.12, +0.15]★ | 54.07 | -104 | no |
| F1 P(haul≥10 incl. C) | challenger | -0.17 [-0.96, +0.56] | -0.17 [-0.98, +0.57] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 53.60 | -120 | no |
| F2 75th-pct score | challenger | -0.35 [-1.42, +0.65] | -0.35 [-1.44, +0.63] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 53.42 | -120 | no |
| F3 mean xP + premium-attacker tie-break | challenger | -0.61 [-1.75, +0.46] | -0.61 [-1.67, +0.43] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 53.16 | -120 | no |
| (ref) mean xP argmax | challenger | -0.60 [-1.75, +0.51] | -0.60 [-1.77, +0.52] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 53.17 | -120 | no |
| G odds-aware captain | challenger | +0.10 [-0.44, +0.63] | +0.10 [-0.47, +0.60] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | +0.00 [+0.00, +0.00] | 53.87 | -120 | no |
| B1 two-stage minutes (replaces avail scaling) | challenger | -6.27 [-9.45, -2.95]★ | -0.26 [-1.25, +0.74] | -0.56 [-2.18, +1.07] | -0.08 [-0.09, -0.07]★ | -0.08 [-0.09, -0.07]★ | 47.50 | -308 | no |
| B2 B1 + 3× zero-pt weight if flagged | challenger | -9.17 [-12.51, -5.60]★ | -0.92 [-1.98, +0.11] | -0.90 [-2.48, +0.67] | -0.08 [-0.09, -0.07]★ | -0.08 [-0.09, -0.07]★ | 44.60 | -312 | no |
| B1a B1 overlay on top of avail scaling | challenger | -6.62 [-9.95, -3.65]★ | -0.89 [-1.86, +0.06] | -0.60 [-2.27, +1.13] | -0.07 [-0.08, -0.06]★ | -0.08 [-0.09, -0.07]★ | 47.15 | -308 | no |
| D isotonic per position | challenger | -1.87 [-4.54, +0.59] | -0.29 [-1.19, +0.55] | -0.29 [-1.36, +0.75] | -0.04 [-0.05, -0.04]★ | +0.01 [+0.01, +0.02]★ | 51.90 | -52 | no |
| C EB shrinkage + promoted ×0.9 | challenger | +0.75 [-1.14, +2.60] | +0.09 [-0.61, +0.73] | -0.50 [-1.47, +0.46] | -0.01 [-0.01, -0.01]★ | -0.01 [-0.02, -0.01]★ | 54.52 | -108 | no |
| A component xPts (+C3 captain) | challenger | +0.30 [-3.02, +3.73] | +0.79 [-0.11, +1.69] | +0.42 [-1.05, +1.92] | +0.03 [+0.02, +0.04]★ | +0.03 [+0.03, +0.04]★ | 54.07 | -104 | no |
| E selected on 2023/24: max_transfers 3 + λ=0.25 (test 24/25+25/26) | challenger | -5.30 [-8.50, -2.29]★ | -1.57 [-3.05, -0.33]★ | -0.99 [-2.08, +0.14] | +0.06 [+0.05, +0.07]★ | -0.07 [-0.08, -0.07]★ | 49.41 | -88 | no |

## Per-season XI pts / captain pts / MAE↓

| candidate | vs | season | XI | captain | MAE↓ |
|---|---|---|---|---|---|
| F1 P(haul≥10 incl. C) | champion | 2023/24 | -0.47 [-2.38, +1.62] | -0.47 [-2.29, +1.56] | +0.00 [+0.00, +0.00] |
| F1 P(haul≥10 incl. C) | champion | 2024/25 | -0.37 [-1.87, +0.66] | -0.37 [-1.84, +0.63] | +0.00 [+0.00, +0.00] |
| F1 P(haul≥10 incl. C) | champion | 2025/26 | -0.63 [-1.87, +0.55] | -0.63 [-1.87, +0.63] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | champion | 2023/24 | -0.76 [-1.97, +0.41] | -0.76 [-2.06, +0.47] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | champion | 2024/25 | -0.13 [-1.63, +1.00] | -0.13 [-1.71, +0.97] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | champion | 2025/26 | -1.08 [-2.50, +0.24] | -1.08 [-2.50, +0.26] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | champion | 2023/24 | -1.85 [-4.15, +0.53] | -1.85 [-4.00, +0.71] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | champion | 2024/25 | -1.63 [-3.47, +0.08] | -1.63 [-3.50, +0.05] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | champion | 2025/26 | -1.13 [-2.95, +0.47] | -1.13 [-2.89, +0.53] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | champion | 2023/24 | -2.24 [-4.38, +0.26] | -2.24 [-4.41, +0.18] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | champion | 2024/25 | -1.50 [-3.45, +0.18] | -1.50 [-3.45, +0.32] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | champion | 2025/26 | -1.13 [-2.97, +0.61] | -1.13 [-2.97, +0.63] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | champion | 2023/24 | -0.62 [-1.62, +0.00] | -0.62 [-1.62, +0.00] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | champion | 2024/25 | -0.32 [-1.82, +0.97] | -0.32 [-1.87, +0.97] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | champion | 2025/26 | +0.11 [-0.42, +0.74] | +0.11 [-0.45, +0.71] | +0.00 [+0.00, +0.00] |
| B1 two-stage minutes (replaces avail scaling) | champion | 2023/24 | -1.41 [-6.71, +3.77] | -0.62 [-1.79, +0.44] | -0.04 [-0.05, -0.03]★ |
| B1 two-stage minutes (replaces avail scaling) | champion | 2024/25 | -4.58 [-9.45, +0.42] | +0.61 [-1.18, +2.24] | -0.06 [-0.07, -0.05]★ |
| B1 two-stage minutes (replaces avail scaling) | champion | 2025/26 | -1.97 [-6.71, +2.45] | +0.53 [-1.39, +2.42] | -0.07 [-0.08, -0.05]★ |
| B2 B1 + 3× zero-pt weight if flagged | champion | 2023/24 | -4.97 [-10.56, +0.41] | -0.15 [-1.21, +0.94] | -0.04 [-0.06, -0.04]★ |
| B2 B1 + 3× zero-pt weight if flagged | champion | 2024/25 | -3.74 [-9.11, +1.90] | -0.03 [-1.90, +1.76] | -0.06 [-0.07, -0.05]★ |
| B2 B1 + 3× zero-pt weight if flagged | champion | 2025/26 | -0.58 [-4.97, +4.00] | +0.26 [-1.63, +2.11] | -0.06 [-0.08, -0.05]★ |
| B1a B1 overlay on top of avail scaling | champion | 2023/24 | -4.50 [-9.15, +0.06] | -0.06 [-1.12, +1.00] | +0.01 [+0.00, +0.01]★ |
| B1a B1 overlay on top of avail scaling | champion | 2024/25 | -3.97 [-8.68, +0.61] | +0.18 [-1.82, +1.87] | -0.00 [-0.02, +0.01] |
| B1a B1 overlay on top of avail scaling | champion | 2025/26 | +1.97 [-2.61, +6.76] | -0.34 [-2.32, +1.55] | +0.01 [-0.00, +0.02] |
| D isotonic per position | champion | 2023/24 | +1.35 [-2.53, +5.27] | -0.56 [-1.65, +0.41] | -0.08 [-0.09, -0.07]★ |
| D isotonic per position | champion | 2024/25 | -2.39 [-6.45, +1.63] | +0.08 [+0.00, +0.24] | -0.12 [-0.13, -0.11]★ |
| D isotonic per position | champion | 2025/26 | -2.32 [-5.61, +1.11] | -0.13 [-1.68, +1.16] | -0.10 [-0.11, -0.09]★ |
| C EB shrinkage + promoted ×0.9 | champion | 2023/24 | -1.29 [-4.38, +1.82] | -0.82 [-1.85, +0.09] | -0.02 [-0.03, -0.02]★ |
| C EB shrinkage + promoted ×0.9 | champion | 2024/25 | +1.13 [-3.50, +5.29] | +0.18 [+0.00, +0.55] | +0.01 [+0.00, +0.02]★ |
| C EB shrinkage + promoted ×0.9 | champion | 2025/26 | +1.87 [-2.24, +5.90] | -0.71 [-1.97, +0.47] | +0.01 [+0.00, +0.01]★ |
| A component xPts (+C3 captain) | champion | 2023/24 | -2.03 [-7.41, +3.32] | -0.88 [-2.62, +0.88] | +0.01 [-0.00, +0.02] |
| A component xPts (+C3 captain) | champion | 2024/25 | +4.45 [-1.03, +9.63] | +1.45 [+0.45, +2.66]★ | +0.02 [+0.00, +0.03]★ |
| A component xPts (+C3 captain) | champion | 2025/26 | +4.76 [-0.63, +9.95] | -0.16 [-1.63, +1.13] | +0.05 [+0.03, +0.06]★ |
| F1 P(haul≥10 incl. C) | challenger | 2023/24 | -0.32 [-1.62, +0.94] | -0.32 [-1.56, +0.91] | +0.00 [+0.00, +0.00] |
| F1 P(haul≥10 incl. C) | challenger | 2024/25 | +0.11 [-1.24, +1.16] | +0.11 [-1.26, +1.21] | +0.00 [+0.00, +0.00] |
| F1 P(haul≥10 incl. C) | challenger | 2025/26 | -0.32 [-1.84, +1.08] | -0.32 [-1.79, +1.08] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | challenger | 2023/24 | -0.82 [-2.94, +1.35] | -0.82 [-3.00, +1.38] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | challenger | 2024/25 | -0.84 [-2.26, +0.37] | -0.84 [-2.39, +0.39] | +0.00 [+0.00, +0.00] |
| F2 75th-pct score | challenger | 2025/26 | +0.55 [-1.29, +2.34] | +0.55 [-1.24, +2.26] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | challenger | 2023/24 | -1.18 [-3.06, +0.71] | -1.18 [-3.09, +0.79] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | challenger | 2024/25 | -0.95 [-3.05, +0.84] | -0.95 [-2.95, +0.84] | +0.00 [+0.00, +0.00] |
| F3 mean xP + premium-attacker tie-break | challenger | 2025/26 | +0.24 [-1.61, +2.00] | +0.24 [-1.53, +2.11] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | challenger | 2023/24 | -0.88 [-2.91, +1.09] | -0.88 [-2.79, +1.06] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | challenger | 2024/25 | -1.08 [-3.21, +0.87] | -1.08 [-3.32, +0.87] | +0.00 [+0.00, +0.00] |
| (ref) mean xP argmax | challenger | 2025/26 | +0.13 [-1.63, +2.00] | +0.13 [-1.55, +1.82] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | challenger | 2023/24 | -0.18 [-0.50, +0.00] | -0.18 [-0.50, +0.00] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | challenger | 2024/25 | +0.18 [-1.16, +1.29] | +0.18 [-1.05, +1.29] | +0.00 [+0.00, +0.00] |
| G odds-aware captain | challenger | 2025/26 | +0.26 [-0.55, +1.08] | +0.26 [-0.50, +1.08] | +0.00 [+0.00, +0.00] |
| B1 two-stage minutes (replaces avail scaling) | challenger | 2023/24 | -8.26 [-13.85, -2.65]★ | -1.09 [-2.18, -0.21]★ | -0.08 [-0.08, -0.07]★ |
| B1 two-stage minutes (replaces avail scaling) | challenger | 2024/25 | -5.34 [-10.74, +0.82] | +0.05 [-1.68, +2.00] | -0.10 [-0.12, -0.08]★ |
| B1 two-stage minutes (replaces avail scaling) | challenger | 2025/26 | -5.42 [-10.71, +0.00] | +0.16 [-1.71, +1.87] | -0.07 [-0.09, -0.06]★ |
| B2 B1 + 3× zero-pt weight if flagged | challenger | 2023/24 | -8.15 [-13.85, -2.47]★ | -0.09 [-1.62, +1.44] | -0.08 [-0.08, -0.07]★ |
| B2 B1 + 3× zero-pt weight if flagged | challenger | 2024/25 | -13.26 [-19.92, -7.18]★ | -1.89 [-3.90, -0.05]★ | -0.10 [-0.12, -0.08]★ |
| B2 B1 + 3× zero-pt weight if flagged | challenger | 2025/26 | -6.00 [-11.16, -0.50]★ | -0.68 [-2.58, +1.21] | -0.07 [-0.09, -0.06]★ |
| B1a B1 overlay on top of avail scaling | challenger | 2023/24 | -6.15 [-11.65, -0.68]★ | -0.41 [-1.29, +0.41] | -0.06 [-0.06, -0.05]★ |
| B1a B1 overlay on top of avail scaling | challenger | 2024/25 | -10.32 [-15.61, -4.79]★ | -1.63 [-3.63, +0.18] | -0.08 [-0.10, -0.07]★ |
| B1a B1 overlay on top of avail scaling | challenger | 2025/26 | -3.34 [-8.61, +2.05] | -0.58 [-2.47, +1.26] | -0.06 [-0.08, -0.05]★ |
| D isotonic per position | challenger | 2023/24 | -4.26 [-9.15, +0.94] | -0.44 [-2.29, +1.41] | -0.04 [-0.05, -0.03]★ |
| D isotonic per position | challenger | 2024/25 | -2.00 [-6.50, +2.45] | -0.03 [-1.21, +0.97] | -0.04 [-0.05, -0.04]★ |
| D isotonic per position | challenger | 2025/26 | +0.39 [-3.13, +4.11] | -0.42 [-1.97, +0.92] | -0.04 [-0.05, -0.04]★ |
| C EB shrinkage + promoted ×0.9 | challenger | 2023/24 | +0.65 [-2.35, +4.03] | +0.50 [+0.00, +1.21] | -0.02 [-0.02, -0.01]★ |
| C EB shrinkage + promoted ×0.9 | challenger | 2024/25 | -1.58 [-4.95, +1.79] | -0.39 [-1.71, +0.71] | -0.00 [-0.01, +0.01] |
| C EB shrinkage + promoted ×0.9 | challenger | 2025/26 | +3.16 [-0.24, +6.61] | +0.21 [-1.03, +1.50] | -0.01 [-0.02, -0.01]★ |
| A component xPts (+C3 captain) | challenger | 2023/24 | -0.38 [-5.59, +4.59] | +0.18 [-0.94, +1.44] | +0.06 [+0.05, +0.07]★ |
| A component xPts (+C3 captain) | challenger | 2024/25 | -0.26 [-6.63, +7.18] | +1.37 [-0.37, +3.26] | +0.02 [+0.01, +0.03]★ |
| A component xPts (+C3 captain) | challenger | 2025/26 | +1.47 [-3.79, +6.24] | +0.76 [-0.84, +2.32] | +0.01 [+0.00, +0.01]★ |
| E selected on 2023/24: max_transfers 3 + λ=0.25 (test 24/25+25/26) | challenger | 2024/25 | -6.79 [-11.37, -2.53]★ | -1.71 [-3.92, +0.16] | +0.07 [+0.06, +0.07]★ |
| E selected on 2023/24: max_transfers 3 + λ=0.25 (test 24/25+25/26) | challenger | 2025/26 | -3.82 [-7.92, +0.32] | -1.42 [-3.03, +0.05] | +0.05 [+0.05, +0.06]★ |

## Error by actual-points bucket (reduction; + = better)

| candidate | vs | MAE 0 | MAE 1-2 | MAE 3-4 | MAE 5+ | RMSE 0 | RMSE 1-2 | RMSE 3-4 | RMSE 5+ |
|---|---|---|---|---|---|---|---|---|---|
| B1 two-stage minutes (replaces avail scaling) | champion | -0.06 [-0.07, -0.05]★ | -0.13 [-0.14, -0.11]★ | +0.05 [+0.00, +0.09]★ | +0.18 [+0.12, +0.22]★ | -0.05 [-0.07, -0.04]★ | -0.17 [-0.19, -0.16]★ | +0.01 [-0.03, +0.05] | +0.14 [+0.09, +0.18]★ |
| B2 B1 + 3× zero-pt weight if flagged | champion | -0.06 [-0.07, -0.04]★ | -0.14 [-0.16, -0.12]★ | +0.05 [+0.00, +0.09]★ | +0.18 [+0.13, +0.22]★ | -0.05 [-0.07, -0.03]★ | -0.19 [-0.21, -0.17]★ | +0.01 [-0.03, +0.04] | +0.14 [+0.09, +0.18]★ |
| B1a B1 overlay on top of avail scaling | champion | +0.03 [+0.03, +0.04]★ | -0.13 [-0.14, -0.11]★ | +0.05 [+0.00, +0.08]★ | +0.17 [+0.11, +0.21]★ | +0.00 [-0.01, +0.02] | -0.17 [-0.20, -0.16]★ | +0.01 [-0.04, +0.04] | +0.13 [+0.08, +0.17]★ |
| D isotonic per position | champion | -0.15 [-0.16, -0.15]★ | -0.32 [-0.34, -0.31]★ | +0.36 [+0.32, +0.40]★ | +0.64 [+0.62, +0.67]★ | -0.25 [-0.26, -0.23]★ | -0.39 [-0.41, -0.37]★ | +0.29 [+0.25, +0.33]★ | +0.57 [+0.55, +0.60]★ |
| C EB shrinkage + promoted ×0.9 | champion | +0.01 [+0.00, +0.02]★ | +0.04 [+0.03, +0.05]★ | -0.11 [-0.14, -0.08]★ | -0.11 [-0.14, -0.08]★ | +0.06 [+0.05, +0.08]★ | +0.05 [+0.04, +0.07]★ | -0.09 [-0.12, -0.07]★ | -0.09 [-0.12, -0.07]★ |
| B1 two-stage minutes (replaces avail scaling) | challenger | -0.03 [-0.04, -0.03]★ | -0.34 [-0.36, -0.32]★ | -0.13 [-0.16, -0.09]★ | +0.31 [+0.26, +0.35]★ | -0.13 [-0.14, -0.12]★ | -0.43 [-0.46, -0.40]★ | -0.20 [-0.24, -0.16]★ | +0.24 [+0.20, +0.27]★ |
| B2 B1 + 3× zero-pt weight if flagged | challenger | -0.02 [-0.03, -0.02]★ | -0.35 [-0.38, -0.33]★ | -0.14 [-0.18, -0.11]★ | +0.31 [+0.27, +0.35]★ | -0.12 [-0.13, -0.11]★ | -0.45 [-0.48, -0.42]★ | -0.21 [-0.25, -0.18]★ | +0.23 [+0.19, +0.27]★ |
| B1a B1 overlay on top of avail scaling | challenger | -0.01 [-0.01, -0.00]★ | -0.34 [-0.36, -0.31]★ | -0.13 [-0.17, -0.10]★ | +0.29 [+0.25, +0.33]★ | -0.11 [-0.12, -0.10]★ | -0.42 [-0.45, -0.39]★ | -0.20 [-0.24, -0.17]★ | +0.22 [+0.18, +0.25]★ |
| D isotonic per position | challenger | -0.10 [-0.11, -0.10]★ | +0.07 [+0.06, +0.08]★ | +0.25 [+0.24, +0.27]★ | -0.07 [-0.09, -0.05]★ | -0.07 [-0.08, -0.06]★ | +0.16 [+0.14, +0.17]★ | +0.28 [+0.26, +0.30]★ | -0.03 [-0.05, -0.01]★ |
| C EB shrinkage + promoted ×0.9 | challenger | -0.03 [-0.04, -0.02]★ | +0.12 [+0.09, +0.15]★ | -0.12 [-0.15, -0.09]★ | -0.20 [-0.26, -0.15]★ | +0.06 [+0.04, +0.07]★ | +0.13 [+0.10, +0.17]★ | -0.11 [-0.14, -0.08]★ | -0.17 [-0.22, -0.13]★ |
| E selected on 2023/24: max_transfers 3 + λ=0.25 (test 24/25+25/26) | challenger | +0.13 [+0.13, +0.14]★ | +0.24 [+0.22, +0.27]★ | -0.35 [-0.38, -0.32]★ | -0.73 [-0.74, -0.72]★ | +0.22 [+0.22, +0.23]★ | +0.35 [+0.32, +0.38]★ | -0.33 [-0.36, -0.29]★ | -0.64 [-0.65, -0.63]★ |

## Absolute levels

| run | XI | captain | net tx gain | MAE | RMSE | hit pts |
|---|---|---|---|---|---|---|
| champ__base | 51.52 | 7.00 | 2.08 | 0.926 | 2.052 | -16 |
| chall__base | 53.77 | 6.38 | 3.08 | 0.931 | 1.953 | -120 |
| comp__base | 54.07 | 7.17 | 3.50 | 0.903 | 1.920 | -104 |
