"""FPL bench auto-substitution and vice-captain fallback for the backtest simulators.

Rules (FPL): starters with 0 minutes are replaced in bench order by bench players who played;
the GK is only swapped with the bench GK; every swap must leave a valid formation
(>=1 GK, >=3 DEF, >=2 MID, >=1 FWD), otherwise that bench player is skipped for that starter.
If the captain plays 0 minutes the vice-captain gets the multiplier; if both blank, nobody does.
"""
from __future__ import annotations

MIN_FORMATION = {"GKP": 1, "DEF": 3, "MID": 2, "FWD": 1}


def valid_formation(positions) -> bool:
    c = {}
    for p in positions:
        c[p] = c.get(p, 0) + 1
    return all(c.get(k, 0) >= v for k, v in MIN_FORMATION.items()) and c.get("GKP", 0) == 1


def apply_autosubs(xi, bench_outfield, bench_gk, pos, minutes):
    """Return (final_xi, subs) where subs is a list of (out_id, in_id). ``pos``/``minutes`` map id ->."""
    order = {"GKP": 0, "DEF": 1, "MID": 2, "FWD": 3}
    xi = sorted(xi, key=lambda i: order[pos[i]])  # FPL processes starters by position
    subs = []
    played = lambda i: float(minutes.get(i, 0) or 0) > 0
    # goalkeeper: only the bench GK
    for k, s in enumerate(xi):
        if pos[s] == "GKP" and not played(s) and bench_gk is not None and played(bench_gk):
            xi[k] = bench_gk; subs.append((s, bench_gk))
    replaced = {o for o, _ in subs}
    for b in bench_outfield:
        if not played(b):
            continue
        for k, s in enumerate(xi):
            if s in replaced or played(s) or pos[s] == "GKP":
                continue
            trial = xi[:k] + [b] + xi[k + 1:]
            if valid_formation(pos[i] for i in trial):
                xi = trial; subs.append((s, b)); replaced.add(s)
                break
    return xi, subs


def captain_points(captain, vice, minutes, actual, multiplier=2):
    """Extra points from the armband (multiplier-1 times the scorer's points) and who got it."""
    played = lambda i: i is not None and float(minutes.get(i, 0) or 0) > 0
    if played(captain):
        return (multiplier - 1) * float(actual.get(captain, 0)), captain
    if played(vice):
        return (multiplier - 1) * float(actual.get(vice, 0)), vice
    return 0.0, None


def score(xi, bench_outfield, bench_gk, captain, vice, pos, minutes, actual, multiplier=2):
    final, subs = apply_autosubs(xi, bench_outfield, bench_gk, pos, minutes)
    extra, armband = captain_points(captain, vice, minutes, actual, multiplier)
    return dict(xi_points_as=sum(float(actual.get(i, 0)) for i in final) + extra,
                n_autosubs=len(subs), vice_used=int(armband is not None and armband != captain),
                armband_pts=extra)
