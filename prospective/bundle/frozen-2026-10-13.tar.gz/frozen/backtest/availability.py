"""Deadline availability from fplcache pre-deadline bootstrap snapshots (backtest default).

For each (season, GW) the harness uses the latest fplcache snapshot taken **strictly before** that
GW's FPL deadline (asserted on load and on fetch). Each player's availability is
``chance_of_playing_next_round / 100`` when FPL published one, else the repo's status multiplier
(a=1, d=0.5, i/s/u/n=0). It scales xP (next and horizon), the B0 captain score and sets
``start_probability``. Turn off with ``backtest.py --no-deadline-availability``.

Only status and chance_of_playing are read. Set-piece order, ownership and price change were tested
and dropped (no gain; see RESULTS_datasources.md).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

D = Path(__file__).resolve().parent
SNAP_DIR = D / "fplcache"
#: == ForecastConfig.status_multiplier
STATUS_MULT = {"a": 1.0, "d": 0.5, "i": 0.0, "s": 0.0, "u": 0.0, "n": 0.0}
SCALED = ("xp_next", "xp_horizon", "xp_b0")


class SnapshotAfterDeadline(AssertionError):
    """A snapshot at or after the deadline would leak post-deadline team news."""


def latest_before(snapshots, deadline):
    """Latest ``(timestamp, name)`` strictly before ``deadline``. Raises if there is none."""
    deadline = pd.Timestamp(deadline)
    cands = [s for s in snapshots if pd.Timestamp(s[0]) < deadline]
    if not cands:
        raise SnapshotAfterDeadline(f"no snapshot strictly before {deadline}")
    best = max(cands, key=lambda s: pd.Timestamp(s[0]))
    assert_before(best[0], deadline)
    return best


def assert_before(snap_ts, deadline) -> None:
    if not pd.Timestamp(snap_ts) < pd.Timestamp(deadline):
        raise SnapshotAfterDeadline(f"snapshot {snap_ts} is not strictly before deadline {deadline}")


def availability(status: pd.Series, chance: pd.Series) -> pd.Series:
    """chance_of_playing/100 where published, else the status multiplier (unknown status -> 1)."""
    by_status = status.map(STATUS_MULT).fillna(1.0)
    return pd.Series(np.where(chance.notna(), chance / 100.0, by_status), index=status.index).clip(0, 1)


def load(snap_dir: Path = SNAP_DIR) -> pd.DataFrame:
    """season, gw, player_id (FPL player code), avail. Asserts every snapshot precedes its deadline."""
    idx = pd.read_csv(snap_dir / "index.csv", parse_dates=["snap_ts", "deadline"])
    for r in idx.itertuples():
        assert_before(r.snap_ts, r.deadline)
    s = pd.read_parquet(snap_dir / "snapshots.parquet", columns=["season", "gw", "player_code", "status", "cop"])
    s["avail"] = availability(s.status, s.cop)
    return s.rename(columns={"player_code": "player_id"})[["season", "gw", "player_id", "avail"]]


def apply(pf: pd.DataFrame, avail: pd.DataFrame) -> pd.DataFrame:
    """Scale a harness player frame by deadline availability. Players with no snapshot row keep 1.0."""
    out = pf.merge(avail, on=["season", "gw", "player_id"], how="left", validate="many_to_one")
    a = out.pop("avail").fillna(1.0)
    for c in SCALED:
        if c in out:
            out[c] = out[c] * a
    out["start_probability"] = a
    return out
