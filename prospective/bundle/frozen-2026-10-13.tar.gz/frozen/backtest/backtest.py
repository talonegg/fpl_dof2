"""Decision-level walk-forward backtest for the FPL DOF engine (review harness, not shipped).

    python backtest/backtest.py --model baseline [--seasons 2024/25 2025/26] [--data-dir DIR]

Reuses the repo's own leakage-safe fold assembly (fpl_dof.forecast.backtest.fold_rows /
training_rows / OUTCOME_COLUMNS strip) and the real transfer engine
(fpl_dof.optimise.transfer.recommend_transfers, which also picks the captain). For each season it
starts from the engine's best legal squad at the first scoreable deadline, then for every later
GW: refit on pre-deadline rows only, predict xPts, let the engine choose transfers + captain from
the held squad, and score the decision against what actually happened.

Model plug-in interface: any object with
    fit(training: pd.DataFrame) -> None          # rows strictly before the deadline, outcomes incl.
    predict(visible: pd.DataFrame) -> array-like # one xPts per row (per fixture), outcomes stripped
registered in MODELS below as name -> factory(config, rules).
"""
from __future__ import annotations

import argparse
import sys

import json
import logging
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from fpl_dof.config import load_config
from fpl_dof.forecast import baselines
from fpl_dof.forecast.backtest import (
    FIXTURE_TEAM, OUTCOME_COLUMNS, deadlines_for, fold_rows, training_rows,
)
from fpl_dof.forecast.features import TARGET, assert_no_look_ahead
from fpl_dof.forecast.xp_v1 import ComponentPredictor
from fpl_dof.optimise.squad import InfeasibleError, optimise_squad
from fpl_dof.optimise.transfer import recommend_transfers
from fpl_dof.rules.models import GameRules
from fpl_dof.squad.state import HeldPlayer, Provenance, SquadState, free_transfers_after


class B0Model:
    """Price + position baseline (the repo's B0), as a cheap sanity alternative."""
    def __init__(self, config, rules, history=None):
        self._m = None
    def fit(self, training):
        self._m = baselines.fit_b0(training, TARGET)
    def predict(self, visible):
        return self._m.predict(visible).to_numpy()


def _flag(cfg, section_path, value):
    """Return a ForecastConfig copy with one nested flag flipped (e.g. ('discrimination','minutes_v2'))."""
    sec, key = section_path
    sub = getattr(cfg.forecast, sec).model_copy(update={key: value})
    return cfg.forecast.model_copy(update={sec: sub})


def CFG():
    cfg, _ = load_config(environ={"FPL_DOF_CONFIG_FILE": "config/ci-backtest.yaml"})
    return cfg


def _vec(kind):
    def make(cfg, rules, history):
        from vector_models import VectorGBM
        return VectorGBM(kind, history)
    return make


# Plug-in registry: name -> factory(cfg, rules, history) returning an object with fit(training)
# and predict(visible) (and optionally set_context(season, gw, deadline)).
MODELS = {
    "baseline": lambda cfg, rules, h: ComponentPredictor(cfg.forecast, rules),
    "b0": B0Model,
    "minutes_v2": lambda cfg, rules, h: ComponentPredictor(_flag(cfg, ("discrimination", "minutes_v2"), True), rules),
    "ts_xg": lambda cfg, rules, h: ComponentPredictor(_flag(cfg, ("expected_goals", "team_strength_from_xg"), True), rules),
    "minutes_v2+ts_xg": lambda cfg, rules, h: ComponentPredictor(
        _flag(cfg.model_copy(update={"forecast": _flag(cfg, ("discrimination", "minutes_v2"), True)}), ("expected_goals", "team_strength_from_xg"), True), rules),
    "vec_noxg": _vec("noxg"),
    "vec_xg": _vec("xg"),
    "vec_xg2": _vec("xg2"),
    "comp_A": lambda cfg, rules, h: __import__("comp_model").CompModel(h),
}


def boot_ci(x, n=2000, seed=0):
    x = np.asarray(pd.Series(x).dropna(), dtype=float)
    if len(x) < 2:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    means = rng.choice(x, size=(n, len(x)), replace=True).mean(axis=1)
    return (float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975)))


def summarise(x):
    s = pd.Series(x, dtype=float).dropna()
    lo, hi = boot_ci(s)
    return {"n": int(len(s)), "mean": float(s.mean()) if len(s) else float("nan"),
            "std": float(s.std()) if len(s) > 1 else float("nan"), "ci_lo": lo, "ci_hi": hi}


def player_frame(merged: pd.DataFrame, pred: np.ndarray) -> pd.DataFrame:
    df = merged.assign(_pred=pred)
    team = df[FIXTURE_TEAM] if FIXTURE_TEAM in df.columns else df["team_id"]
    df = df.assign(_team=pd.to_numeric(team, errors="coerce").fillna(pd.to_numeric(df["team_id"], errors="coerce")))
    g = df.groupby("player_code").agg(position=("position", "first"), team_id=("_team", "first"),
                                      price=("price", "first"), xp_next=("_pred", "sum"),
                                      actual=(TARGET, "sum"), minutes=("minutes", "sum"),
                                      selected_by=("selected_by", "first") if "selected_by" in df else ("_pred", "size"),
                                      web_name=("web_name", "first") if "web_name" in df else ("position", "first"))
    g = g.reset_index().rename(columns={"player_code": "player_id"})
    g = g.dropna(subset=["team_id", "price"])
    g["team_id"] = g["team_id"].astype(int)
    g["player_id"] = g["player_id"].astype(int)
    g["xp_horizon"] = g["xp_next"]
    g["start_probability"] = 1.0
    return g


def load(data_dir, seasons):
    silver = Path(data_dir) / "silver" / "season=2026-27"
    rules = GameRules.model_validate(json.loads((silver / "rules.json").read_text()))
    history = pd.read_parquet(silver / "player_gameweek.parquet")
    history["kickoff_time"] = pd.to_datetime(history["kickoff_time"], utc=True)
    if seasons:
        history = history[history["season"].isin(seasons)]
    return rules, history


def forecast_stage(model_name, seasons, data_dir, out_dir):
    """Walk forward, refit the model (and B0, for the b0-captain policy) per fold, cache player frames."""
    logging.getLogger().setLevel(logging.ERROR)
    cfg = CFG()
    rules, history = load(data_dir, seasons)
    model = MODELS[model_name](cfg, rules, history)
    b0 = B0Model(cfg, rules, history)
    cache, frames = {}, []
    t0 = time.time()
    for season, gw, deadline in deadlines_for(history):
        past = history[history["kickoff_time"] < deadline]
        merged = fold_rows(history, season, gw, deadline, cfg.forecast)
        cache[deadline] = merged
        if not merged.empty:
            assert_no_look_ahead(merged, past, as_of=deadline)
        if past.groupby(["season", "gameweek"]).ngroups < cfg.backtest.minimum_training_matches:
            continue
        training = training_rows(cache, before=deadline)
        if merged.empty or training.empty:
            continue
        visible = merged.drop(columns=list(OUTCOME_COLUMNS) + ["selected_by"], errors="ignore")
        for m in (model, b0):
            if hasattr(m, "set_context"):
                m.set_context(season, gw, deadline)
            m.fit(training)
        pf = player_frame(merged, np.asarray(model.predict(visible), dtype=float))
        pb = player_frame(merged, np.asarray(b0.predict(visible), dtype=float)).set_index("player_id")["xp_next"]
        pf["xp_b0"] = pf.player_id.map(pb).fillna(0.0)
        pf["season"], pf["gw"] = season, gw
        frames.append(pf)
        print(f"{model_name} {season} GW{gw:2d} ({time.time()-t0:.0f}s)", flush=True)
    allpf = pd.concat(frames, ignore_index=True)
    allpf["selected_by"] = pd.to_numeric(allpf["selected_by"], errors="coerce")
    allpf.to_parquet(out_dir / f"cache_{model_name}.parquet")
    return allpf


POLICIES = ["default", "cap_midfwd", "cap_b0"] + [f"calib_t{t}" for t in (0, 0.5, 1, 2, 3)] + [f"calib_t{t}_cap_b0" for t in (0, 0.5, 1, 2, 3)]


def simulate(allpf, policy, model_name, out_dir):
    """Decision layer: the real recommend_transfers, plus optional policy overrides."""
    cfg = CFG()
    rules = GameRules.model_validate(json.loads((Path("/workspace/fpl_data/silver/season=2026-27") / "rules.json").read_text()))
    opt = cfg.optimiser.model_copy(update={"enforce_start_probability_floor": False})
    calib_t = float(policy.split("_t")[1].split("_")[0]) if policy.startswith("calib") else None
    cap_rule = "b0" if policy.endswith("cap_b0") else ("midfwd" if policy == "cap_midfwd" else "engine")
    rows, state, cur = [], None, None
    hist_pred, hist_real = 0.0, 0.0   # realised vs predicted GROSS gain of executed moves, prior GWs only
    for (season, gw), pf in allpf.groupby(["season", "gw"], sort=False):
        pf = pf.reset_index(drop=True)
        fresh = season != cur
        if fresh:
            squad, _ = optimise_squad(pf, rules, opt)
            state = SquadState(entry_id=None, gameweek=gw, players=tuple(
                HeldPlayer(player_id=m.player_id, position=m.position, team_id=m.team_id,
                           current_price=m.price, purchase_price=m.price) for m in squad.players),
                bank=max(0.0, rules.squad.budget - sum(m.price for m in squad.players)),
                free_transfers=1, chips_used=(), provenance=Provenance.DECLARED)
            cur = season
        lookup = pf.set_index("player_id")
        missing = [p for p in state.players if p.player_id not in lookup.index]
        if missing:
            pf = pd.concat([pf, pd.DataFrame([{"player_id": p.player_id, "position": getattr(p.position, "value", p.position),
                "team_id": p.team_id, "price": p.current_price, "xp_next": 0.0, "xp_horizon": 0.0, "xp_b0": 0.0,
                "start_probability": 1.0, "actual": 0.0, "minutes": 0, "selected_by": 0} for p in missing])], ignore_index=True)
            lookup = pf.set_index("player_id")
        state = SquadState(entry_id=None, gameweek=gw, players=tuple(
            HeldPlayer(player_id=p.player_id, position=p.position, team_id=int(lookup.loc[p.player_id, "team_id"]),
                       current_price=float(lookup.loc[p.player_id, "price"]), purchase_price=p.purchase_price)
            for p in state.players), bank=state.bank, free_transfers=state.free_transfers,
            chips_used=(), provenance=Provenance.DECLARED)
        try:
            rec = recommend_transfers(pf, state, rules, cfg.transfers, opt)
        except InfeasibleError as e:
            # FPL grandfathers a squad that exceeds the club cap after a real-world transfer; the
            # engine instead declares it infeasible. Re-run with the excess held players tagged as
            # their own pseudo-club for this week (no new buys from that club are enabled by this).
            from collections import Counter
            cnt = Counter(p.team_id for p in state.players)
            over = {c for c, n in cnt.items() if n > rules.squad.club_limit}
            if not over:
                print(f"{season} GW{gw}: infeasible: {e}"); continue
            remap, seen = {}, Counter()
            for p in state.players:
                if p.team_id in over:
                    seen[p.team_id] += 1
                    if seen[p.team_id] > rules.squad.club_limit:
                        remap[p.player_id] = -p.player_id
            print(f"{season} GW{gw}: club-cap grandfathering applied to {sorted(remap)}")
            pf = pf.copy(); pf.loc[pf.player_id.isin(remap), "team_id"] = pf.player_id.map(remap)
            lookup = pf.set_index("player_id")
            state = SquadState(entry_id=None, gameweek=gw, players=tuple(
                HeldPlayer(player_id=p.player_id, position=p.position, team_id=remap.get(p.player_id, p.team_id),
                           current_price=p.current_price, purchase_price=p.purchase_price) for p in state.players),
                bank=state.bank, free_transfers=state.free_transfers, chips_used=(), provenance=Provenance.DECLARED)
            try:
                rec = recommend_transfers(pf, state, rules, cfg.transfers, opt)
            except InfeasibleError as e2:
                print(f"{season} GW{gw}: infeasible: {e2}"); continue
        roll = rec.roll
        o = rec.recommended
        ratio = float("nan")
        if calib_t is not None and not fresh:
            ratio = min(1.0, max(0.0, hist_real / hist_pred)) if hist_pred > 5 else 1.0
            best, best_v = roll, 0.0
            for opt_ in rec.options:
                if opt_.transfers == 0:
                    continue
                v = ratio * (opt_.gross_expected_points - roll.gross_expected_points) + opt_.hit_points
                if v > calib_t and v > best_v:
                    best, best_v = opt_, v
            o = best
        act = lookup["actual"]
        gain_in = sum(float(act.get(m.player_in_id, 0)) for m in o.moves)
        gain_out = sum(float(act.get(m.player_out_id, 0)) for m in o.moves)
        if not fresh and o.transfers > 0:
            hist_pred += o.gross_expected_points - roll.gross_expected_points
            hist_real += gain_in - gain_out
        xi = list(o.starting)
        if cap_rule == "engine":
            cap = o.captain_id
        elif cap_rule == "midfwd":
            cand = [i for i in xi if lookup.loc[i, "position"] in ("MID", "FWD")] or xi
            cap = max(cand, key=lambda i: float(lookup.loc[i, "xp_next"]))
        else:
            cap = max(xi, key=lambda i: float(lookup.loc[i, "xp_b0"]))
        xi_actual = [float(act.get(i, 0)) for i in xi]
        cap_pts = float(act.get(cap, 0))
        sel = pf.dropna(subset=["selected_by"])
        tmpl = int(sel.sort_values("selected_by", ascending=False).iloc[0]["player_id"]) if len(sel) else None
        rows.append(dict(season=season, gw=gw, fresh_squad=fresh, transfers=o.transfers, hit=o.hit_points,
            net_transfer_gain=gain_in - gain_out + o.hit_points,
            xp_transfer_gain=o.gross_expected_points - roll.gross_expected_points + o.hit_points,
            calib_ratio=ratio, captain_pos=lookup.loc[cap, "position"], captain_pts=cap_pts,
            best_xi_captain_pts=max(xi_actual), best_any_captain_pts=float(pf["actual"].max()),
            template_captain_pts=float(act.get(tmpl, 0)) if tmpl else np.nan,
            xi_points=sum(xi_actual) + cap_pts * (opt.captain_multiplier - 1) + o.hit_points))
        newids = set(o.squad_after)
        old = {p.player_id: p for p in state.players}
        players = tuple(old[i] if i in old else HeldPlayer(player_id=i, position=lookup.loc[i, "position"],
                        team_id=int(lookup.loc[i, "team_id"]), current_price=float(lookup.loc[i, "price"]),
                        purchase_price=float(lookup.loc[i, "price"])) for i in newids)
        state = SquadState(entry_id=None, gameweek=gw + 1, players=players, bank=o.bank_after,
                           free_transfers=free_transfers_after(state.free_transfers, o.transfers, rules),
                           chips_used=(), provenance=Provenance.DECLARED)
    dec = pd.DataFrame(rows)
    dec.to_csv(out_dir / f"decisions_{model_name}__{policy}.csv", index=False)
    return dec


def run(model_name, seasons, data_dir, out_dir, policy="default", deadline_availability=True):
    """Forecast (cached) then decide. ``deadline_availability`` (default on) scales xP and sets start
    probability from the latest fplcache snapshot strictly before each deadline (availability.py);
    off reproduces the old every-player-starts baseline, written under ``<model>_noavail``."""
    cp = out_dir / f"cache_{model_name}.parquet"
    allpf = pd.read_parquet(cp) if cp.exists() else forecast_stage(model_name, seasons, data_dir, out_dir)
    if deadline_availability:
        import availability as av
        allpf = av.apply(allpf, av.load())
    else:
        model_name = f"{model_name}_noavail"
    xp = allpf.rename(columns={"player_id": "player", "xp_next": "xp"})[["season", "gw", "player", "position", "xp", "actual", "minutes"]]
    xp.to_csv(out_dir / f"xp_{model_name}.csv", index=False)
    dec = simulate(allpf, policy, model_name, out_dir)
    if policy == "default":
        dec.to_csv(out_dir / f"decisions_{model_name}.csv", index=False)
    return xp, dec


def report(model_name, xp, dec, out_dir):
    xp = xp.assign(err=xp.xp - xp.actual)
    def gw_err(df):
        return df.groupby(["season", "gw"]).agg(mae=("err", lambda e: e.abs().mean()),
                                               rmse=("err", lambda e: np.sqrt((e ** 2).mean()))).reset_index()
    tr = dec[~dec.fresh_squad]
    dec = dec.assign(cap_vs_best_xi=dec.captain_pts - dec.best_xi_captain_pts,
                     cap_vs_best_any=dec.captain_pts - dec.best_any_captain_pts,
                     cap_vs_template=dec.captain_pts - dec.template_captain_pts)
    L = [f"# Walk-forward backtest — model `{model_name}`", "",
         "Generated by `backtest/backtest.py`. Unit of resampling for CIs = one gameweek (95% bootstrap, 2000 draws).", ""]
    def table(title, frames):
        L.extend([f"## {title}", "", "| metric | scope | n GWs | mean | std | 95% CI |", "|---|---|---|---|---|---|"])
        for name, scope, s in frames:
            m = summarise(s)
            L.append(f"| {name} | {scope} | {m['n']} | {m['mean']:.3f} | {m['std']:.3f} | [{m['ci_lo']:.3f}, {m['ci_hi']:.3f}] |")
        L.append("")
    scopes = [("all", dec, tr, xp)] + [(s, dec[dec.season == s], tr[tr.season == s], xp[xp.season == s]) for s in sorted(dec.season.unique())]
    rows = []
    for sc, d, t, x in scopes:
        e_all, e_60 = gw_err(x), gw_err(x[x.minutes >= 60])
        rows += [("xPts MAE (all players)", sc, e_all.mae), ("xPts RMSE (all players)", sc, e_all.rmse),
                 ("xPts MAE (60+ min)", sc, e_60.mae), ("xPts RMSE (60+ min)", sc, e_60.rmse)]
    table("(c) xPts accuracy, per-GW", rows)
    rows = []
    for sc, d, t, x in scopes:
        rows += [("net transfer gain (pts in − out + hit), all GWs", sc, t.net_transfer_gain),
                 ("net transfer gain, GWs with ≥1 transfer", sc, t[t.transfers > 0].net_transfer_gain),
                 ("predicted xP gain of chosen option", sc, t.xp_transfer_gain),
                 ("hit points taken", sc, t.hit)]
    table("(a) Transfer decisions (realised)", rows)
    rows = []
    for sc, d, t, x in scopes:
        d = d.assign(a=d.captain_pts - d.best_xi_captain_pts, b=d.captain_pts - d.best_any_captain_pts, c=d.captain_pts - d.template_captain_pts)
        rows += [("captain points", sc, d.captain_pts), ("captain − best in XI", sc, d.a),
                 ("captain − best any player", sc, d.b), ("captain − template (most-owned)", sc, d.c),
                 ("XI points incl. captain & hits", sc, d.xi_points)]
    table("(b) Captaincy", rows)
    L += ["## Counts", "", f"- player-GW predictions: {len(xp)}; decision GWs: {len(dec)} ({len(tr)} transfer GWs after squad init)",
          f"- transfers made: {int(tr.transfers.sum())}, hits taken: {int((tr.hit < 0).sum())} GWs, total hit pts {int(tr.hit.sum())}",
          f"- captain hit rate (captain = best in XI): {(dec.captain_pts >= dec.best_xi_captain_pts).mean():.3f}", ""]
    (out_dir / f"RESULTS_{model_name}.md").write_text("\n".join(L))
    print("\n".join(L))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="baseline", choices=sorted(MODELS))
    ap.add_argument("--seasons", nargs="*", default=["2023/24", "2024/25", "2025/26"])  # 2026/27 uses season-local team ids (D-26); the team-strength fit refuses to pool it
    ap.add_argument("--data-dir", default="/workspace/fpl_data")
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--policy", default="default", choices=POLICIES)
    ap.add_argument("--no-deadline-availability", dest="deadline_availability", action="store_false",
                    help="turn off fplcache deadline availability (every player starts with prob 1.0)")
    a = ap.parse_args()
    out = Path(__file__).resolve().parent
    if a.report_only:
        xp, dec = pd.read_csv(out / f"xp_{a.model}.csv"), pd.read_csv(out / f"decisions_{a.model}.csv")
    else:
        xp, dec = run(a.model, a.seasons, a.data_dir, out, a.policy, a.deadline_availability)
    report(a.model if a.deadline_availability else f"{a.model}_noavail", xp, dec, out)
