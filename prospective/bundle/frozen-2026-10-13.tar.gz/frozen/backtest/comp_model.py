"""Candidate A: xPts from separate component models summed with FPL scoring (per position).
Features = Vector's shifted rolling features (vector_models.build_features, all strictly pre-GW)
+ rolling saves/goals/assists/DC. Retrain every 4 GWs on GWs t < test. Components:
  P(play), P(60+|play)          HistGBM classifiers
  goals, assists | play         HistGBM Poisson regressors
  bonus, saves | play           HistGBM Poisson regressors (saves GKP only; E[floor(S/3)] via Poisson pmf)
  clean sheet                   P(CS) = exp(-λ), λ = mean(team rolling xGA, opponent rolling xGF) (opponent xG)
  goals conceded (GKP/DEF)      −E[floor(GC/2)] with GC ~ Poisson(λ), × P(60)
  DC points (2025/26 only)      P(DC threshold reached | play) classifier on 2025/26 prior GWs, 2 pts
Yellow/red cards, own goals, pen saves/misses are omitted (small, noisy)."""
import numpy as np, pandas as pd
from scipy.stats import poisson
from sklearn.ensemble import HistGradientBoostingClassifier as HGC, HistGradientBoostingRegressor as HGR
from vector_models import build_features, BASE, VectorGBM

GOAL = {"GKP": 10, "DEF": 6, "MID": 5, "FWD": 4}
CS = {"GKP": 4, "DEF": 4, "MID": 1, "FWD": 0}
DC_THR = {"DEF": 10}  # others 12 (CBIRT)


class CompModel(VectorGBM):
    RET = 4

    def __init__(self, history):
        super().__init__("xg", history)
        h = history.copy()
        h["dc_hit"] = np.where(h.position == "GKP", 0, (h.defensive_contribution.fillna(0) >= np.where(h.position == "DEF", 10, 12)).astype(float))
        h.loc[h.defensive_contribution.isna(), "dc_hit"] = np.nan
        k = h.season + "|" + h.player_code.astype(str)
        extra = h.assign(key=k).groupby(["key", "gameweek"], as_index=False).agg(
            goals=("goals_scored", "sum"), assists=("assists", "sum"), saves=("saves", "sum"), dc=("dc_hit", "max"))
        self.g = self.g.merge(extra, on=["key", "gameweek"], how="left").set_index(self.g.index)
        G = self.g.groupby("key")
        for c in ("goals", "assists", "saves", "dc"):
            self.g[c + "_l6"] = G[c].shift(1).groupby(self.g.key).rolling(6, min_periods=1).mean().reset_index(0, drop=True)
        self.g["dc_l6"] = self.g["dc_l6"].fillna(-1)  # all-NaN before 2025/26 breaks HGB binning
        self.F = self.F + ["goals_l6", "assists_l6", "saves_l6", "dc_l6"]

    def fit(self, training):
        t = self._t()
        if self.n % self.RET == 0:
            tr = self.g[(self.g.t < t) & (self.g.gp > 0)]
            kw = dict(max_iter=150, learning_rate=0.05, min_samples_leaf=50, early_stopping=False)
            self.models = {}
            for pos in ["GKP", "DEF", "MID", "FWD"]:
                p = tr[tr.position == pos]; pl = p[p.minutes > 0]
                m = {"play": HGC(**kw).fit(p[self.F], (p.minutes > 0).astype(int)),
                     "s60": HGC(**kw).fit(pl[self.F], (pl.minutes >= 60).astype(int)),
                     "bonus": HGR(loss="poisson", **kw).fit(pl[self.F], pl.bonus)}
                if pos != "GKP":
                    m["goals"] = HGR(loss="poisson", **kw).fit(pl[self.F], pl.goals)
                    m["assists"] = HGR(loss="poisson", **kw).fit(pl[self.F], pl.assists)
                    dc = pl[pl.dc.notna()]
                    m["dc"] = HGC(**kw).fit(dc[self.F], dc.dc.astype(int)) if len(dc) > 500 and dc.dc.nunique() > 1 else None
                else:
                    m["saves"] = HGR(loss="poisson", **kw).fit(pl[self.F], pl.saves)
                self.models[pos] = m
        self.n += 1

    def predict(self, visible):
        t = self._t()
        te = self.g[self.g.t == t].copy()
        out = pd.Series(0.0, index=te.index)
        nf = te.nfix.clip(lower=1).to_numpy()
        lam = (((te.xga_r.fillna(1.4) + te.opp_xgf_r.fillna(1.4)) / 2) / nf).clip(0.2, 4).to_numpy()  # per-fixture
        pcs = np.exp(-lam)
        i = np.arange(15)
        egc_pen = np.array([(poisson.pmf(i, l) * (i // 2)).sum() for l in lam])
        for pos, m in self.models.items():
            idx = te.position == pos
            if not idx.any():
                continue
            X = te.loc[idx, self.F]
            pp = m["play"].predict_proba(X)[:, 1]; p6 = m["s60"].predict_proba(X)[:, 1]
            k = idx.to_numpy()
            app = 1 + p6 + p6 * CS[pos] * pcs[k] - (p6 * egc_pen[k] if pos in ("GKP", "DEF") else 0)
            xp = app * nf[k] + m["bonus"].predict(X)
            if pos == "GKP":
                s = m["saves"].predict(X)
                xp = xp + np.array([(poisson.pmf(i, l) * (i // 3)).sum() for l in s])
            else:
                xp = xp + GOAL[pos] * m["goals"].predict(X) + 3 * m["assists"].predict(X)
                if m.get("dc") is not None and te.loc[idx, "season"].iloc[0] >= "2025/26":
                    xp = xp + 2 * m["dc"].predict_proba(X)[:, 1]
            out.loc[idx] = pp * xp
        per = dict(zip(te.player_code, out))
        codes = visible["player_code"]
        return (codes.map(per).fillna(0.0) / codes.map(codes.value_counts())).to_numpy()
