"""Paired per-GW uplift of variants vs the engine baseline. Writes RESULTS_proposals.md."""
import sys
from pathlib import Path
import numpy as np, pandas as pd

D = Path(__file__).resolve().parent
rng = np.random.default_rng(0)

def ci(x):
    x = np.asarray(pd.Series(x).dropna(), float)
    if len(x) < 2: return (np.nan, np.nan)
    b = rng.choice(x, (2000, len(x))).mean(1)
    return float(np.quantile(b, .025)), float(np.quantile(b, .975))

def gw_metrics(model, policy):
    dec = pd.read_csv(D / f"decisions_{model}__{policy}.csv")
    xp = pd.read_csv(D / f"xp_{model}.csv")
    xp["e"] = xp.xp - xp.actual
    buck = pd.cut(xp.actual, [-99, .5, 2.5, 4.5, 999], labels=["0", "1-2", "3-4", "5+"])
    g = xp.groupby(["season", "gw"])
    m = pd.DataFrame({"mae_all": g.e.apply(lambda e: e.abs().mean()), "rmse_all": g.e.apply(lambda e: np.sqrt((e**2).mean()))})
    s60 = xp[xp.minutes >= 60].groupby(["season", "gw"]).e
    m["mae_60"] = s60.apply(lambda e: e.abs().mean()); m["rmse_60"] = s60.apply(lambda e: np.sqrt((e**2).mean()))
    for b in ["0", "1-2", "3-4", "5+"]:
        sb = xp[buck == b].groupby(["season", "gw"]).e
        m[f"mae_{b}"] = sb.apply(lambda e: e.abs().mean()); m[f"rmse_{b}"] = sb.apply(lambda e: np.sqrt((e**2).mean()))
    d = dec.set_index(["season", "gw"])
    m["xi"] = d.xi_points; m["cap"] = d.captain_pts
    m["tx"] = d.net_transfer_gain.where(~d.fresh_squad)
    return m

# metric -> sign so that positive uplift = better
METRICS = [("xi", 1, "XI pts incl C & hits"), ("cap", 1, "captain pts"), ("tx", 1, "net transfer gain"),
           ("mae_all", -1, "xPts MAE all (↓ shown as reduction)"), ("mae_60", -1, "xPts MAE 60+ (reduction)")]
BUCKETS = [(f"{k}_{b}", -1, f"{k.upper()} bucket {b} (reduction)") for b in ["0", "1-2", "3-4", "5+"] for k in ["mae", "rmse"]]

def compare(variants, out_name="RESULTS_proposals.md", notes=""):
    base = gw_metrics("baseline", "default")
    L = ["# Proposal re-scoring vs the fpl_dof2 engine baseline", "", notes, "",
         "Paired per-GW uplift = sign × (variant − baseline); positive = better. 95% bootstrap CI over GWs (2000 draws). "
         "★ = CI excludes 0. Seasons 2023/24 GW5 → 2025/26 GW38 (110 GWs; transfer gain 107 GWs).", "",
         "## Key table (all seasons)", "", "| variant | " + " | ".join(n for _, _, n in METRICS) + " |", "|---" * (len(METRICS) + 1) + "|"]
    per = {}
    for label, model, policy in variants:
        v = gw_metrics(model, policy)
        j = base.join(v, rsuffix="_v", how="inner")
        cells, ps = [], []
        for k, s, _ in METRICS:
            dlt = s * (j[k + "_v"] - j[k]).dropna()
            lo, hi = ci(dlt)
            sig = "★" if (lo > 0 or hi < 0) else ""
            cells.append(f"{dlt.mean():+.3f} [{lo:+.2f}, {hi:+.2f}]{sig}" if len(dlt) else "—")
            ps.append((k, dlt))
        L.append(f"| {label} | " + " | ".join(cells) + " |")
        per[label] = (j, ps)
    L += ["", "## Per-season uplift (mean [95% CI])", ""]
    for label, (j, ps) in per.items():
        L += [f"### {label}", "", "| metric | " + " | ".join(sorted(j.index.get_level_values(0).unique())) + " |", "|---" * 4 + "|"]
        for (k, dlt), (_, _, name) in zip(ps, METRICS):
            cs = []
            for s, x in dlt.groupby(level=0):
                lo, hi = ci(x); cs.append(f"{x.mean():+.2f} [{lo:+.2f}, {hi:+.2f}]{'★' if lo > 0 or hi < 0 else ''}")
            L.append(f"| {name} | " + " | ".join(cs) + " |")
        L.append("")
    L += ["## Forecast error by actual-points bucket (per-GW, reduction vs baseline; positive = variant better)", "",
          "| variant | " + " | ".join(n for _, _, n in BUCKETS) + " |", "|---" * (len(BUCKETS) + 1) + "|"]
    seen = set()
    for label, model, policy in variants:
        if model in seen: continue
        seen.add(model)
        j = base.join(gw_metrics(model, policy), rsuffix="_v", how="inner")
        cs = []
        for k, s, _ in BUCKETS:
            dlt = s * (j[k + "_v"] - j[k]).dropna(); lo, hi = ci(dlt)
            cs.append(f"{dlt.mean():+.3f}{'★' if lo > 0 or hi < 0 else ''}")
        L.append(f"| {model} | " + " | ".join(cs) + " |")
    L += ["", "Baseline absolute levels (per-GW mean): " + ", ".join(f"{k}={base[k].mean():.3f}" for k in ["xi", "cap", "tx", "mae_all", "mae_60", "rmse_all", "rmse_60"]), ""]
    return L
