"""Data-source backtests (local only). Registers the C1 + pre-closing odds variant and runs the
forecast + decision stages.

    ds_backtest.py forecast <model>
    ds_backtest.py decide <cache_model> <policy> <out_name> [--no-deadline-availability]

Deadline availability (availability.py) is applied by default, as in backtest.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pandas as pd
import availability as av
import backtest as bt
from vector_models import VectorGBM
D = Path(__file__).resolve().parent
ODDS = ["odds_gf", "odds_ga", "odds_cs"]


class VectorGBMPlus(VectorGBM):
    """C1 (kind xg2) with extra columns appended to Vector's feature matrix; nothing else changed."""
    def __init__(self, extra, history):
        super().__init__("xg2", history)
        g = self.g
        if set(extra) & set(ODDS):
            tg = pd.read_parquet(D / "fdcouk" / "team_odds.parquet")
            g = g.merge(tg, on=["season", "gameweek", "team_id"], how="left")
        assert len(g) == len(self.g)
        self.g = g.set_index(self.g.index)
        self.F = self.F + list(extra)


bt.MODELS["c1_odds"] = lambda cfg, rules, h: VectorGBMPlus(ODDS, h)


def decide(cache_model, policy, out_name, deadline_availability=True):
    pf = pd.read_parquet(D / f"cache_{cache_model}.parquet")
    if deadline_availability:
        pf = av.apply(pf, av.load())
    xp = pf.rename(columns={"player_id": "player", "xp_next": "xp"})[["season", "gw", "player", "position", "xp", "actual", "minutes"]]
    xp.to_csv(D / f"xp_{out_name}.csv", index=False)
    bt.simulate(pf, policy, out_name, D)


if __name__ == "__main__":
    if sys.argv[1] == "forecast":
        bt.forecast_stage(sys.argv[2], ["2023/24", "2024/25", "2025/26"], "/workspace/fpl_data", D)
    else:
        decide(sys.argv[2], sys.argv[3], sys.argv[4], "--no-deadline-availability" not in sys.argv)
