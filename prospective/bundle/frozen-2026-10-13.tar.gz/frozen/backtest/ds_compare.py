"""Paired per-GW uplift tables for the data-source tests -> RESULTS_datasources.md body tables."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, pandas as pd
import compare as C

MET = [("mae_all", -1, "MAE↓"), ("rmse_all", -1, "RMSE↓"), ("mae_0", -1, "MAE 0"), ("mae_1-2", -1, "MAE 1-2"),
       ("mae_3-4", -1, "MAE 3-4"), ("mae_5+", -1, "MAE 5+"), ("cap", 1, "captain pts/GW"),
       ("xi", 1, "XI pts incl C & hits"), ("tx", 1, "net transfer gain")]


def cell(d):
    d = d.dropna(); lo, hi = C.ci(d)
    return f"{d.mean():+.2f} [{lo:+.2f}, {hi:+.2f}]{'★' if lo > 0 or hi < 0 else ''}"


def table(rows, title):
    L = [f"### {title}", "", "| variant | vs | " + " | ".join(n for _, _, n in MET) + " |", "|---" * (len(MET) + 2) + "|"]
    per = ["", "Per-season (XI pts, captain pts, MAE reduction):", "", "| variant | vs | season | XI | captain | MAE↓ |", "|---|---|---|---|---|---|"]
    for lab, (vm, vp), (bl, bm, bp) in rows:
        j = C.gw_metrics(bm, bp).join(C.gw_metrics(vm, vp), rsuffix="_v", how="inner")
        L.append(f"| {lab} | {bl} | " + " | ".join(cell(s * (j[k + "_v"] - j[k])) for k, s, _ in MET) + " |")
        for season, js in j.groupby(level=0):
            per.append(f"| {lab} | {bl} | {season} | {cell(js.xi_v - js.xi)} | {cell(js.cap_v - js.cap)} | {cell(js.mae_all - js.mae_all_v)} |")
    return L + per + [""]


def levels(names):
    L = ["| run | XI pts/GW | captain pts/GW | net transfer gain/GW | MAE | RMSE | hit pts total |", "|---|---|---|---|---|---|---|"]
    for lab, m, p in names:
        g = C.gw_metrics(m, p); dec = pd.read_csv(C.D / f"decisions_{m}__{p}.csv")
        L.append(f"| {lab} | {g.xi.mean():.2f} | {g.cap.mean():.2f} | {g.tx.mean():.2f} | {g.mae_all.mean():.3f} | {g.rmse_all.mean():.3f} | {int(dec[~dec.fresh_squad].hit.sum())} |")
    return L + [""]


if __name__ == "__main__":
    # L0 = no deadline availability (--no-deadline-availability); L1 = availability on (the default).
    E0, C3_0, C1_0 = ("engine L0", "L0_baseline", "default"), ("C3 L0", "L0_c3", "cap_b0"), ("C1 L0", "L0_c1", "cap_b0")
    E1, C3_1, C1_1 = ("engine L1", "L1_baseline", "default"), ("C3 L1", "L1_c3", "cap_b0"), ("C1 L1", "L1_c1", "cap_b0")
    ODDS = ("C1+odds feats (L1)", "L1_c1_odds", "cap_b0")
    have = lambda x: (C.D / f"decisions_{x[1]}__{x[2]}.csv").exists()
    out = ["## Absolute levels", ""] + levels([x for x in [E0, C3_0, C1_0, E1, C3_1, C1_1, ODDS] if have(x)])
    out += table([("+ deadline availability", ("L1_baseline", "default"), E0),
                  ("+ deadline availability", ("L1_c3", "cap_b0"), C3_0),
                  ("+ deadline availability", ("L1_c1", "cap_b0"), C1_0)], "Step 1: deadline availability (L1 − L0)")
    if have(ODDS):
        out += table([("C1+odds feats", ("L1_c1_odds", "cap_b0"), E1), ("C1+odds feats", ("L1_c1_odds", "cap_b0"), C1_1)],
                     "Step 2: pre-closing odds as C1 features (L1 base)")
    (C.D / "ds_tables.md").write_text("\n".join(out)); print("\n".join(out))
