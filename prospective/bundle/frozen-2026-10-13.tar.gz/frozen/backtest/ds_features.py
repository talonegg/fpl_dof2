"""football-data.co.uk pre-closing odds -> per team-GW implied goals for/against and clean-sheet prob.

Deadline availability lives in availability.py; the other fplcache features (set-piece order,
ownership, price change) were tested and dropped."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import least_squares
from scipy.stats import poisson

D = Path(__file__).resolve().parent
PRE_CLOSING = ["AvgH", "AvgD", "AvgA", "Avg>2.5", "Avg<2.5"]
ALIAS = {"Man United": "Man Utd", "Tottenham": "Spurs", "Sheffield United": "Sheffield Utd", "Nott'm Forest": "Nott'm Forest"}


def _lambdas(ph, pd_, pa, pov):
    def res(x):
        lh, la = np.exp(x)
        i = np.arange(11)
        m = np.outer(poisson.pmf(i, lh), poisson.pmf(i, la))
        H, Dr, A = np.tril(m, -1).sum(), np.trace(m), np.triu(m, 1).sum()
        tot = np.add.outer(i, i)
        ov = m[tot >= 3].sum()
        return [H - ph, A - pa, ov - pov]
    r = least_squares(res, np.log([1.4, 1.2]))
    return np.exp(r.x)


def odds_features(data_dir="/workspace/fpl_data"):
    """Team-GW implied goals for/against and clean-sheet probability from PRE-CLOSING Avg odds.
    Collection rule (football-data.co.uk notes.txt): weekend odds collected Friday afternoon, midweek odds
    Tuesday afternoon. We assume collection at 18:00 Europe/London on that day (end of 'afternoon') and drop a
    fixture if that assumed time is not strictly before the GW's real FPL deadline."""
    idx = pd.read_csv(D / "fplcache" / "index.csv", parse_dates=["deadline"])
    dl = {(r.season, r.gw): r.deadline for r in idx.itertuples()}
    h = pd.read_parquet(Path(data_dir) / "silver" / "season=2026-27" / "player_gameweek.parquet",
                        columns=["season", "gameweek", "team_id", "opponent_team_id", "was_home", "kickoff_time", "fixture_id"])
    fx = h[h.was_home.astype(bool)].drop_duplicates(["season", "fixture_id"])
    out, kept, dropped = [], 0, []
    for code, season in [("2324", "2023/24"), ("2425", "2024/25"), ("2526", "2025/26")]:
        teams = json.loads((D / "fplcache" / f"{season.replace('/', '-')}_gw10.json").read_text())["teams"]
        name2code = {t["name"]: t["code"] for t in teams}
        f = pd.read_csv(D / "fdcouk" / f"E0_{code}.csv")
        f = f[["HomeTeam", "AwayTeam", *PRE_CLOSING]]  # never read closing (…C…) columns
        sfx = fx[fx.season == season]
        for r in f.itertuples(index=False):
            hc, ac = name2code[ALIAS.get(r.HomeTeam, r.HomeTeam)], name2code[ALIAS.get(r.AwayTeam, r.AwayTeam)]
            m = sfx[(sfx.team_id == hc) & (sfx.opponent_team_id == ac)]
            assert len(m) == 1, (season, r.HomeTeam, r.AwayTeam)
            m = m.iloc[0]
            gw = int(m.gameweek)
            date = pd.Timestamp(m.kickoff_time).tz_convert("Europe/London").normalize()
            wd = date.weekday()  # Mon=0
            back = (wd - 4) % 7 if wd in (4, 5, 6, 0) else (wd - 1) % 7  # Fri for Fri-Mon, Tue for Tue-Thu
            coll = (date - pd.Timedelta(days=back)).replace(hour=18).tz_convert("UTC")
            row = dict(season=season, gameweek=gw, fixture_id=m.fixture_id, home=hc, away=ac, coll=coll, deadline=dl.get((season, gw)))
            if row["deadline"] is None or not coll < row["deadline"]:
                dropped.append(row); continue
            ih, idr, ia = 1 / r.AvgH, 1 / r.AvgD, 1 / r.AvgA
            s3 = ih + idr + ia
            out.append(dict(row, ph=ih / s3, pd=idr / s3, pa=ia / s3, _o=None))
        # vectorised over/under (itertuples mangles '>' names)
        f2 = f.assign(hc=f.HomeTeam.map(lambda x: name2code[ALIAS.get(x, x)]), ac=f.AwayTeam.map(lambda x: name2code[ALIAS.get(x, x)]))
        f2["pov"] = (1 / f2["Avg>2.5"]) / (1 / f2["Avg>2.5"] + 1 / f2["Avg<2.5"])
        pov = {(a, b): p for a, b, p in zip(f2.hc, f2.ac, f2.pov)}
        for o in out:
            if o["season"] == season:
                o["_o"] = pov[(o["home"], o["away"])]
    o = pd.DataFrame(out)
    lam = np.array([_lambdas(a, b, c, d) for a, b, c, d in zip(o.ph, o.pd, o.pa, o._o)])
    o["lh"], o["la"] = lam[:, 0], lam[:, 1]
    team = pd.concat([o.assign(team_id=o.home, gf=o.lh, ga=o.la), o.assign(team_id=o.away, gf=o.la, ga=o.lh)])
    team["cs"] = np.exp(-team.ga)
    tg = team.groupby(["season", "gameweek", "team_id"], as_index=False).agg(odds_gf=("gf", "sum"), odds_ga=("ga", "sum"), odds_cs=("cs", "sum"))
    dr = pd.DataFrame(dropped)
    return tg, o, dr


if __name__ == "__main__":
    tg, o, dr = odds_features()
    print("kept fixtures", len(o), "dropped", len(dr)); print(dr.groupby("season").size() if len(dr) else "")
    tg.to_parquet(D / "fdcouk" / "team_odds.parquet"); dr.to_csv(D / "fdcouk" / "dropped.csv", index=False)
