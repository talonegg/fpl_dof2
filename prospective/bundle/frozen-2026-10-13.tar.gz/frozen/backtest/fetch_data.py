"""Fetch the backtest's external data (not committed; see .gitignore). Polite and cached: files
already on disk are never re-downloaded.

    python backtest/fetch_data.py [--data-dir /workspace/fpl_data]

1. fplcache (github.com/Randdalf/fplcache, The Unlicense; the JSON is FPL's own bootstrap data):
   lists snapshot files with a blobless clone, picks the latest snapshot strictly before each GW
   deadline (asserted again against the snapshot's own events[gw].deadline_time), downloads only
   those (~115 files), and writes fplcache/index.csv + fplcache/snapshots.parquet (status and
   chance_of_playing only).
2. football-data.co.uk Premier League CSVs for 2023/24-2025/26 + notes.txt into fdcouk/, then the
   pre-closing-odds team table fdcouk/team_odds.parquet (ds_features.py).
"""
from __future__ import annotations

import argparse
import json
import lzma
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import availability as av  # noqa: E402

D = Path(__file__).resolve().parent
UA = {"User-Agent": "fpl-dof-backtest (+https://github.com/talonegg/fpl_dof2)"}
SEASONS = {"2023/24": "2324", "2024/25": "2425", "2025/26": "2526"}


def _get(url: str) -> bytes:
    time.sleep(1.0)  # one request a second at most
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
        return r.read()


def _snap_ts(path: str) -> pd.Timestamp:
    _, y, m, d, hm = path.split("/")
    hm = hm.split(".")[0]
    return pd.Timestamp(int(y), int(m), int(d), int(hm[:2]), int(hm[2:]), tz="UTC")


def fetch_fplcache(data_dir: Path) -> None:
    out_dir = av.SNAP_DIR
    out_dir.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(["git", "clone", "-q", "--filter=blob:none", "--no-checkout",
                        "https://github.com/Randdalf/fplcache", tmp], check=True)
        files = subprocess.run(["git", "-C", tmp, "ls-tree", "-r", "--name-only", "HEAD", "cache"],
                               capture_output=True, text=True, check=True).stdout.split()
    snaps = sorted((_snap_ts(f), f) for f in files)
    h = pd.read_parquet(Path(data_dir) / "silver" / "season=2026-27" / "player_gameweek.parquet",
                        columns=["season", "gameweek", "kickoff_time"])
    h = h[h.season.isin(list(SEASONS))]
    first_ko = h.groupby(["season", "gameweek"]).kickoff_time.min()
    idx, rows = [], []
    for (season, gw), ko in first_ko.items():
        ko = pd.Timestamp(ko).tz_convert("UTC")
        bound = ko  # the deadline is always before first kickoff; refined below
        while True:
            t, f = av.latest_before(snaps, bound)
            out = out_dir / f"{season.replace('/', '-')}_gw{gw:02d}.json"
            if not out.exists():
                out.write_text(lzma.decompress(_get(f"https://raw.githubusercontent.com/Randdalf/fplcache/HEAD/{f}")).decode())
            j = json.loads(out.read_text())
            ev = {e["id"]: e for e in j["events"]}
            deadline = pd.Timestamp(ev[gw]["deadline_time"])
            if t < deadline and not ev[gw]["finished"]:
                break
            out.unlink()
            bound = deadline  # latest strictly before the real deadline
        assert abs((deadline - ko).total_seconds()) < 6 * 3600, (season, gw, deadline, ko)  # right season
        av.assert_before(t, deadline)
        idx.append(dict(season=season, gw=gw, snapshot=f, snap_ts=t, deadline=deadline,
                        staleness_h=(deadline - t).total_seconds() / 3600))
        for e in j["elements"]:
            rows.append(dict(season=season, gw=gw, player_code=e["code"], status=e["status"],
                             cop=e["chance_of_playing_next_round"]))
        print(idx[-1], flush=True)
    pd.DataFrame(idx).to_csv(out_dir / "index.csv", index=False)
    pd.DataFrame(rows).to_parquet(out_dir / "snapshots.parquet")


def fetch_fdcouk() -> None:
    out_dir = D / "fdcouk"
    out_dir.mkdir(exist_ok=True)
    for code in SEASONS.values():
        p = out_dir / f"E0_{code}.csv"
        if not p.exists():
            p.write_bytes(_get(f"https://www.football-data.co.uk/mmz4281/{code}/E0.csv"))
    if not (out_dir / "notes.txt").exists():
        (out_dir / "notes.txt").write_bytes(_get("https://www.football-data.co.uk/notes.txt"))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="/workspace/fpl_data")
    a = ap.parse_args()
    fetch_fplcache(Path(a.data_dir))
    fetch_fdcouk()
    import ds_features
    tg, o, dr = ds_features.odds_features(a.data_dir)
    tg.to_parquet(D / "fdcouk" / "team_odds.parquet")
    dr.to_csv(D / "fdcouk" / "dropped.csv", index=False)
    print("odds fixtures kept", len(o), "dropped", len(dr))
