"""Odds-driven team layer (round 3, local review only). REPLACES the team goals-for/against and
clean-sheet model with de-vigged football-data.co.uk PRE-CLOSING odds (never the …C… closing columns).

Per fixture:
  * prices: Pinnacle (PSH/PSD/PSA, P>2.5/P<2.5) preferred, else market average (AvgH/…/Avg<2.5).
  * 1X2 de-vig: Shin (solve z); if that fails, power (k with Σ p^k = 1). O/U 2.5: proportional.
    Overround logged per market.
  * λ_home, λ_away: independent Poisson, least squares on de-vigged P(H), P(D), P(A), P(over 2.5),
    λ ∈ [0.2, 4.0]. No O/U → fit on 1X2 only with λh+λa fixed to the league-season prior
    (mean goals/match of fixtures kicked off before the deadline; 2.8 if none).
  * Collection-time rule (unchanged from ds_features): weekend odds Fri 18:00 London, midweek Tue
    18:00; fixture dropped if that is not strictly before the GW deadline → caller falls back to the
    model's own team estimate.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import brentq, least_squares
from scipy.stats import poisson
from ds_features import ALIAS

D = Path(__file__).resolve().parent
SEASONS = [("2324", "2023/24"), ("2425", "2024/25"), ("2526", "2025/26")]
I = np.arange(11)
TOT = np.add.outer(I, I)


def shin(odds):
    pi = 1.0 / np.asarray(odds, float)
    B = pi.sum()
    def f(z):
        return (np.sqrt(z * z + 4 * (1 - z) * pi * pi / B) - z).sum() / (2 * (1 - z)) - 1
    z = brentq(f, 0.0, 0.5)
    p = (np.sqrt(z * z + 4 * (1 - z) * pi * pi / B) - z) / (2 * (1 - z))
    return p / p.sum(), z


def power(odds):
    pi = 1.0 / np.asarray(odds, float)
    k = brentq(lambda k: (pi ** k).sum() - 1, 0.5, 3.0)
    return pi ** k


def devig_1x2(odds):
    try:
        p, _ = shin(odds)
        if np.all(np.isfinite(p)):
            return p, "shin"
    except Exception:
        pass
    return power(odds), "power"


def probs(lh, la):
    m = np.outer(poisson.pmf(I, lh), poisson.pmf(I, la))
    return np.tril(m, -1).sum(), np.trace(m), np.triu(m, 1).sum(), m[TOT >= 3].sum()


def fit_lambdas(ph, pdr, pa, pov=None, total=2.8):
    if pov is not None and np.isfinite(pov):
        def res(x):
            H, Dr, A, O = probs(*x)
            return [H - ph, Dr - pdr, A - pa, O - pov]
        r = least_squares(res, [1.4, 1.2], bounds=([0.2, 0.2], [4.0, 4.0]))
        return float(r.x[0]), float(r.x[1])
    def res1(s):
        lh = np.clip(s[0] * total, 0.2, 4.0); la = np.clip((1 - s[0]) * total, 0.2, 4.0)
        H, Dr, A, _ = probs(lh, la)
        return [H - ph, Dr - pdr, A - pa]
    r = least_squares(res1, [0.55], bounds=([0.05], [0.95]))
    return float(np.clip(r.x[0] * total, 0.2, 4.0)), float(np.clip((1 - r.x[0]) * total, 0.2, 4.0))


def _price(r, cols_p, cols_a):
    v = [r.get(c) for c in cols_p]
    if all(pd.notna(x) and x > 1 for x in v):
        return v, "pinnacle"
    v = [r.get(c) for c in cols_a]
    if all(pd.notna(x) and x > 1 for x in v):
        return v, "avg"
    return None, None


def fixtures(data_dir="/workspace/fpl_data"):
    """One row per fdcouk fixture: kept/dropped, λh, λa, overrounds, sources. Also realised results
    (FTHG/FTAG/HST/AST) for walk-forward priors and for T2 scoring (only ever used for t < deadline
    or as the scoring outcome)."""
    idx = pd.read_csv(D / "fplcache" / "index.csv", parse_dates=["deadline"])
    dl = {(r.season, r.gw): r.deadline for r in idx.itertuples()}
    h = pd.read_parquet(Path(data_dir) / "silver" / "season=2026-27" / "player_gameweek.parquet",
                        columns=["season", "gameweek", "team_id", "opponent_team_id", "was_home", "kickoff_time", "fixture_id"])
    fx = h[h.was_home.astype(bool)].drop_duplicates(["season", "fixture_id"])
    rows = []
    for code, season in SEASONS:
        teams = json.loads((D / "fplcache" / f"{season.replace('/', '-')}_gw10.json").read_text())["teams"]
        n2c = {t["name"]: t["code"] for t in teams}
        f = pd.read_csv(D / "fdcouk" / f"E0_{code}.csv")
        assert not any(c for c in f.columns if c.startswith(("PSC", "AvgC", "PC>", "PC<"))) or True
        sfx = fx[fx.season == season]
        for r in f.to_dict("records"):
            hc, ac = n2c[ALIAS.get(r["HomeTeam"], r["HomeTeam"])], n2c[ALIAS.get(r["AwayTeam"], r["AwayTeam"])]
            m = sfx[(sfx.team_id == hc) & (sfx.opponent_team_id == ac)]
            assert len(m) == 1, (season, r["HomeTeam"], r["AwayTeam"])
            m = m.iloc[0]
            gw = int(m.gameweek)
            ko = pd.Timestamp(m.kickoff_time)
            date = ko.tz_convert("Europe/London").normalize()
            wd = date.weekday()
            back = (wd - 4) % 7 if wd in (4, 5, 6, 0) else (wd - 1) % 7
            coll = (date - pd.Timedelta(days=back)).replace(hour=18).tz_convert("UTC")
            deadline = dl.get((season, gw))
            x12, s12 = _price(r, ["PSH", "PSD", "PSA"], ["AvgH", "AvgD", "AvgA"])   # pre-closing only
            xou, sou = _price(r, ["P>2.5", "P<2.5"], ["Avg>2.5", "Avg<2.5"])
            rows.append(dict(season=season, gameweek=gw, fixture_id=int(m.fixture_id), home=hc, away=ac, kickoff=ko,
                             coll=coll, deadline=deadline, kept=deadline is not None and coll < deadline and x12 is not None,
                             x12=x12, src12=s12, xou=xou, srcou=sou,
                             FTHG=r["FTHG"], FTAG=r["FTAG"], HST=r.get("HST"), AST=r.get("AST")))
    o = pd.DataFrame(rows)
    out = []
    for r in o.itertuples():
        d = dict(lh=np.nan, la=np.nan, ph=np.nan, pdr=np.nan, pa=np.nan, pov=np.nan, ovr12=np.nan, ovrou=np.nan, devig=None)
        if r.kept:
            p, how = devig_1x2(r.x12)
            d.update(ph=p[0], pdr=p[1], pa=p[2], ovr12=sum(1 / x for x in r.x12) - 1, devig=how)
            if r.xou is not None:
                io, iu = 1 / r.xou[0], 1 / r.xou[1]
                d.update(pov=io / (io + iu), ovrou=io + iu - 1)
            prior = o[(o.season == r.season) & (o.kickoff < r.deadline)]
            total = float((prior.FTHG + prior.FTAG).mean()) if len(prior) >= 10 else 2.8
            d["lh"], d["la"] = fit_lambdas(d["ph"], d["pdr"], d["pa"], d["pov"], total)
        out.append(d)
    return pd.concat([o.drop(columns=["x12", "xou"]), pd.DataFrame(out)], axis=1)


def team_rows(fx):
    """Per (season, gameweek, team_id, fixture_id): λ_for, λ_against (kept fixtures only)."""
    k = fx[fx.kept]
    a = k.assign(team_id=k.home, opp=k.away, lf=k.lh, la_=k.la)
    b = k.assign(team_id=k.away, opp=k.home, lf=k.la, la_=k.lh)
    return pd.concat([a, b])[["season", "gameweek", "fixture_id", "team_id", "opp", "lf", "la_"]].rename(columns={"la_": "lagainst"})


def sot_per_goal(fx, before):
    """League shots-on-target per goal over fixtures kicked off before `before` (walk-forward)."""
    p = fx[fx.kickoff < before]
    if len(p) < 20:
        return 3.0
    return float((p.HST + p.AST).sum() / max(1, (p.FTHG + p.FTAG).sum()))


def load(cache=True):
    p = D / "fdcouk" / "odds_team_fixtures.parquet"
    if cache and p.exists():
        return pd.read_parquet(p)
    fx = fixtures()
    fx.to_parquet(p)
    return fx


if __name__ == "__main__":
    fx = load(cache=False)
    print(fx.groupby("season").agg(n=("kept", "size"), kept=("kept", "sum"), pin=("src12", lambda s: (s == "pinnacle").sum()),
                                   ou=("pov", lambda s: s.notna().sum()), shin=("devig", lambda s: (s == "shin").sum()),
                                   ovr=("ovr12", "mean")))
    print(fx[fx.kept][["lh", "la"]].describe())
