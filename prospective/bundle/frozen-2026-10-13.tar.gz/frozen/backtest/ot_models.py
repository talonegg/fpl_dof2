"""Round-3 model variants using the odds team layer (odds_team.py). Local review only.

  champ_ot : engine (minutes_v2) + C3, with xp_v1.fixture_opposition swapped to odds λ (CS, goals
             conceded, attacking fixture factor) for fixtures whose pre-closing odds were collected
             before the current deadline; otherwise the engine's own team-strength opposition.
  c1_ot    : C1 (vec_xg2) with team xG features (xgf_r, xga_r, opp_xgf_r, opp_xga_r) REPLACED by
             implied per-fixture goals for/against where all of the team-GW's fixtures have odds.
  comp_ot  : A with team layer from odds: CS=exp(-λ_opp), −E[floor(GC/2)], player goals =
             λ_team×xG share (shrunk to position/price prior), assists = λ_team×xA share×0.75,
             GK saves via λ_opp×(SoT/goal−1) saves ~ Poisson → E[floor(S/3)]; bonus/DC/P(play)/P(60)
             as in A. Team-GW not fully covered by odds → A's own estimate for that player-GW.
"""
from __future__ import annotations
import math
import numpy as np, pandas as pd
from scipy.stats import poisson
import backtest as bt
import odds_team as ot
from comp_model import CompModel, GOAL, CS
from vector_models import VectorGBM

FX = ot.load()
TR = ot.team_rows(FX)
ASSIST_FRAC = 0.75
I15 = np.arange(15)


def _team_gw():
    """(season, gameweek, team_id) -> n odds fixtures, Σλ_for, Σλ_against, ΣCS, Σ E[floor(GC/2)]."""
    t = TR.copy()
    t["cs"] = np.exp(-t.lagainst)
    t["gcpen"] = [(poisson.pmf(I15, l) * (I15 // 2)).sum() for l in t.lagainst]
    return t.groupby(["season", "gameweek", "team_id"], as_index=False).agg(
        n_odds=("fixture_id", "size"), o_gf=("lf", "sum"), o_ga=("lagainst", "sum"), o_cs=("cs", "sum"),
        o_gcpen=("gcpen", "sum"), o_ga_list=("lagainst", list))


TG = _team_gw()


# ---------------- champion swap ----------------
class ChampOT:
    def __init__(self, cfg, rules, h):
        from fpl_dof.forecast import xp_v1
        self.inner = bt.MODELS["minutes_v2"](cfg, rules, h)
        self.xp_v1, self.orig = xp_v1, xp_v1.fixture_opposition
        k = FX[FX.kept]
        self.lam = {(r.season, r.home, r.away): (r.lh, r.la, r.coll) for r in k.itertuples()}
        self.used = self.fallback = 0
        me = self

        def patched(models, *, team_id, opponent_id, at_home):
            key = (me.season, int(team_id), int(opponent_id)) if at_home else (me.season, int(opponent_id), int(team_id))
            v = me.lam.get(key)
            if v is None or not v[2] < me.deadline:
                me.fallback += 1
                return me.orig(models, team_id=team_id, opponent_id=opponent_id, at_home=at_home)
            me.used += 1
            lf, la = (v[0], v[1]) if at_home else (v[1], v[0])
            ts = models.team_strength
            own = ts.league_mean_goals * ts.attack.get(int(team_id), 1.0)
            return xp_v1.Opposition(clean_sheet_probability=math.exp(-la), goals_conceded_mean=la,
                                    attacking_fixture_factor=float(np.clip(lf / max(own, 0.05), 0.3, 3.0)))
        xp_v1.fixture_opposition = patched
        from fpl_dof.forecast import horizon
        horizon.fixture_opposition = patched

    def set_context(self, season, gw, deadline):
        self.season, self.gw, self.deadline = season, gw, pd.Timestamp(deadline)
        if hasattr(self.inner, "set_context"):
            self.inner.set_context(season, gw, deadline)

    def fit(self, training):
        self.inner.fit(training)

    def predict(self, visible):
        return self.inner.predict(visible)


# ---------------- C1 swap ----------------
class C1OT(VectorGBM):
    def __init__(self, h):
        super().__init__("xg2", h)
        g = self.g.merge(TG[["season", "gameweek", "team_id", "n_odds", "o_gf", "o_ga"]], on=["season", "gameweek", "team_id"], how="left")
        g.index = self.g.index
        full = (g.n_odds == g.nfix).to_numpy()
        nf = g.nfix.clip(lower=1)
        self.coverage = float(full.mean())
        for c, v in [("xgf_r", g.o_gf / nf), ("xga_r", g.o_ga / nf), ("opp_xgf_r", g.o_ga / nf), ("opp_xga_r", g.o_gf / nf)]:
            g[c] = np.where(full, v, g[c])
        self.g = g.drop(columns=["n_odds", "o_gf", "o_ga"])


# ---------------- A with odds team layer ----------------
class CompOT(CompModel):
    K_SHRINK = 3.0

    def __init__(self, h):
        super().__init__(h)
        d = h.copy()
        d["t"] = d.season.map({s: i for i, s in enumerate(sorted(d.season.unique()))}) * 100 + d.gameweek
        tx = d.groupby(["season", "t", "team_id"], as_index=False)[["expected_goals", "expected_assists"]].sum().sort_values("t")
        for c in ["expected_goals", "expected_assists"]:
            tx["team_" + c + "_l6"] = tx.groupby(["season", "team_id"])[c].transform(lambda x: x.shift(1).rolling(6, min_periods=1).mean())
        g = self.g.merge(tx[["season", "t", "team_id", "team_expected_goals_l6", "team_expected_assists_l6"]], on=["season", "t", "team_id"], how="left")
        g = g.merge(TG, on=["season", "gameweek", "team_id"], how="left")
        g.index = self.g.index
        pl = g.played_last  # noqa: F841 (kept for clarity)
        play_frac = g.minutes_l6.fillna(0) / 90.0
        play_frac = play_frac.clip(lower=0.1)
        g["xg_share"] = (g.expected_goals_l6 / g.team_expected_goals_l6.clip(lower=0.1) / play_frac).clip(0, 1)
        g["xa_share"] = (g.expected_assists_l6 / g.team_expected_assists_l6.clip(lower=0.1) / play_frac).clip(0, 1)
        g["n_obs"] = g.groupby("key").cumcount().clip(upper=6)
        g["band"] = pd.cut(g.price, [0, 4.75, 5.75, 7.25, 9.25, 99], labels=False)
        g["odds_full"] = (g.n_odds == g.nfix)
        self.g = g
        self.used = self.fallback = 0
        self.fx = FX

    def fit(self, training):
        super().fit(training)
        t = self._t()
        tr = self.g[(self.g.t < t) & (self.g.minutes > 0)]
        self.prior = tr.groupby(["position", "band"])[["xg_share", "xa_share"]].mean()
        before = self.deadline
        self.r_sot = ot.sot_per_goal(self.fx, before)

    def set_context(self, season, gw, deadline):
        super().set_context(season, gw, deadline)
        self.deadline = pd.Timestamp(deadline)

    def _shrunk(self, te, c):
        pri = te.set_index(["position", "band"]).index.map(self.prior[c].to_dict()).to_numpy(dtype=float)
        pri = np.nan_to_num(pri, nan=0.0)
        n = te.n_obs.to_numpy(dtype=float)
        x = np.nan_to_num(te[c].to_numpy(dtype=float), nan=0.0)
        return (n * x + self.K_SHRINK * pri) / (n + self.K_SHRINK)

    def predict(self, visible):
        base = pd.Series(super().predict(visible), index=visible.index)  # A's own (fallback)
        t = self._t()
        te = self.g[self.g.t == t].copy()
        out = {}
        for pos, m in self.models.items():
            e = te[(te.position == pos) & te.odds_full]
            if e.empty:
                continue
            X = e[self.F]
            pp = m["play"].predict_proba(X)[:, 1]; p6 = m["s60"].predict_proba(X)[:, 1]
            nf = e.nfix.clip(lower=1).to_numpy()
            app = nf * (1 + p6) + p6 * CS[pos] * e.o_cs.to_numpy()
            if pos in ("GKP", "DEF"):
                app = app - p6 * e.o_gcpen.to_numpy()
            xp = app + m["bonus"].predict(X)
            if pos == "GKP":
                sv = np.array([sum((poisson.pmf(I15, l * max(self.r_sot - 1, 0.5)) * (I15 // 3)).sum() for l in ls) for ls in e.o_ga_list])
                xp = xp + sv
            else:
                xp = xp + GOAL[pos] * e.o_gf.to_numpy() * self._shrunk(e, "xg_share") \
                        + 3 * e.o_gf.to_numpy() * self._shrunk(e, "xa_share") * ASSIST_FRAC
                if m.get("dc") is not None and e.season.iloc[0] >= "2025/26":
                    xp = xp + 2 * m["dc"].predict_proba(X)[:, 1]
            out.update(dict(zip(e.player_code, pp * xp)))
        codes = visible["player_code"]
        v = codes.map(out) / codes.map(codes.value_counts())
        self.used += int(v.notna().sum()); self.fallback += int(v.isna().sum())
        return v.fillna(base).to_numpy()


bt.MODELS["champ_ot"] = lambda cfg, rules, h: ChampOT(cfg, rules, h)
bt.MODELS["c1_ot"] = lambda cfg, rules, h: C1OT(h)
bt.MODELS["comp_ot"] = lambda cfg, rules, h: CompOT(h)

if __name__ == "__main__":
    import sys
    from pathlib import Path
    name = sys.argv[1]
    bt.forecast_stage(name, ["2023/24", "2024/25", "2025/26"], "/workspace/fpl_data", Path(bt.__file__).resolve().parent)
