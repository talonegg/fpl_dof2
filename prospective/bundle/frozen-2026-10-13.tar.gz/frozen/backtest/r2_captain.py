"""F/G captain policies, applied post hoc to the XI each arm actually fielded (captain never feeds
back into transfers in this harness, so this is exact). All fitted rules are walk-forward."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import HistGradientBoostingRegressor as HGR
D = Path(__file__).resolve().parent; R2 = D / "r2"
T = {"2023/24": 0, "2024/25": 1, "2025/26": 2}


def scores(pf):
    pf = pf.copy(); pf["t"] = pf.season.map(T) * 100 + pf.gw
    o = pd.read_parquet(D / "fdcouk" / "team_odds.parquet").rename(columns={"gameweek": "gw"})
    pf = pf.merge(o, on=["season", "gw", "team_id"], how="left")
    pf["has_odds"] = pf.odds_gf.notna().astype(float)
    for c in ("odds_gf", "odds_cs"):
        pf[c] = pf[c].fillna(0)
    pf["b0gf"], pf["b0cs"] = pf.xp_b0 * pf.odds_gf, pf.xp_b0 * pf.odds_cs
    GF = ["xp_b0", "b0gf", "b0cs", "has_odds"]
    out, n, mods = [], 0, {}
    for t in sorted(pf.t.unique()):
        cur = pf[pf.t == t].copy()
        pr = pf[(pf.t < t)]
        cur["p_haul"] = cur["q75"] = cur["g_odds"] = np.nan
        if pr.t.nunique() >= 3:
            if n % 4 == 0:
                mods = {}
                for pos in pf.position.unique():
                    p = pr[pr.position == pos]
                    p2 = p.sample(min(len(p), 60000), random_state=0)
                    mods[pos] = (LogisticRegression().fit(p[["xp_next", "xp_b0"]], (p.actual >= 5).astype(int)),
                                 HGR(loss="quantile", quantile=0.75, max_iter=100).fit(p2[["xp_next", "xp_b0"]], p2.actual),
                                 LinearRegression().fit(p[GF], p.actual))
            n += 1
            for pos, (lr, q, g) in mods.items():
                m = cur.position == pos
                if m.any():
                    cur.loc[m, "p_haul"] = lr.predict_proba(cur.loc[m, ["xp_next", "xp_b0"]])[:, 1]
                    cur.loc[m, "q75"] = q.predict(cur.loc[m, ["xp_next", "xp_b0"]])
                    cur.loc[m, "g_odds"] = g.predict(cur.loc[m, GF])
        out.append(cur)
    return pd.concat(out)


def choose(xi, rule):
    if rule == "C3_b0" or xi[rule if rule in xi else "xp_b0"].isna().all():
        return xi.xp_b0.idxmax()
    if rule == "F3_mean_tb":
        top = xi.xp_next.max()
        near = xi[(xi.xp_next >= top - 0.5) & xi.position.isin(["MID", "FWD"]) & (xi.price >= 9.0)]
        return near.price.idxmax() if len(near) else xi.xp_next.idxmax()
    if rule == "mean_xp":
        return xi.xp_next.idxmax()
    return xi[rule].idxmax()


RULES = {"C3_b0": "C3_b0", "F1_p_haul": "p_haul", "F2_q75": "q75", "F3_mean_tb": "F3_mean_tb", "mean_xp": "mean_xp", "G_odds": "g_odds"}


def run(name):
    pf = scores(pd.read_parquet(R2 / f"pf_{name}.parquet"))
    xi = pd.read_csv(R2 / f"xi_{name}.csv").merge(pf, on=["season", "gw", "player_id"], how="left")
    dec = pd.read_csv(R2 / f"dec_{name}.csv")
    for label, rule in RULES.items():
        caps = {k: float(g.loc[choose(g, rule), "actual"]) if g.actual.notna().any() else 0.0 for k, g in xi.groupby(["season", "gw"])}
        d = dec.copy()
        d["captain_pts"] = [caps.get((s, w), 0.0) for s, w in zip(d.season, d.gw)]
        d["xi_points"] = d.base_xi + d.captain_pts
        d.to_csv(R2 / f"dec_{name}__cap_{label}.csv", index=False)
        print(name, label, round(d.captain_pts.mean(), 3), round(d.xi_points.mean(), 2))


if __name__ == "__main__":
    for n in sys.argv[1:]:
        run(n)
