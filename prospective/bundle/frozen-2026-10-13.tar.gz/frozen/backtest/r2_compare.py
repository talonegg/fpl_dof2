"""Paired per-GW comparisons for round 2 -> table rows (used to build RESULTS_round2.md)."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
D = Path(__file__).resolve().parent; R2 = D / "r2"
rng = np.random.default_rng(0)
SEAS = ["2023/24", "2024/25", "2025/26"]


def ci(x):
    x = np.asarray(pd.Series(x).dropna(), float)
    if len(x) < 2: return (np.nan, np.nan)
    b = rng.choice(x, (2000, len(x))).mean(1)
    return float(np.quantile(b, .025)), float(np.quantile(b, .975))


def metrics(dec_name, pf_name):
    d = pd.read_csv(R2 / f"dec_{dec_name}.csv").set_index(["season", "gw"])
    pf = pd.read_parquet(R2 / f"pf_{pf_name}.parquet")
    pf["e"] = pf.xp_next - pf.actual
    pf["b"] = pd.cut(pf.actual, [-99, .5, 2.5, 4.5, 999], labels=["0", "1-2", "3-4", "5+"])
    g = pf.groupby(["season", "gw"]).e
    m = pd.DataFrame({"mae": g.apply(lambda e: e.abs().mean()), "rmse": g.apply(lambda e: np.sqrt((e ** 2).mean()))})
    for b in ["0", "1-2", "3-4", "5+"]:
        s = pf[pf.b == b].groupby(["season", "gw"]).e
        m["mae_" + b] = s.apply(lambda e: e.abs().mean()); m["rmse_" + b] = s.apply(lambda e: np.sqrt((e ** 2).mean()))
    m = m.join(d[["xi_points", "captain_pts"]].rename(columns={"xi_points": "xi", "captain_pts": "cap"}), how="inner")
    m["tx"] = d.net_transfer_gain.where(~d.fresh_squad.astype(bool))
    m.attrs["hits"] = int(d.hit.sum())
    return m


KEYS = [("xi", 1), ("cap", 1), ("tx", 1), ("mae", -1), ("rmse", -1)] + [(f"{k}_{b}", -1) for k in ("mae", "rmse") for b in ["0", "1-2", "3-4", "5+"]]


def fmt(x):
    lo, hi = ci(x)
    return f"{x.mean():+.2f} [{lo:+.2f}, {hi:+.2f}]{'★' if lo > 0 or hi < 0 else ''}", lo, hi, x.mean()


def pair(cand, ref):
    j = ref.join(cand, rsuffix="_v", how="inner")
    res = {}
    for k, s in KEYS:
        dl = s * (j[k + "_v"] - j[k])
        res[k] = fmt(dl.dropna())
        for se in SEAS:
            x = dl[dl.index.get_level_values(0) == se].dropna()
            res[(k, se)] = fmt(x) if len(x) > 1 else ("—", np.nan, np.nan, np.nan)
    res["n"] = len(j)
    return res


def winner(res, seasons):
    _, lo, hi, _ = res["xi"]
    return lo > 0 and all(not (res[("xi", s)][3] < 0) for s in seasons)
