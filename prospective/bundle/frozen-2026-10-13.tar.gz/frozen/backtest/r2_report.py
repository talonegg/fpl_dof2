import json, numpy as np, pandas as pd
import r2_compare as c
REF = {"champion": "champ__base", "challenger": "chall__base"}
refs = {k: c.metrics(v, v) for k, v in REF.items()}
# (candidate label, dec name, pf name, reference, seasons used)
rows = []
ARM = {"champion": "champ", "challenger": "chall"}
for ref, arm in ARM.items():
    for lab, cap in [("F1 P(haul≥10 incl. C)", "F1_p_haul"), ("F2 75th-pct score", "F2_q75"), ("F3 mean xP + premium-attacker tie-break", "F3_mean_tb"),
                     ("(ref) mean xP argmax", "mean_xp"), ("G odds-aware captain", "G_odds")]:
        rows.append((lab, f"{arm}__base__cap_{cap}", f"{arm}__base", ref, c.SEAS))
    for lab, v in [("B1 two-stage minutes (replaces avail scaling)", "B1"), ("B2 B1 + 3× zero-pt weight if flagged", "B2"),
                   ("B1a B1 overlay on top of avail scaling", "B1a"), ("D isotonic per position", "D_iso"),
                   ("C EB shrinkage + promoted ×0.9", "C_shrink")]:
        rows.append((lab, f"{arm}__{v}", f"{arm}__{v}", ref, c.SEAS))
    rows.append(("A component xPts (+C3 captain)", "comp__base", "comp__base", ref, c.SEAS))
rows.append(("E selected on 2023/24: max_transfers 3 + λ=0.25 (test 24/25+25/26)", "chall__E_sel", "chall__E_sel", "challenger", ["2024/25", "2025/26"]))

L = []
summary = []
for lab, dn, pn, ref, seas in rows:
    m = c.metrics(dn, pn)
    m = m[m.index.get_level_values(0).isin(seas)]
    r_ = refs[ref][refs[ref].index.get_level_values(0).isin(seas)]
    r = c.pair(m, r_)
    win = c.winner(r, seas)
    summary.append((lab, ref, r, win, seas, m.attrs.get("hits", 0), m.xi.mean()))

def cell(r, k): return r[k][0]
L += ["## Key table (paired uplift, candidate − reference; MAE/RMSE as reduction so + = better; 95% GW-bootstrap CI; ★ = CI excludes 0)", "",
      "| candidate | vs | XI pts/GW | captain pts/GW | net transfer gain/GW | MAE↓ | RMSE↓ | abs XI | hits | winner? |", "|---|---|---|---|---|---|---|---|---|---|"]
for lab, ref, r, win, seas, hits, xi in summary:
    L.append(f"| {lab} | {ref} | {cell(r,'xi')} | {cell(r,'cap')} | {cell(r,'tx')} | {cell(r,'mae')} | {cell(r,'rmse')} | {xi:.2f} | {hits} | {'**YES**' if win else 'no'} |")
L += ["", "## Per-season XI pts / captain pts / MAE↓", "", "| candidate | vs | season | XI | captain | MAE↓ |", "|---|---|---|---|---|---|"]
for lab, ref, r, win, seas, *_ in summary:
    for s in seas:
        L.append(f"| {lab} | {ref} | {s} | {r[('xi',s)][0]} | {r[('cap',s)][0]} | {r[('mae',s)][0]} |")
L += ["", "## Error by actual-points bucket (reduction; + = better)", "", "| candidate | vs | " + " | ".join(f"{k.upper()} {b}" for k in ("mae", "rmse") for b in ["0", "1-2", "3-4", "5+"]) + " |", "|---" * 10 + "|"]
for lab, ref, r, win, seas, *_ in summary:
    if "captain" in lab or lab.startswith("F") or "(ref)" in lab or lab.startswith("G"): continue
    L.append(f"| {lab} | {ref} | " + " | ".join(r[f'{k}_{b}'][0] for k in ("mae", "rmse") for b in ["0", "1-2", "3-4", "5+"]) + " |")
abs_ = []
for n in ["champ__base", "chall__base", "comp__base"]:
    m = c.metrics(n, n); abs_.append(f"| {n} | {m.xi.mean():.2f} | {m.cap.mean():.2f} | {m.tx.mean():.2f} | {m.mae.mean():.3f} | {m.rmse.mean():.3f} | {m.attrs['hits']} |")
open("r2/tables.md", "w").write("\n".join(L) + "\n\n## Absolute levels\n\n| run | XI | captain | net tx gain | MAE | RMSE | hit pts |\n|---|---|---|---|---|---|---|\n" + "\n".join(abs_) + "\n")
print("\n".join(L[:30])); print("\n".join(abs_))
