"""Round 3 decision runs: odds team layer arms through round2.simulate (deadline availability,
price+position (b0/C3) captain, no harness club-cap workaround)."""
import sys
import round2 as r2
r2.ARMS.update({"champ_ot": "champ_ot", "chall_ot": "c1_ot", "comp_ot": "comp_ot"})
if __name__ == "__main__":
    r2.run(sys.argv[1], "base")
