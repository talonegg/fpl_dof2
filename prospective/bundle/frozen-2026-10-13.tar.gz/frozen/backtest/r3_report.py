"""Round 3 report -> RESULTS_oddsteam.md tables (paired, 95% GW-bootstrap CI, Holm across this round)."""
import json, glob
import numpy as np, pandas as pd
import r2_compare as c
import odds_team as ot

def boot_p(x, n=4000, seed=1):
    x = np.asarray(pd.Series(x).dropna(), float)
    b = np.random.default_rng(seed).choice(x, (n, len(x))).mean(1)
    return float(min(1.0, 2 * min((b <= 0).mean(), (b >= 0).mean())))

def holm(ps):
    o = np.argsort(ps); m = len(ps); adj = np.empty(m); run = 0
    for r, i in enumerate(o):
        run = max(run, min(1, (m - r) * ps[i])); adj[i] = run
    return adj

M = {n: c.metrics(n, n) for n in ["champ__base", "chall__base", "comp__base", "champ_ot__base", "chall_ot__base", "comp_ot__base"]}
CMP = [("Champion + odds team layer", "champ_ot__base", "champ__base", "champion"),
       ("C1 + odds team layer (team xG features replaced)", "chall_ot__base", "chall__base", "challenger"),
       ("A + odds team layer", "comp_ot__base", "comp__base", "A"),
       ("A + odds team layer", "comp_ot__base", "champ__base", "champion"),
       ("A + odds team layer", "comp_ot__base", "chall__base", "challenger")]
rows = []
for lab, cand, ref, rn in CMP:
    r = c.pair(M[cand], M[ref])
    j = M[ref].join(M[cand], rsuffix="_v", how="inner")
    rows.append(dict(lab=lab, ref=rn, r=r, p=boot_p(j.xi_v - j.xi), win=c.winner(r, c.SEAS),
                     hits=M[cand].attrs["hits"], xi=M[cand].xi.mean()))
adj = holm(np.array([x["p"] for x in rows]))
L = ["| candidate | vs | XI pts/GW | captain pts/GW | MAE↓ | RMSE↓ | abs XI | hit pts | p (boot) | p Holm | winner? |", "|---|---|---|---|---|---|---|---|---|---|---|"]
for x, a in zip(rows, adj):
    r = x["r"]
    L.append(f"| {x['lab']} | {x['ref']} | {r['xi'][0]} | {r['cap'][0]} | {r['mae'][0]} | {r['rmse'][0]} | {x['xi']:.2f} | {x['hits']} | {x['p']:.3f} | {a:.3f} | {'**YES**' if x['win'] else 'no'} |")
L += ["", "### Per season (XI pts / captain pts / MAE↓, paired uplift)", "", "| candidate | vs | season | XI | captain | MAE↓ |", "|---|---|---|---|---|---|"]
for x in rows:
    for s in c.SEAS:
        r = x["r"]; L.append(f"| {x['lab']} | {x['ref']} | {s} | {r[('xi',s)][0]} | {r[('cap',s)][0]} | {r[('mae',s)][0]} |")
L += ["", "### Error by actual-points bucket (reduction; + = better)", "", "| candidate | vs | " + " | ".join(f"{k.upper()} {b}" for k in ("mae", "rmse") for b in ["0", "1-2", "3-4", "5+"]) + " |", "|---" * 10 + "|"]
for x in rows:
    L.append(f"| {x['lab']} | {x['ref']} | " + " | ".join(x['r'][f'{k}_{b}'][0] for k in ("mae", "rmse") for b in ["0", "1-2", "3-4", "5+"]) + " |")
L += ["", "### Absolute levels", "", "| run | XI | captain | MAE | RMSE | hit pts | GWs |", "|---|---|---|---|---|---|---|"]
for n, m in M.items():
    L.append(f"| {n} | {m.xi.mean():.2f} | {m.cap.mean():.2f} | {m.mae.mean():.3f} | {m.rmse.mean():.3f} | {m.attrs['hits']} | {len(m)} |")
# coverage
fx = ot.load(); dec_gws = set(map(tuple, M["champ__base"].index.to_frame().values.tolist()))
f = fx.assign(in_bt=[(s, g) in dec_gws for s, g in zip(fx.season, fx.gameweek)])
cov = f.groupby("season").agg(fixtures=("kept", "size"), with_odds=("kept", "sum"), pinnacle_1x2=("src12", lambda s: int(((s == "pinnacle") & f.loc[s.index, "kept"]).sum())),
                              with_ou=("pov", lambda s: int(s.notna().sum())), shin=("devig", lambda s: int((s == "shin").sum())), mean_overround_1x2=("ovr12", "mean"), mean_overround_ou=("ovrou", "mean"))
fb = f[f.in_bt]
cov["bt_fixtures"] = fb.groupby("season").size(); cov["bt_with_odds"] = fb.groupby("season").kept.sum()
L += ["", "### Coverage", "", "```", cov.round(4).to_string(), "```"]
open("r3/tables.md", "w").write("\n".join(L) + "\n")
print("\n".join(L))
