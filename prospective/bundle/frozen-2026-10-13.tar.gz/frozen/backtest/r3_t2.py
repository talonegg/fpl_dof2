"""T2: probabilistic accuracy of the odds team layer vs the current team model, per season.
Current team model = the xG-EWM team rates used by A's CS model and C1's team features
(xgf_r/xga_r: halflife-6 EWM of team xG for/against, shifted one GW within season).
λ_home(model) = mean(home xgf_r, away xga_r); λ_away likewise. Both layers -> Poisson -> 1X2 and CS.
Scored on fixtures that HAVE pre-deadline odds (the layer's fallback set is identical by construction)."""
import numpy as np, pandas as pd
import odds_team as ot
fx = ot.load()
h = pd.read_parquet("/workspace/fpl_data/silver/season=2026-27/player_gameweek.parquet")
h = h[h.season.isin(["2023/24", "2024/25", "2025/26"])]
f = h.groupby(["season", "gameweek", "fixture_id", "team_id"], as_index=False).expected_goals.sum()
f2 = f.merge(f, on=["season", "gameweek", "fixture_id"], suffixes=("", "_o")); f2 = f2[f2.team_id != f2.team_id_o]
tg = f2.groupby(["season", "gameweek", "team_id"], as_index=False).agg(xgf=("expected_goals", "sum"), xga=("expected_goals_o", "sum")).sort_values("gameweek")
for c in ["xgf", "xga"]:
    tg[c + "_r"] = tg.groupby(["season", "team_id"])[c].transform(lambda x: x.shift(1).ewm(halflife=6).mean())
nf = h.groupby(["season", "gameweek", "team_id"]).fixture_id.nunique().rename("nf").reset_index()
tg = tg.merge(nf, on=["season", "gameweek", "team_id"])
r = tg.set_index(["season", "gameweek", "team_id"])
k = fx[fx.kept].copy()
def get(s, g, t, c):
    try: return r.loc[(s, g, t), c]
    except KeyError: return np.nan
for side in ["home", "away"]:
    for c in ["xgf_r", "xga_r"]:
        k[f"{side}_{c}"] = [get(s, g, t, c) for s, g, t in zip(k.season, k.gameweek, k[side])]
k = k.dropna(subset=["home_xgf_r", "away_xgf_r", "home_xga_r", "away_xga_r"])
k["mh"] = ((k.home_xgf_r + k.away_xga_r) / 2).clip(0.2, 4); k["ma"] = ((k.away_xgf_r + k.home_xga_r) / 2).clip(0.2, 4)
res = np.where(k.FTHG > k.FTAG, 0, np.where(k.FTHG == k.FTAG, 1, 2))
Y = np.eye(3)[res]
def p3(lh, la): return np.array([ot.probs(a, b)[:3] for a, b in zip(lh, la)])
P = {"odds": p3(k.lh, k.la), "model": p3(k.mh, k.ma)}
cs_y = np.concatenate([(k.FTAG == 0).to_numpy(), (k.FTHG == 0).to_numpy()]).astype(float)
CSP = {"odds": np.exp(-np.concatenate([k.la, k.lh])), "model": np.exp(-np.concatenate([k.ma, k.mh]))}
seas2 = np.concatenate([k.season, k.season])
rows = []
for s in ["2023/24", "2024/25", "2025/26", "all"]:
    m = (k.season == s).to_numpy() if s != "all" else np.ones(len(k), bool)
    m2 = (seas2 == s) if s != "all" else np.ones(len(seas2), bool)
    row = {"season": s, "n_fixtures": int(m.sum())}
    for lay in ["odds", "model"]:
        p = np.clip(P[lay][m], 1e-9, 1); p = p / p.sum(1, keepdims=True)
        row[f"1x2_brier_{lay}"] = float(((p - Y[m]) ** 2).sum(1).mean())
        row[f"1x2_logloss_{lay}"] = float(-np.log((p * Y[m]).sum(1)).mean())
        q = np.clip(CSP[lay][m2], 1e-9, 1 - 1e-9); y = cs_y[m2]
        row[f"cs_brier_{lay}"] = float(((q - y) ** 2).mean())
        row[f"cs_logloss_{lay}"] = float(-(y * np.log(q) + (1 - y) * np.log(1 - q)).mean())
    rows.append(row)
t = pd.DataFrame(rows)
t.to_csv("r3/t2.csv", index=False)
print(t.round(4).to_string())
