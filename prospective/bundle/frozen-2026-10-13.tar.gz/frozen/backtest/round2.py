"""Round 2 candidate backtests (local review only). See RESULTS_round2.md.

    round2.py sim <arm> <variant> [--seasons ...] [--tcfg key=val ...]

Arms: champ = minutes_v2 cache (engine + C3), chall = vec_xg2 cache (C1), comp = candidate A cache.
Deadline availability (availability.py) is always applied first, as in backtest.py.
Every overlay below is walk-forward: anything fitted uses only GWs strictly before the decision GW,
from the cache's own (already walk-forward) predictions and realised outcomes.
"""
from __future__ import annotations
import json, sys, time
from collections import Counter
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, pandas as pd
import availability as av
import backtest as bt
from fpl_dof.optimise.squad import InfeasibleError, optimise_squad
from fpl_dof.optimise.transfer import recommend_transfers
from fpl_dof.rules.models import GameRules
from fpl_dof.squad.state import HeldPlayer, Provenance, SquadState, free_transfers_after

D = Path(__file__).resolve().parent
R2 = D / "r2"
ARMS = {"champ": "minutes_v2", "chall": "vec_xg2", "comp": "comp_A"}
SEASON_T = {"2023/24": 0, "2024/25": 1, "2025/26": 2}
PROMOTED = {"2023/24": {90, 102, 49}, "2024/25": {40, 13, 20}, "2025/26": {90, 2, 56}}


def load_arm(arm):
    pf = pd.read_parquet(D / f"cache_{ARMS[arm]}.parquet")
    pf = av.apply(pf, av.load())
    pf["t"] = pf.season.map(SEASON_T) * 100 + pf.gw
    return pf


def _walk(pf, fit_apply, min_prior=3):
    """For each GW, fit on rows with t < this GW (prior GWs only) and transform this GW's xp."""
    out = []
    ts = sorted(pf.t.unique())
    for i, t in enumerate(ts):
        cur = pf[pf.t == t].copy()
        prior = pf[pf.t < t]
        if prior.t.nunique() >= min_prior:
            cur = fit_apply(prior, cur)
        out.append(cur)
    return pd.concat(out, ignore_index=True)


# ---------------- D: isotonic calibration per position ----------------
def ov_isotonic(pf):
    from sklearn.isotonic import IsotonicRegression
    def fa(prior, cur):
        for pos in cur.position.unique():
            p = prior[prior.position == pos]
            ir = IsotonicRegression(out_of_bounds="clip").fit(p.xp_next, p.actual)
            m = cur.position == pos
            new = ir.predict(cur.loc[m, "xp_next"])
            cur.loc[m, "xp_horizon"] = new; cur.loc[m, "xp_next"] = new
        return cur
    return _walk(pf, fa)


# ---------------- C: empirical-Bayes shrinkage + promoted-team discount ----------------
def _player_minutes(pf):
    """Season-to-date minutes strictly before each GW (from realised prior rows in the cache)."""
    pf = pf.sort_values(["season", "player_id", "gw"])
    pf["prior_min"] = pf.groupby(["season", "player_id"]).minutes.transform(lambda s: s.shift(1).fillna(0).cumsum())
    return pf


def ov_shrink(pf, k=3.0, promoted_discount=0.9):
    pf = _player_minutes(pf.copy())
    pf["band"] = pd.cut(pf.price, [0, 4.75, 5.75, 7.25, 9.25, 99], labels=False)
    def fa(prior, cur):
        pri = prior[prior.prior_min < 270].groupby(["position", "band"]).actual.mean()
        cur = cur.copy()
        n = cur.prior_min / 90.0
        pm = cur.set_index(["position", "band"]).index.map(pri.to_dict()).to_numpy(dtype=float)
        pm = np.where(np.isnan(pm), cur.xp_next, pm) * cur.start_probability.to_numpy()
        low = n < 6
        new = np.where(low, (n * cur.xp_next + k * pm) / (n + k), cur.xp_next)
        prom = cur.apply(lambda r: r.team_id in PROMOTED[r.season], axis=1).to_numpy()
        new = np.where(prom, new * promoted_discount, new)
        cur["xp_next"] = new; cur["xp_horizon"] = new
        return cur
    return _walk(pf, fa)


# ---------------- B: two-stage minutes overlay ----------------
def minutes_frame():
    """Per player-GW deadline features for the minutes model (Vector's shifted rolling features +
    deadline availability + a rotation index) and outcomes (start, 60+)."""
    from vector_models import build_features
    _, hist = bt.load("/workspace/fpl_data", list(SEASON_T))
    g = build_features(hist)
    g = g.rename(columns={"player_code": "player_id", "gameweek": "gw"})
    a = av.load()
    g = g.merge(a, on=["season", "gw", "player_id"], how="left")
    g["avail"] = g.avail.fillna(1.0)
    g["flagged"] = (g.avail < 1).astype(int)
    G = g.groupby("key")
    sh = G.minutes.shift(1)
    g["rot_idx"] = sh.groupby(g.key).rolling(6, min_periods=2).std().reset_index(0, drop=True) / 90.0
    g["start_y"] = (g.starts > 0).astype(int)
    g["s60_y"] = (g.minutes >= 60).astype(int)
    return g


MF = ["avail", "flagged", "rot_idx", "price", "gp", "min_last", "played_last", "prev_min",
      "starts_l3", "starts_l6", "starts_sea", "minutes_l3", "minutes_l6", "minutes_sea", "minutes_ewm"]


def ov_minutes_on_avail(pf, w=1.0):
    """B1a: the same r overlay applied on top of the default avail-scaled xp (avail kept)."""
    q = pd.read_parquet(R2 / f"minutes_q_w{w}.parquet")
    out = pf.merge(q[["t", "player_id", "r"]], on=["t", "player_id"], how="left")
    r = out.pop("r").fillna(1.0)
    out["xp_next"] *= r; out["xp_horizon"] *= r
    return out


def ov_minutes(pf, flagged_zero_weight=1.0):
    """xp × P(start)·[P(60|start) + 0.5·(1−P(60|start))] / same quantity's prior-6 mean for the player
    (relative overlay: the arm's xp already contains its own minutes view; this re-weights it by how
    much more/less likely to play this week than usual). Replaces the plain avail scaling."""
    raw = pd.read_parquet(D / f"cache_{pf.attrs['arm_cache']}.parquet")  # pre-availability xp
    raw["t"] = raw.season.map(SEASON_T) * 100 + raw.gw
    qp = R2 / f"minutes_q_w{flagged_zero_weight}.parquet"
    q = pd.read_parquet(qp) if qp.exists() else minutes_q(sorted(raw.t.unique()), flagged_zero_weight)
    if not qp.exists(): q.to_parquet(qp)
    out = raw.merge(q[["t", "player_id", "r", "ps"]], on=["t", "player_id"], how="left")
    out["r"] = out.r.fillna(1.0)
    for c in ("xp_next", "xp_horizon"):
        out[c] = out[c] * out.r
    a = av.load()
    out = out.merge(a, on=["season", "gw", "player_id"], how="left")
    out["xp_b0"] = out.xp_b0 * out.avail.fillna(1.0)
    out["start_probability"] = out.ps.fillna(out.avail.fillna(1.0))
    return out.drop(columns=["avail", "r", "ps"])


def minutes_q(ts, flagged_zero_weight):
    from sklearn.ensemble import HistGradientBoostingClassifier as HGC
    g = minutes_frame()
    kw = dict(max_iter=150, learning_rate=0.05, min_samples_leaf=50)
    preds, models, n = [], None, 0
    for t in ts:
        if n % 4 == 0:
            tr = g[(g.t < t) & (g.gp > 0)]
            w = np.where((tr.flagged == 1) & (tr.start_y == 0), flagged_zero_weight, 1.0)
            st = tr[tr.start_y == 1]
            models = (HGC(**kw).fit(tr[MF], tr.start_y, sample_weight=w), HGC(**kw).fit(st[MF], st.s60_y))
        n += 1
        te = g[g.t == t]
        ps = models[0].predict_proba(te[MF])[:, 1]; p6 = models[1].predict_proba(te[MF])[:, 1]
        preds.append(pd.DataFrame({"t": t, "player_id": te.player_id.values, "q": ps * (p6 + 0.5 * (1 - p6)), "ps": ps}))
    q = pd.concat(preds).groupby(["t", "player_id"], as_index=False).mean()
    q = q.sort_values(["player_id", "t"])
    q["qbar"] = q.groupby("player_id").q.transform(lambda s: s.shift(1).rolling(6, min_periods=1).mean())
    q["r"] = (q.q / q.qbar).clip(0, 1.5).fillna(1.0)
    return q


# ---------------- E: robust objective (mean − λ·std), std from prior residuals ----------------
def ov_robust(pf, lam):
    def fa(prior, cur):
        prior = prior.assign(b=pd.qcut(prior.xp_next.rank(method="first"), 10, labels=False))
        edges = np.quantile(prior.xp_next, np.linspace(0, 1, 11))
        sd = prior.assign(r=prior.actual - prior.xp_next).groupby(["position", "b"]).r.std()
        b = np.clip(np.searchsorted(edges, cur.xp_next, side="right") - 1, 0, 9)
        s = pd.Series(list(zip(cur.position, b))).map(sd.to_dict()).fillna(0).to_numpy()
        new = np.maximum(0, cur.xp_next.to_numpy() - lam * s)
        cur["xp_next"] = new; cur["xp_horizon"] = new
        return cur
    return _walk(pf, fa)


OVERLAYS = {"base": lambda pf: pf, "D_iso": ov_isotonic, "C_shrink": ov_shrink,
            "B1": lambda pf: ov_minutes(pf, 1.0), "B2": lambda pf: ov_minutes(pf, 3.0), "B1a": ov_minutes_on_avail,
            "E_l0.25": lambda pf: ov_robust(pf, 0.25), "E_l0.5": lambda pf: ov_robust(pf, 0.5)}


def simulate(allpf, out_name, tcfg=None, seasons=None):
    """backtest.simulate's decision loop WITHOUT the harness club-cap workaround (counts any
    InfeasibleError instead), b0 captain, and writes the XI for post-hoc captain policies."""
    cfg = bt.CFG()
    rules = GameRules.model_validate(json.loads((Path("/workspace/fpl_data/silver/season=2026-27") / "rules.json").read_text()))
    opt = cfg.optimiser.model_copy(update={"enforce_start_probability_floor": False})
    trc = cfg.transfers.model_copy(update=tcfg or {})
    if seasons:
        allpf = allpf[allpf.season.isin(seasons)]
    rows, xis, state, cur, infeasible, overcap = [], [], None, None, 0, 0
    for (season, gw), pf in allpf.groupby(["season", "gw"], sort=False):
        pf = pf.reset_index(drop=True)
        fresh = season != cur
        if fresh:
            squad, _ = optimise_squad(pf, rules, opt)
            state = SquadState(entry_id=None, gameweek=gw, players=tuple(
                HeldPlayer(player_id=m.player_id, position=m.position, team_id=m.team_id,
                           current_price=m.price, purchase_price=m.price) for m in squad.players),
                bank=max(0.0, rules.squad.budget - sum(m.price for m in squad.players)),
                free_transfers=1, chips_used=(), provenance=Provenance.DECLARED)
            cur = season
        lookup = pf.set_index("player_id")
        missing = [p for p in state.players if p.player_id not in lookup.index]
        if missing:
            pf = pd.concat([pf, pd.DataFrame([{"player_id": p.player_id, "position": getattr(p.position, "value", p.position),
                "team_id": p.team_id, "price": p.current_price, "xp_next": 0.0, "xp_horizon": 0.0, "xp_b0": 0.0,
                "start_probability": 1.0, "actual": 0.0, "minutes": 0, "selected_by": 0} for p in missing])], ignore_index=True)
            lookup = pf.set_index("player_id")
        state = SquadState(entry_id=None, gameweek=gw, players=tuple(
            HeldPlayer(player_id=p.player_id, position=p.position, team_id=int(lookup.loc[p.player_id, "team_id"]),
                       current_price=float(lookup.loc[p.player_id, "price"]), purchase_price=p.purchase_price)
            for p in state.players), bank=state.bank, free_transfers=state.free_transfers,
            chips_used=(), provenance=Provenance.DECLARED)
        if max(Counter(p.team_id for p in state.players).values()) > rules.squad.club_limit:
            overcap += 1
        try:
            rec = recommend_transfers(pf, state, rules, trc, opt)
        except InfeasibleError as e:
            infeasible += 1; print(f"{season} GW{gw}: INFEASIBLE {e}"); continue
        o, roll = rec.recommended, rec.roll
        act = lookup["actual"]
        gin = sum(float(act.get(m.player_in_id, 0)) for m in o.moves)
        gout = sum(float(act.get(m.player_out_id, 0)) for m in o.moves)
        xi = list(o.starting)
        cap = max(xi, key=lambda i: float(lookup.loc[i, "xp_b0"]))
        xa = [float(act.get(i, 0)) for i in xi]
        rows.append(dict(season=season, gw=gw, fresh_squad=fresh, transfers=o.transfers, hit=o.hit_points,
                         net_transfer_gain=gin - gout + o.hit_points, captain_pts=float(act.get(cap, 0)),
                         base_xi=sum(xa) + o.hit_points, xi_points=sum(xa) + float(act.get(cap, 0)) + o.hit_points))
        xis += [dict(season=season, gw=gw, player_id=i) for i in xi]
        newids = set(o.squad_after)
        old = {p.player_id: p for p in state.players}
        players = tuple(old[i] if i in old else HeldPlayer(player_id=i, position=lookup.loc[i, "position"],
                        team_id=int(lookup.loc[i, "team_id"]), current_price=float(lookup.loc[i, "price"]),
                        purchase_price=float(lookup.loc[i, "price"])) for i in newids)
        state = SquadState(entry_id=None, gameweek=gw + 1, players=players, bank=o.bank_after,
                           free_transfers=free_transfers_after(state.free_transfers, o.transfers, rules),
                           chips_used=(), provenance=Provenance.DECLARED)
    dec = pd.DataFrame(rows)
    dec.attrs.update(infeasible=infeasible, overcap=overcap)
    dec.to_csv(R2 / f"dec_{out_name}.csv", index=False)
    pd.DataFrame(xis).to_csv(R2 / f"xi_{out_name}.csv", index=False)
    (R2 / f"meta_{out_name}.json").write_text(json.dumps(dict(infeasible=infeasible, overcap_gws=overcap)))
    return dec


def run(arm, variant, tcfg=None, seasons=None, tag=None):
    pf = load_arm(arm)
    pf.attrs["arm_cache"] = ARMS[arm]
    pf = OVERLAYS[variant](pf)
    name = tag or f"{arm}__{variant}"
    pf[["season", "gw", "player_id", "position", "price", "team_id", "xp_next", "xp_b0", "actual", "minutes"]].to_parquet(R2 / f"pf_{name}.parquet")
    t0 = time.time()
    simulate(pf, name, tcfg, seasons)
    print(name, "done", round(time.time() - t0), "s", flush=True)


if __name__ == "__main__":
    arm, variant = sys.argv[2], sys.argv[3]
    tcfg, seasons, tag = {}, None, None
    for a in sys.argv[4:]:
        k, v = a.split("=")
        if k == "seasons": seasons = v.split(",")
        elif k == "tag": tag = v
        else: tcfg[k] = float(v) if "." in v else int(v)
    run(arm, variant, tcfg, seasons, tag)
