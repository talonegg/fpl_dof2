"""Harness tests (run: .venv/bin/python -m pytest -q backtest/test_backtest_harness.py). No data files needed."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import availability as av  # noqa: E402
import ds_features  # noqa: E402

UTC = "UTC"
SNAPS = [(pd.Timestamp("2025-08-15 06:00", tz=UTC), "a"), (pd.Timestamp("2025-08-15 12:00", tz=UTC), "b"),
         (pd.Timestamp("2025-08-15 18:00", tz=UTC), "c")]


def test_latest_snapshot_strictly_before_deadline():
    assert av.latest_before(SNAPS, pd.Timestamp("2025-08-15 17:30", tz=UTC))[1] == "b"
    # a snapshot exactly at the deadline is not "before" it
    assert av.latest_before(SNAPS, pd.Timestamp("2025-08-15 18:00", tz=UTC))[1] == "b"


def test_no_snapshot_before_deadline_raises():
    with pytest.raises(av.SnapshotAfterDeadline):
        av.latest_before(SNAPS, pd.Timestamp("2025-08-15 06:00", tz=UTC))


def test_load_asserts_every_snapshot_precedes_its_deadline(tmp_path):
    pd.DataFrame([dict(season="2025/26", gw=1, snap_ts="2025-08-15 18:00+00:00", deadline="2025-08-15 17:30+00:00")]
                 ).to_csv(tmp_path / "index.csv", index=False)
    pd.DataFrame(dict(season=["2025/26"], gw=[1], player_code=[1], status=["a"], cop=[None])).to_parquet(tmp_path / "snapshots.parquet")
    with pytest.raises(av.SnapshotAfterDeadline):
        av.load(tmp_path)


def test_availability_uses_chance_then_status():
    status = pd.Series(["a", "d", "i", "d", "s", "x"])
    chance = pd.Series([None, None, None, 75.0, None, None], dtype=float)
    assert list(av.availability(status, chance)) == [1.0, 0.5, 0.0, 0.75, 0.0, 1.0]


def test_apply_scales_xp_and_sets_start_probability():
    pf = pd.DataFrame(dict(season="2025/26", gw=1, player_id=[1, 2, 3], xp_next=[4.0, 4.0, 4.0],
                           xp_horizon=[8.0, 8.0, 8.0], xp_b0=[2.0, 2.0, 2.0], start_probability=1.0))
    a = pd.DataFrame(dict(season="2025/26", gw=1, player_id=[1, 2], avail=[0.0, 0.5]))
    out = av.apply(pf, a)
    assert list(out.xp_next) == [0.0, 2.0, 4.0] and list(out.xp_b0) == [0.0, 1.0, 2.0]
    assert list(out.start_probability) == [0.0, 0.5, 1.0]  # no snapshot row -> unchanged
    assert "avail" not in out


def test_availability_is_the_harness_default(monkeypatch, tmp_path):
    import backtest as bt
    pf = pd.DataFrame(dict(season="2025/26", gw=1, player_id=[1], position="MID", xp_next=[4.0], xp_horizon=[4.0],
                           xp_b0=[1.0], start_probability=1.0, actual=[2.0], minutes=[90]))
    pf.to_parquet(tmp_path / "cache_m.parquet")
    monkeypatch.setattr(av, "load", lambda *a, **k: pd.DataFrame(dict(season=["2025/26"], gw=[1], player_id=[1], avail=[0.0])))
    seen = {}
    monkeypatch.setattr(bt, "simulate", lambda allpf, policy, name, out: seen.update({name: allpf}) or pd.DataFrame())
    bt.run("m", [], "", tmp_path)
    bt.run("m", [], "", tmp_path, deadline_availability=False)
    assert seen["m"].xp_next.iloc[0] == 0.0 and seen["m"].start_probability.iloc[0] == 0.0
    assert seen["m_noavail"].xp_next.iloc[0] == 4.0  # the flag turns it off


def test_dropped_fplcache_features_are_gone():
    import ds_backtest
    assert not hasattr(ds_features, "snapshot_features")
    assert not hasattr(ds_backtest, "FC") and "c1_fc" not in ds_backtest.bt.MODELS


def test_backtest_odds_read_pre_closing_only():
    assert ds_features.PRE_CLOSING == ["AvgH", "AvgD", "AvgA", "Avg>2.5", "Avg<2.5"]
    assert not any("C" in c[3:] for c in ds_features.PRE_CLOSING)
