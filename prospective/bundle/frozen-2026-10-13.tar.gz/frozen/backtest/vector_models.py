"""Faithful port of Vector's /workspace/fpl-backtest/harness (bt.py features + eval.py GBMs) to the
fpl_dof2 harness's plug-in interface. Differences from the original, all deliberate:
* player key is (season, player_code) instead of season|name (name collisions/renames); prior-season
  means joined on player_code instead of name.
* team / opponent are the archive's stable club codes, so the alphabetical id->name map is not needed.
* history starts at 2023/24 (repo backfill), not 2022/23 — same as every other model here.
Same features, same per-position HistGBM hyper-parameters, same retrain-every-4-GWs cadence,
training rows strictly from GWs before the fold (t < test t, gp > 0).
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier as HGC, HistGradientBoostingRegressor as HGR

ROLL_SRC = ["total_points", "minutes", "expected_goals", "expected_assists", "expected_goals_conceded",
            "starts", "bonus", "bps"]


def build_features(history: pd.DataFrame) -> pd.DataFrame:
    d = history.copy()
    seasons = sorted(d.season.unique())
    d["sidx"] = d.season.map({s: i for i, s in enumerate(seasons)})
    d["t"] = d.sidx * 100 + d.gameweek
    d["key"] = d.season + "|" + d.player_code.astype(str)
    agg = {c: "sum" for c in ROLL_SRC}
    agg.update(price="last", was_home="mean", fixture_id="count")
    g = (d.groupby(["key", "season", "sidx", "gameweek", "t", "player_code", "position", "team_id"], as_index=False)
           .agg(agg).rename(columns={"fixture_id": "nfix"}).sort_values(["key", "t"]))
    G = g.groupby("key")
    for c in ROLL_SRC:
        sh = G[c].shift(1)
        g[c + "_l3"] = sh.groupby(g.key).rolling(3, min_periods=1).mean().reset_index(0, drop=True)
        g[c + "_l6"] = sh.groupby(g.key).rolling(6, min_periods=1).mean().reset_index(0, drop=True)
        g[c + "_sea"] = sh.groupby(g.key).expanding().mean().reset_index(0, drop=True)
        g[c + "_ewm"] = sh.groupby(g.key).transform(lambda x: x.ewm(halflife=4, ignore_na=True).mean())
    g["gp"] = G.cumcount()
    g["min_last"] = G["minutes"].shift(1)
    g["played_last"] = (g.min_last > 0).astype(float)
    prev = g.groupby(["sidx", "player_code"], as_index=False)[["total_points", "minutes"]].mean()
    prev["sidx"] += 1
    g = g.merge(prev.rename(columns={"total_points": "prev_pts", "minutes": "prev_min"}), on=["sidx", "player_code"], how="left")
    # team rolling xG for / against, shifted within season
    fx = d.groupby(["season", "t", "fixture_id", "team_id"], as_index=False).expected_goals.sum()
    fx2 = fx.merge(fx, on=["season", "t", "fixture_id"], suffixes=("", "_o"))
    fx2 = fx2[fx2.team_id != fx2.team_id_o]
    tg = fx2.groupby(["season", "t", "team_id"], as_index=False).agg(xgf=("expected_goals", "sum"), xga=("expected_goals_o", "sum")).sort_values("t")
    for c in ["xgf", "xga"]:
        tg[c + "_r"] = tg.groupby(["season", "team_id"])[c].transform(lambda x: x.shift(1).ewm(halflife=6).mean())
    opp = d.groupby(["season", "t", "team_id"], as_index=False).opponent_team_id.first()
    g = g.merge(opp, on=["season", "t", "team_id"], how="left")
    g = g.merge(tg[["season", "t", "team_id", "xgf_r", "xga_r"]], on=["season", "t", "team_id"], how="left")
    g = g.merge(tg[["season", "t", "team_id", "xgf_r", "xga_r"]].rename(columns={"team_id": "opponent_team_id", "xgf_r": "opp_xgf_r", "xga_r": "opp_xga_r"}),
                on=["season", "t", "opponent_team_id"], how="left")
    g["nfix"] = g.nfix.astype(float)
    g[["prev_pts", "prev_min"]] = g[["prev_pts", "prev_min"]].fillna(-1)
    g["was_home"] = g.was_home.astype(float)
    return g


BASE = ["price", "was_home", "gp", "nfix", "min_last", "played_last", "prev_pts", "prev_min", "xgf_r", "xga_r", "opp_xgf_r", "opp_xga_r"]


class VectorGBM:
    """kind in {'noxg','xg','xg2'}; uses the context hook (season, gw) the harness provides."""
    RET = 4

    def __init__(self, kind, history):
        self.kind = kind
        self.g = build_features(history)
        roll = [c for c in self.g.columns if any(c.endswith(s) for s in ["_l3", "_l6", "_sea", "_ewm"])]
        self.F_all = BASE + roll
        self.F = [c for c in self.F_all if "expected" not in c] if kind == "noxg" else self.F_all
        self.models, self.n = {}, 0
        self.season = self.gw = None

    def set_context(self, season, gw, deadline):
        self.season, self.gw = season, gw

    def _t(self):
        row = self.g[(self.g.season == self.season) & (self.g.gameweek == self.gw)]
        return int(row.t.iloc[0])

    def fit(self, training):
        t = self._t()
        if self.n % self.RET == 0:
            tr = self.g[(self.g.t < t) & (self.g.gp > 0)]
            self.models = {}
            kw = dict(max_iter=200, learning_rate=0.05, min_samples_leaf=50)
            for pos in ["GKP", "DEF", "MID", "FWD"]:
                p = tr[tr.position == pos]
                if self.kind == "xg2":
                    pl = p[p.minutes > 0]
                    self.models[pos] = (HGC(**kw).fit(p[self.F], (p.minutes > 0).astype(int)), HGR(**kw).fit(pl[self.F], pl.total_points))
                else:
                    self.models[pos] = HGR(**kw).fit(p[self.F], p.total_points)
        self.n += 1

    def predict(self, visible):
        t = self._t()
        te = self.g[self.g.t == t].copy()
        out = pd.Series(0.0, index=te.index)
        for pos, m in self.models.items():
            e = te[te.position == pos]
            if e.empty:
                continue
            out.loc[e.index] = m[0].predict_proba(e[self.F])[:, 1] * m[1].predict(e[self.F]) if self.kind == "xg2" else m.predict(e[self.F])
        per_player = dict(zip(te.player_code, out))
        # split a player-GW prediction evenly over that player's fixture rows (DGW sums preserved)
        codes = visible["player_code"]
        nrows = codes.map(codes.value_counts())
        return (codes.map(per_player).fillna(0.0) / nrows).to_numpy()
