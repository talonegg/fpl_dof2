"""Model A shadow — component xPts (separate P(play), P(60+), goals, assists, bonus, saves, CS,
goals-conceded and 2025/26+ defensive-contribution models summed with FPL scoring).

Port of ``backtest/comp_model.py``. In the round-2 walk-forward backtest it was the closest
candidate (+2.55 [-0.43, +5.53] XI pts/GW over the champion, negative in 2023/24), so it is not
a promotion candidate yet: it runs as a **third shadow** beside the engine and C1. Every week
stage fits it on history strictly before the upcoming gameweek (every rolling feature is shifted
one GW; the upcoming rows carry no outcomes), lets the real transfer engine choose from its
numbers (captain by the price+position rule, as for C1), and logs XI, captain/vice and transfers
to ``shadow_a.json``. Nothing it produces reaches ``week.json`` or ``week_challenger.json``, and
:func:`run_shadow_a_safely` never raises.
"""

from __future__ import annotations

import json
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from fpl_dof.config.models import OptimiserConfig, TransferConfig
from fpl_dof.frames import as_int
from fpl_dof.obs.logging import get_logger
from fpl_dof.optimise.captain import apply_price_position_captain, price_position_scores
from fpl_dof.optimise.transfer import TransferRecommendation, recommend_transfers
from fpl_dof.rules.models import GameRules
from fpl_dof.shadow.c1 import BASE, POSITIONS, _option, build_features, upcoming_rows
from fpl_dof.squad.state import SquadState

log = get_logger(__name__)

SHADOW_A_FILENAME = "shadow_a.json"
MODEL_NAME = "a_component_xpts"

GOAL = {"GKP": 10, "DEF": 6, "MID": 5, "FWD": 4}
CS = {"GKP": 4, "DEF": 4, "MID": 1, "FWD": 0}
EXTRA = {"goals_scored": "goals", "assists": "assists", "saves": "saves"}
_I = np.arange(15)
_FACT = np.array([float(np.prod(np.arange(1, k + 1))) for k in _I])


def _floor_mean(lam: float, per: int) -> float:
    """E[floor(X / per)] for X ~ Poisson(lam), truncated at 14 (ample for FPL rates)."""
    pmf = np.exp(-lam) * np.power(lam, _I) / _FACT
    return float((pmf * (_I // per)).sum())


def build_frame(history: pd.DataFrame) -> pd.DataFrame:
    """C1's features plus per-GW goals/assists/saves/DC-hit and their shifted 6-GW means."""
    g = build_features(history)
    h = history.copy()
    for c in (*EXTRA, "defensive_contribution"):
        if c not in h.columns:
            h[c] = np.nan
    dc = h["defensive_contribution"]
    thr = np.where(h["position"] == "DEF", 10, 12)
    h["dc"] = np.where(h["position"] == "GKP", 0.0, (dc.fillna(0) >= thr).astype(float))
    h.loc[dc.isna(), "dc"] = np.nan
    h["key"] = h["season"] + "|" + h["player_code"].astype(str)
    extra = h.groupby(["key", "gameweek"], as_index=False).agg(
        **{dst: (src, "sum") for src, dst in EXTRA.items()}, dc=("dc", "max")
    )
    g = g.merge(extra, on=["key", "gameweek"], how="left")
    grouped = g.groupby("key")
    for c in ("goals", "assists", "saves", "dc"):
        g[c + "_l6"] = (
            grouped[c]
            .shift(1)
            .groupby(g.key)
            .rolling(6, min_periods=1)
            .mean()
            .reset_index(0, drop=True)
        )
    g["dc_l6"] = g["dc_l6"].fillna(-1)
    return g


def _features(g: pd.DataFrame) -> list[str]:
    roll = [
        c
        for c in g.columns
        if any(c.endswith(s) for s in ("_l3", "_l6", "_sea", "_ewm"))
        and c not in ("goals_l6", "assists_l6", "saves_l6", "dc_l6")
    ]
    return BASE + roll + ["goals_l6", "assists_l6", "saves_l6", "dc_l6"]


def fit_predict(g: pd.DataFrame, t_next: int, season: str) -> pd.Series:
    """A's xPts per player_code for GW ``t_next``, trained only on rows with t < t_next."""
    from sklearn.ensemble import HistGradientBoostingClassifier as Clf
    from sklearn.ensemble import HistGradientBoostingRegressor as Reg

    feats = _features(g)
    train = g[(g.t < t_next) & (g.gp > 0)]
    test = g[g.t == t_next]
    out = pd.Series(0.0, index=test.index)
    nf = test.nfix.clip(lower=1).to_numpy()
    lam = (((test.xga_r.fillna(1.4) + test.opp_xgf_r.fillna(1.4)) / 2) / nf).clip(0.2, 4).to_numpy()
    pcs = np.exp(-lam)
    egc = np.array([_floor_mean(x, 2) for x in lam])
    kw: dict[str, Any] = {
        "max_iter": 150,
        "learning_rate": 0.05,
        "min_samples_leaf": 50,
        "early_stopping": False,
    }
    for pos in POSITIONS:
        p = train[train.position == pos]
        pl = p[p.minutes > 0]
        idx = (test.position == pos).to_numpy()
        if not idx.any() or p.empty or pl.empty or p.minutes.gt(0).nunique() < 2:
            continue
        x = test.loc[idx, feats]
        pp = Clf(**kw).fit(p[feats], (p.minutes > 0).astype(int)).predict_proba(x)[:, 1]
        s60 = (pl.minutes >= 60).astype(int)
        p6 = (
            Clf(**kw).fit(pl[feats], s60).predict_proba(x)[:, 1]
            if s60.nunique() > 1
            else np.full(len(x), float(s60.mean()))
        )
        app = 1 + p6 + p6 * CS[pos] * pcs[idx] - (p6 * egc[idx] if pos in ("GKP", "DEF") else 0)
        xp = app * nf[idx] + Reg(loss="poisson", **kw).fit(pl[feats], pl.bonus).predict(x)
        if pos == "GKP":
            s = Reg(loss="poisson", **kw).fit(pl[feats], pl.saves.fillna(0)).predict(x)
            xp = xp + np.array([_floor_mean(v, 3) for v in s])
        else:
            xp = xp + GOAL[pos] * Reg(loss="poisson", **kw).fit(
                pl[feats], pl.goals.fillna(0)
            ).predict(x)
            xp = xp + 3 * Reg(loss="poisson", **kw).fit(pl[feats], pl.assists.fillna(0)).predict(x)
            dc = pl[pl.dc.notna()]
            if season >= "2025/26" and len(dc) > 500 and dc.dc.nunique() > 1:
                xp = xp + 2 * Clf(**kw).fit(dc[feats], dc.dc.astype(int)).predict_proba(x)[:, 1]
        out.loc[test.index[idx]] = pp * xp
    return pd.Series(out.to_numpy(), index=test.player_code.to_numpy())


def predict_next(
    history: pd.DataFrame, players: pd.DataFrame, fixtures: pd.DataFrame, season: str, gameweek: int
) -> dict[int, float]:
    """A's xPts for ``gameweek`` per ``player_code``; history at or after it is dropped first."""
    past = history[(history["season"] != season) | (history["gameweek"] < gameweek)]
    future = upcoming_rows(players, fixtures, season, gameweek)
    columns = [c for c in past.columns if c in future.columns]
    frame = pd.concat([past, future[columns]], ignore_index=True)
    frame["fixture_id"] = frame["fixture_id"].astype(float)
    g = build_frame(frame)
    t_next = int(g[(g.season == season) & (g.gameweek == gameweek)].t.iloc[0])
    return {as_int(k): float(v) for k, v in fit_predict(g, t_next, season).items()}


def run_shadow_a(
    *,
    forecast: pd.DataFrame,
    history: pd.DataFrame,
    players: pd.DataFrame,
    fixtures: pd.DataFrame,
    state: SquadState,
    rules: GameRules,
    transfer_config: TransferConfig,
    optimiser_config: OptimiserConfig,
    gameweek: int,
) -> TransferRecommendation:
    """Fit A and run the real transfer engine on a *copy* of the champion's forecast frame."""
    xp_by_code = predict_next(history, players, fixtures, rules.season, gameweek)
    code_of = dict(zip(players["player_id"].astype(int), players["code"].astype(int), strict=True))
    frame = forecast.copy()
    frame["xp_next"] = [xp_by_code.get(code_of.get(as_int(i), -1), 0.0) for i in frame["player_id"]]
    frame["xp_horizon"] = frame["xp_next"]
    rec = recommend_transfers(frame, state, rules, transfer_config, optimiser_config)
    scores = price_position_scores(frame, history)
    if scores is not None:
        rec = apply_price_position_captain(rec, frame, scores, optimiser_config.captain_multiplier)
    return rec


def run_shadow_a_safely(
    *,
    gold: Path,
    run_id: str,
    gameweek: int,
    engine: TransferRecommendation,
    challenger: TransferRecommendation | None = None,
    **kwargs: Any,
) -> Path | None:
    """Run A and log it beside the engine (and C1, when given). Never raises."""
    payload: dict[str, object] = {
        "run_id": run_id,
        "gameweek": gameweek,
        "model": MODEL_NAME,
        "affects_live_recommendation": False,
        "engine": {"model": "engine", **_option(engine.recommended)},
    }
    if challenger is not None:
        payload["challenger"] = {"model": "c1_gbm_xg_minutes", **_option(challenger.recommended)}
    try:
        rec = run_shadow_a(gameweek=gameweek, **kwargs)
        payload.update(
            status="ok",
            shadow={"model": MODEL_NAME, **_option(rec.recommended)},
            shadow_rationale=rec.rationale,
        )
    except Exception as exc:
        log.warning("shadow.a_failed", extra={"error": repr(exc)})
        payload.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
    try:
        gold.mkdir(parents=True, exist_ok=True)
        path = gold / SHADOW_A_FILENAME
        path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
        return path
    except Exception as exc:
        log.warning("shadow.a_unwritable", extra={"error": repr(exc)})
        return None
