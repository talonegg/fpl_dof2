"""football-data.co.uk pre-closing match odds, used only as a logged shadow input to C1."""
