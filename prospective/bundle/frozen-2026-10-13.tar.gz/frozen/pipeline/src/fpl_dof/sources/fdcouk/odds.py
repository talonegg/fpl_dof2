"""football-data.co.uk pre-closing 1X2 and O/U 2.5 odds → implied team goals and clean sheets.

**Shadow input only.** The C1 challenger logs these numbers beside its picks; neither the champion
nor C1's published picks read them; they are logged only.

**Pre-closing columns only.** The site publishes pre-closing averages (``AvgH``, ``AvgD``,
``AvgA``, ``Avg>2.5``, ``Avg<2.5``), collected on Friday afternoon for weekend games and Tuesday
afternoon for midweek ones, and closing ones with an extra ``C`` (``AvgCH`` …). Closing odds are
taken at kick-off, after the FPL deadline, so reading them would be look-ahead; :data:`PRE_CLOSING`
is the complete list of columns read and :func:`parse_pre_closing` refuses anything else.

**Terms and politeness.** The data is published free for use; robots.txt allows general crawling
(``User-agent: * / Disallow:``) and is checked before each fetch. One small file
(``fixtures.csv``, ~60 KB) is fetched at most once per :data:`CACHE_TTL_SECONDS` through the
shared :class:`~fpl_dof.sources.fetch.Fetcher`, which rate-limits, identifies the project honestly
and keeps the snapshot in bronze. Attribution: "Data from football-data.co.uk".
"""

from __future__ import annotations

import datetime as dt
import io
import re
import urllib.robotparser
from collections.abc import Mapping

import pandas as pd

from fpl_dof.frames import as_float, as_int
from fpl_dof.obs.logging import get_logger
from fpl_dof.sources.fetch import Fetcher
from fpl_dof.sources.oddsapi.market import devig, fit_goal_expectations

log = get_logger(__name__)

SOURCE = "fdcouk"
SOURCE_VERSION = "1"
BASE_URL = "https://www.football-data.co.uk"
FIXTURES_PATH = "fixtures.csv"
DIVISION = "E0"  # Premier League
CACHE_TTL_SECONDS = 12 * 3600
ATTRIBUTION = "Data from football-data.co.uk (pre-closing average odds)"

#: The only odds columns ever read. All pre-closing market averages.
PRE_CLOSING: dict[str, str] = {
    "AvgH": "home",
    "AvgD": "draw",
    "AvgA": "away",
    "Avg>2.5": "over",
    "Avg<2.5": "under",
}
_CLOSING = re.compile(r"^(Avg|Max|B365|BFE|BFD|BV|BW|PS|PP|SKB|WH|IW|VC|1XB)C")

#: football-data.co.uk team name → FPL team name, where they differ beyond a suffix.
ALIASES: dict[str, str] = {
    "Man United": "Man Utd",
    "Tottenham": "Spurs",
    "Nott'm Forest": "Nott'm Forest",
    "Nottingham Forest": "Nott'm Forest",
    "Sheffield United": "Sheffield Utd",
    "Wolverhampton": "Wolves",
}


class OddsParseError(ValueError):
    """The file is not in the shape this module reads."""


def is_closing_column(name: str) -> bool:
    return bool(_CLOSING.match(name))


def parse_pre_closing(payload: bytes | str, *, division: str = DIVISION) -> pd.DataFrame:
    """Rows of ``division`` with only the pre-closing odds, renamed to home/draw/away/over/under.

    Rows missing any of the five prices are dropped (a fixture the site has no market for yet).
    """
    text = payload.decode("utf-8-sig") if isinstance(payload, bytes) else payload.lstrip("\ufeff")
    raw = pd.read_csv(io.StringIO(text))
    needed = ["Div", "Date", "HomeTeam", "AwayTeam", *PRE_CLOSING]
    missing = [c for c in needed if c not in raw.columns]
    if missing:
        raise OddsParseError(f"missing columns {missing}")
    selected = [*needed, *(["Time"] if "Time" in raw.columns else [])]
    assert not any(is_closing_column(c) for c in selected), "closing odds must never be read"
    frame = raw.loc[raw["Div"] == division, selected].rename(columns=PRE_CLOSING)
    for c in PRE_CLOSING.values():
        frame[c] = pd.to_numeric(frame[c], errors="coerce")
    frame = frame.dropna(subset=list(PRE_CLOSING.values()))
    return frame.rename(columns={"HomeTeam": "home_name", "AwayTeam": "away_name"}).reset_index(
        drop=True
    )


def _norm(name: str) -> str:
    return re.sub(r"[^a-z]", "", name.lower())


def team_name_map(teams: pd.DataFrame) -> dict[str, int]:
    """football-data.co.uk name → FPL ``team_id``. Exact, alias, then unique-prefix matching."""
    by_norm = {_norm(str(n)): int(i) for n, i in zip(teams["name"], teams["team_id"], strict=True)}

    class _Resolver(dict[str, int]):
        def __missing__(self, key: str) -> int:
            target = _norm(ALIASES.get(key, key))
            if target in by_norm:
                return by_norm[target]
            hits = [i for n, i in by_norm.items() if n.startswith(target) or target.startswith(n)]
            if len(hits) == 1:
                return hits[0]
            raise KeyError(key)

    return _Resolver()


def implied_team_markets(
    odds: pd.DataFrame,
    *,
    teams: pd.DataFrame,
    fixtures: pd.DataFrame,
    gameweek: int,
) -> pd.DataFrame:
    """Per team in ``gameweek``: implied goals for/against and clean-sheet probability.

    Matches odds rows to the gameweek's fixtures by (home, away) team. Unmatched rows are ignored.
    Columns: team_id, fixture_id, odds_goals_for, odds_goals_against, odds_clean_sheet,
    odds_win, odds_residual. Double gameweeks give one row per fixture.
    """
    names = team_name_map(teams)
    fx = fixtures[fixtures["gameweek"] == gameweek]
    by_pair = {
        (int(h), int(a)): int(f)
        for h, a, f in zip(fx["home_team_id"], fx["away_team_id"], fx["fixture_id"], strict=True)
    }
    rows: list[dict[str, object]] = []
    for r in odds.itertuples(index=False):
        try:
            home, away = names[str(r.home_name)], names[str(r.away_name)]
        except KeyError:
            continue
        fixture_id = by_pair.get((home, away))
        if fixture_id is None:
            continue
        result = devig(
            {"home": as_float(r.home), "draw": as_float(r.draw), "away": as_float(r.away)}
        )
        over = devig({"over": as_float(r.over), "under": as_float(r.under)})["over"]
        g = fit_goal_expectations(result=result, over=over, line=2.5)
        common = {"fixture_id": fixture_id, "odds_residual": g.residual}
        rows.append(
            dict(
                common,
                team_id=home,
                odds_goals_for=g.expected_goals_home,
                odds_goals_against=g.expected_goals_away,
                odds_clean_sheet=g.clean_sheet_probability_home,
                odds_win=g.home_win_probability,
            )
        )
        rows.append(
            dict(
                common,
                team_id=away,
                odds_goals_for=g.expected_goals_away,
                odds_goals_against=g.expected_goals_home,
                odds_clean_sheet=g.clean_sheet_probability_away,
                odds_win=g.away_win_probability,
            )
        )
    cols = [
        "team_id",
        "fixture_id",
        "odds_goals_for",
        "odds_goals_against",
        "odds_clean_sheet",
        "odds_win",
        "odds_residual",
    ]
    return pd.DataFrame(rows, columns=cols)


def fetch_fixture_odds(
    fetcher: Fetcher,
    *,
    now: dt.datetime | None = None,
    force_refresh: bool = False,
) -> pd.DataFrame:
    """Polite fetch of ``fixtures.csv`` (robots-checked, cached for 12 h in bronze), then parse."""
    robots = fetcher.fetch(
        f"{BASE_URL}/robots.txt",
        source=SOURCE,
        source_version=SOURCE_VERSION,
        resource="robots",
        key="robots",
        cache_ttl_seconds=7 * 24 * 3600,
        now=now,
        suffix=".txt.gz",
    )
    parser = urllib.robotparser.RobotFileParser()
    parser.parse(robots.payload.decode("utf-8", errors="replace").splitlines())
    url = f"{BASE_URL}/{FIXTURES_PATH}"
    if not parser.can_fetch("*", url):
        raise PermissionError(f"robots.txt disallows {url}")
    fetched = fetcher.fetch(
        url,
        source=SOURCE,
        source_version=SOURCE_VERSION,
        resource="fixtures",
        key="fixtures",
        cache_ttl_seconds=CACHE_TTL_SECONDS,
        force_refresh=force_refresh,
        now=now,
        suffix=".csv.gz",
    )
    return parse_pre_closing(fetched.payload)


def summarise(
    markets: pd.DataFrame, names: Mapping[int, str] | None = None
) -> list[dict[str, object]]:
    """JSON-friendly rows for the shadow log."""
    out: list[dict[str, object]] = []
    for r in markets.itertuples(index=False):
        row: dict[str, object] = {
            "team_id": as_int(r.team_id),
            "fixture_id": as_int(r.fixture_id),
            "implied_goals_for": round(as_float(r.odds_goals_for), 3),
            "implied_goals_against": round(as_float(r.odds_goals_against), 3),
            "clean_sheet_probability": round(as_float(r.odds_clean_sheet), 3),
            "win_probability": round(as_float(r.odds_win), 3),
            "fit_residual": round(as_float(r.odds_residual), 5),
        }
        if names is not None:
            row["team"] = names.get(as_int(r.team_id))
        out.append(row)
    return out


def market_odds_block(
    fetcher: Fetcher,
    *,
    teams: pd.DataFrame,
    fixtures: pd.DataFrame,
    gameweek: int,
    deadline_utc: dt.datetime,
    now: dt.datetime,
    force_refresh: bool = False,
    offline: bool = False,
) -> dict[str, object]:
    """The shadow log block for ``gameweek``. Raises on any failure; the caller makes it fail-safe.

    Refuses to fetch at or after the deadline: odds read then would be post-deadline information.
    """
    if now >= deadline_utc:
        raise RuntimeError("deadline has passed; odds read now would be look-ahead")
    if offline:
        raise RuntimeError("offline run; odds not fetched")
    odds = fetch_fixture_odds(fetcher, now=now, force_refresh=force_refresh)
    markets = implied_team_markets(odds, teams=teams, fixtures=fixtures, gameweek=gameweek)
    names = {int(i): str(n) for i, n in zip(teams["team_id"], teams["name"], strict=True)}
    return {
        "source": ATTRIBUTION,
        "columns": list(PRE_CLOSING),
        "fetched_at": now.isoformat(),
        "fixtures_matched": int(markets["fixture_id"].nunique()) if len(markets) else 0,
        "teams": summarise(markets, names),
    }
