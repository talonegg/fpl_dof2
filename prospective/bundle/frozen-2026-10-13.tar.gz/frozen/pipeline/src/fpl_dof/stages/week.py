"""Week stage — the weekly recommendation, in one pass.

Runs after ``forecast``. Loads the squad as it actually stands, ranks doing nothing against every
affordable transfer, picks the resulting XI, collects the alerts, works out both deadlines, and
reconciles the last gameweek's advice against what was played.

The success test for E1 is not accuracy, it is **elapsed attention**: "it is Thursday evening" to
"I know what I am doing and why" in under fifteen minutes. So this stage writes one artefact that
answers the whole question rather than several that each answer part of it.

It is skipped, with a reason, when no squad can be established. That is the normal preseason state
(DL-20) and must not fail a run that is otherwise fine — the forecast and the E0 squad are still
worth publishing.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from fpl_dof.forecast.form import form_by_player_id, trailing_form
from fpl_dof.frames import as_float, as_int
from fpl_dof.obs.logging import get_logger
from fpl_dof.obs.manifest import utcnow
from fpl_dof.optimise.captain import (
    apply_price_position_captain,
    price_position_scores,
    relabel_selection,
)
from fpl_dof.optimise.transfer import TransferRecommendation, recommend_transfers
from fpl_dof.pipeline import Output, StageContext, StageResult
from fpl_dof.rules.models import GameRules, Position
from fpl_dof.shadow.a import run_shadow_a_safely
from fpl_dof.shadow.c1 import MODEL_NAME as C1_MODEL_NAME
from fpl_dof.shadow.c1 import Challenger, fit_challenger, run_shadow_safely
from fpl_dof.silver.store import read_table, read_table_optional
from fpl_dof.silver.tables import Table
from fpl_dof.squad.selection import Candidate, SelectionError, select_team
from fpl_dof.squad.state import (
    SquadState,
    SquadStateError,
    gameweek_price_index,
    load_squad_state,
)
from fpl_dof.stages.forecast import XP_FILENAME
from fpl_dof.stages.transform import read_rules
from fpl_dof.week.alerts import Alert, collect_alerts
from fpl_dof.week.deadline import DeadlineView, describe_deadline, next_deadline, to_contract
from fpl_dof.week.ledger import read_advice, record_advice
from fpl_dof.week.reconcile import Reconciliation, reconcile

log = get_logger(__name__)

WEEK_FILENAME = "week.json"
CHALLENGER_FILENAME = "week_challenger.json"
CHAMPION_MODEL = {"id": "engine", "label": "Champion", "role": "champion"}
CHALLENGER_MODEL = {"id": C1_MODEL_NAME, "label": "Challenger (C1)", "role": "challenger"}
SKIPPED_REASON_KEY = "skipped_reason"


def run(ctx: StageContext) -> StageResult:
    rules = read_rules(ctx, ctx.config.rules.season)
    season = rules.season
    silver = ctx.layout.silver
    gold = ctx.layout.gold / f"season={season.replace('/', '-')}"

    gameweeks = read_table(silver, season, Table.GAMEWEEK)
    players = read_table(silver, season, Table.PLAYER)
    forecast = pd.read_parquet(gold / XP_FILENAME)
    forecast["start_floor"] = ctx.config.forecast.minimum_start_probability_for_xi

    deadline = next_deadline(
        gameweeks,
        now=utcnow(),
        local_zone=ctx.config.runtime.timezone,
        decide_by_hours=ctx.config.alerts.decide_by_hours_before_deadline,
    )

    picks = read_table_optional(silver, season, Table.ENTRY_PICK)
    try:
        state = load_squad_state(
            entry_config=ctx.config.entry,
            rules=rules,
            players=players,
            next_gameweek=deadline.gameweek,
            picks=picks,
            transfers=read_table_optional(silver, season, Table.ENTRY_TRANSFER),
            entry=read_table_optional(silver, season, Table.ENTRY),
            chips=read_table_optional(silver, season, Table.ENTRY_CHIP),
            gameweek_prices=gameweek_price_index(
                read_table_optional(silver, season, Table.PLAYER_GAMEWEEK)
            ),
        )
    except SquadStateError as exc:
        # Degrade rather than break (DP-15). The forecast is still good; there is simply no squad
        # to advise on yet.
        log.warning("week.skipped", extra={"reason": str(exc)})
        path = _write(
            gold,
            {
                "run_id": ctx.run_id,
                "skipped": True,
                SKIPPED_REASON_KEY: str(exc),
                "deadline": to_contract(deadline),
            },
        )
        return StageResult(
            metrics={"status": "skipped", SKIPPED_REASON_KEY: str(exc)},
            outputs=[Output(path=path)],
        )

    recommendation = recommend_transfers(
        forecast, state, rules, ctx.config.transfers, ctx.config.optimiser
    )
    history_all = read_table_optional(silver, season, Table.PLAYER_GAMEWEEK)
    scores: dict[int, float] | None = None
    if ctx.config.optimiser.captain_rule == "price_position":
        scores = price_position_scores(forecast, history_all)
        if scores is None:
            log.warning("week.captain_rule_fallback", extra={"reason": "no history to fit B0"})
        else:
            recommendation = apply_price_position_captain(
                recommendation, forecast, scores, ctx.config.optimiser.captain_multiplier
            )
    alerts = collect_alerts(
        state=state,
        players=players,
        rules=rules,
        config=ctx.config.alerts,
        current_gameweek=deadline.gameweek,
        chips=read_table_optional(silver, season, Table.CHIP),
    )
    reconciliation = _reconcile_previous(ctx, gold, picks, deadline.gameweek)

    player_gameweek = read_table_optional(silver, season, Table.PLAYER_GAMEWEEK)
    if player_gameweek is not None and "season" in player_gameweek.columns:
        player_gameweek = player_gameweek[player_gameweek["season"] == season]
    form = form_by_player_id(trailing_form(player_gameweek, as_of=pd.Timestamp(utcnow())), forecast)

    payload = _payload(
        ctx=ctx,
        rules=rules,
        state=state,
        forecast=forecast,
        recommendation=recommendation,
        alerts=alerts,
        deadline=deadline,
        reconciliation=reconciliation,
        form=form,
        captain_scores=scores,
    )
    payload["model"] = CHAMPION_MODEL
    path = _write(gold, payload)
    record_advice(ctx.layout, payload)

    # C1 shadow: logged beside the engine, never read back into the live recommendation, and
    # isolated so any failure of it is a warning in shadow_c1.json rather than a failed run.
    #
    # Champion/challenger: the same fitted C1 is also published in full as week_challenger.json.
    # The champion is already on disk by now, so nothing here can stop it publishing.
    shadow_path = None
    shadow_a_path = None
    challenger_path = None
    challenger_rec: TransferRecommendation | None = None
    (gold / CHALLENGER_FILENAME).unlink(missing_ok=True)  # never leave a stale challenger behind
    if ctx.config.optimiser.shadow_c1:
        # Shadow-only market input: pre-closing odds, logged beside C1's picks. Never read by the
        # champion, and never by C1's picks either; fetched and parsed fail-safe.
        shadow_inputs = (
            _shadow_odds_safely(ctx, silver, season, deadline)
            if ctx.config.optimiser.shadow_c1_odds
            else None
        )
        c1_inputs: dict[str, Any] = {
            "forecast": forecast,
            "history": history_all if history_all is not None else pd.DataFrame(),
            "players": players,
            "fixtures": _read_fixtures(silver, season),
            "state": state,
            "rules": rules,
            "transfer_config": ctx.config.transfers,
            "optimiser_config": ctx.config.optimiser,
        }
        challenger: Challenger | BaseException
        try:
            challenger = fit_challenger(gameweek=deadline.gameweek, **c1_inputs)
        except Exception as exc:
            challenger = exc
        if isinstance(challenger, Challenger):
            challenger_rec = challenger.recommendation
        if ctx.config.optimiser.publish_challenger and isinstance(challenger, Challenger):
            challenger_path = _write_challenger_safely(
                gold,
                challenger,
                ctx=ctx,
                rules=rules,
                state=state,
                alerts=alerts,
                deadline=deadline,
                reconciliation=reconciliation,
                form=form,
            )
        shadow_path = run_shadow_safely(
            gold=gold,
            run_id=ctx.run_id,
            gameweek=deadline.gameweek,
            engine=recommendation,
            result=challenger,
            shadow_inputs=shadow_inputs,
            forecast=forecast,
            history=history_all if history_all is not None else pd.DataFrame(),
            players=players,
            fixtures=_read_fixtures(silver, season),
            state=state,
            rules=rules,
            transfer_config=ctx.config.transfers,
            optimiser_config=ctx.config.optimiser,
        )

    # Model A shadow: a third model logged beside the engine (and C1), after both live artefacts
    # are on disk. It works on copies, is never read back, and cannot raise (shadow_a.json).
    if ctx.config.optimiser.shadow_a:
        shadow_a_path = run_shadow_a_safely(
            gold=gold,
            run_id=ctx.run_id,
            gameweek=deadline.gameweek,
            engine=recommendation,
            challenger=challenger_rec,
            forecast=forecast,
            history=history_all if history_all is not None else pd.DataFrame(),
            players=players,
            fixtures=_read_fixtures(silver, season),
            state=state,
            rules=rules,
            transfer_config=ctx.config.transfers,
            optimiser_config=ctx.config.optimiser,
        )

    for line in [
        *describe_deadline(deadline),
        f"Squad provenance: {state.provenance.value}",
        f"Recommendation: {recommendation.rationale}",
    ]:
        log.info("week.summary", extra={"line": line})

    return StageResult(
        metrics={
            "status": "ok",
            "gameweek": deadline.gameweek,
            "provenance": state.provenance.value,
            "transfers": recommendation.recommended.transfers,
            "net_xp": recommendation.recommended.net_expected_points,
            "gain_over_roll": recommendation.recommended.gain_over(recommendation.roll),
            "free_transfers": state.free_transfers,
            "alerts": len(alerts),
            "urgent_alerts": sum(1 for a in alerts if a.severity.label == "urgent"),
        },
        outputs=[
            Output(path=path, rows=len(state.players)),
            *([Output(path=shadow_path)] if shadow_path is not None else []),
            *([Output(path=shadow_a_path)] if shadow_a_path is not None else []),
            *([Output(path=challenger_path)] if challenger_path is not None else []),
        ],
    )


def _write_challenger_safely(
    gold: Path,
    challenger: Challenger,
    *,
    ctx: StageContext,
    rules: GameRules,
    state: SquadState,
    alerts: list[Alert],
    deadline: DeadlineView,
    reconciliation: Reconciliation | None,
    form: dict[int, tuple[float | None, int | None]] | None,
) -> Path | None:
    """C1's answer in week.json's own schema. Never raises: the challenger cannot fail the run."""
    try:
        payload = _payload(
            ctx=ctx,
            rules=rules,
            state=state,
            forecast=challenger.forecast,
            recommendation=challenger.recommendation,
            alerts=alerts,
            deadline=deadline,
            reconciliation=reconciliation,
            form=form,
            captain_scores=challenger.captain_scores,
        )
        payload["model"] = CHALLENGER_MODEL
        path = gold / CHALLENGER_FILENAME
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path
    except Exception as exc:
        log.warning("week.challenger_failed", extra={"error": repr(exc)})
        (gold / CHALLENGER_FILENAME).unlink(missing_ok=True)
        return None


def _shadow_odds_safely(
    ctx: StageContext, silver: Path, season: str, deadline: DeadlineView
) -> dict[str, Any]:
    """Pre-closing market odds for the upcoming GW as a shadow-log block. Never raises."""
    from fpl_dof.sources import BronzeStore, Fetcher, market_odds_block

    block: dict[str, Any] = {"affects_picks": False}
    try:
        with Fetcher(
            config=ctx.config.http, bronze=BronzeStore(ctx.layout.bronze), run_id=ctx.run_id
        ) as fetcher:
            block.update(
                market_odds_block(
                    fetcher,
                    teams=read_table(silver, season, Table.TEAM),
                    fixtures=_read_fixtures(silver, season),
                    gameweek=deadline.gameweek,
                    deadline_utc=deadline.deadline_utc,
                    now=utcnow(),
                    force_refresh=ctx.options.force_refresh,
                    offline=ctx.options.offline,
                )
            )
        block["status"] = "ok"
    except Exception as exc:
        log.warning("shadow.c1_odds_failed", extra={"error": repr(exc)})
        block.update(status="failed", error=repr(exc))
    return block


def _read_fixtures(silver: Path, season: str) -> pd.DataFrame:
    try:
        return read_table(silver, season, Table.FIXTURE)
    except Exception:
        return pd.DataFrame()


def _write(gold: Path, payload: dict[str, object]) -> Path:
    gold.mkdir(parents=True, exist_ok=True)
    path = gold / WEEK_FILENAME
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def _reconcile_previous(
    ctx: StageContext,
    gold: Path,
    picks: pd.DataFrame | None,
    next_gameweek: int,
) -> Reconciliation | None:
    """Diff last gameweek's advice against what was played, if both exist.

    Reads the advice *as it was recorded at the time* — the ledger first (DL-69), and the
    previously written week.json as the fallback a pre-ledger run left behind — which is what
    makes this evidence rather than recollection: not as it is remembered, and not as it would be
    recomputed now with hindsight.
    """
    if picks is None or picks.empty or ctx.config.entry.team_id is None:
        return None
    previous_gameweek = next_gameweek - 1
    if previous_gameweek < 1:
        return None

    advised: object = None
    recorded = read_advice(ctx.layout, previous_gameweek)
    if recorded is not None:
        advised = recorded.get("advised")
    else:
        path = gold / WEEK_FILENAME
        if not path.exists():
            return None
        try:
            previous = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            log.warning("week.previous_unreadable", extra={"path": str(path)})
            return None
        advised = previous.get("advised")
    if not isinstance(advised, dict) or advised.get("gameweek") != previous_gameweek:
        return None

    try:
        return reconcile(
            gameweek=previous_gameweek,
            entry_id=ctx.config.entry.team_id,
            advised=advised,
            picks=picks,
        )
    except ValueError as exc:
        log.info("week.reconcile_skipped", extra={"reason": str(exc)})
        return None


def _payload(
    *,
    ctx: StageContext,
    rules: GameRules,
    state: SquadState,
    forecast: pd.DataFrame,
    recommendation: TransferRecommendation,
    alerts: list[Alert],
    deadline: DeadlineView,
    reconciliation: Reconciliation | None,
    form: dict[int, tuple[float | None, int | None]] | None = None,
    captain_scores: dict[int, float] | None = None,
) -> dict[str, object]:
    chosen = recommendation.recommended
    lookup = forecast.set_index("player_id")
    form = form or {}

    def side(player_id: int, name: str, price: float) -> dict[str, object]:
        """One side of a move, with both rankings' numbers on it (DL-70)."""
        xp = 0.0
        if player_id in lookup.index:
            xp = round(as_float(lookup.loc[player_id, "xp_next"]), 3)
        return {
            "player_id": player_id,
            "web_name": name,
            "price": price,
            "xp_next": xp,
            "form_points_per_match": form.get(player_id, (None, None))[0],
        }

    candidates = {
        player_id: Candidate(
            player_id=player_id,
            position=Position(str(lookup.loc[player_id, "position"])),
            expected_points=as_float(lookup.loc[player_id, "xp_next"]),
            start_probability=as_float(lookup.loc[player_id, "start_probability"]),
            web_name=str(lookup.loc[player_id, "web_name"]),
        )
        for player_id in chosen.squad_after
    }
    floor = (
        ctx.config.forecast.minimum_start_probability_for_xi
        if ctx.config.optimiser.enforce_start_probability_floor
        else 0.0
    )
    locked = frozenset(ctx.config.optimiser.locked_player_ids)
    extra_warnings: list[str] = []
    try:
        selection = select_team(
            candidates,
            rules,
            captain_multiplier=ctx.config.optimiser.captain_multiplier,
            start_probability_floor=floor,
            locked_player_ids=locked,
        )
    except SelectionError as exc:
        # The advised squad cannot field an XI above the floor. Pick the best XI it *can* field
        # and say so, rather than publishing nothing in the week it matters (DP-15).
        log.warning("week.floor_relaxed", extra={"reason": str(exc)})
        extra_warnings.append(
            f"the advised XI is chosen with the start-probability floor relaxed: {exc}"
        )
        selection = select_team(
            candidates,
            rules,
            captain_multiplier=ctx.config.optimiser.captain_multiplier,
            start_probability_floor=0.0,
            locked_player_ids=locked,
        )
    if captain_scores is not None:
        selection = relabel_selection(
            selection,
            captain_scores,
            {as_int(i): as_float(v) for i, v in lookup["xp_next"].items()},
            ctx.config.optimiser.captain_multiplier,
        )

    return {
        "run_id": ctx.run_id,
        "skipped": False,
        "deadline": to_contract(deadline),
        "squad_state": {
            "provenance": state.provenance.value,
            "entry_id": state.entry_id,
            "as_of_gameweek": state.as_of_gameweek,
            "bank": state.bank,
            "sell_value": state.sell_value(rules),
            "budget": state.budget(rules),
            "free_transfers": state.free_transfers,
            "chips_used": list(state.chips_used),
            "warnings": list(state.warnings),
        },
        "recommendation": {
            "rationale": recommendation.rationale,
            "is_roll": recommendation.is_roll(),
            "transfers": chosen.transfers,
            "hit_points": chosen.hit_points,
            "net_expected_points": chosen.net_expected_points,
            "gain_over_roll": chosen.gain_over(recommendation.roll),
            "bank_after": chosen.bank_after,
            "moves": [
                {
                    "out": side(move.player_out_id, move.player_out_name, move.selling_price),
                    "in": side(move.player_in_id, move.player_in_name, move.buying_price),
                }
                for move in chosen.moves
            ],
            "options": [
                {
                    "transfers": option.transfers,
                    "hit_points": option.hit_points,
                    "net_expected_points": option.net_expected_points,
                    "gain_over_roll": option.gain_over(recommendation.roll),
                    "moves": [move.describe() for move in option.moves],
                }
                for option in sorted(recommendation.options, key=lambda o: o.transfers)
            ],
            "warnings": [*recommendation.warnings, *extra_warnings],
        },
        "advised": {
            "gameweek": deadline.gameweek,
            "squad": list(chosen.squad_after),
            "starting": list(selection.starting),
            "bench_order": list(selection.bench_order),
            "reserve_goalkeeper": selection.reserve_goalkeeper,
            "captain": selection.captain,
            "vice_captain": selection.vice_captain,
            "formation": selection.formation,
            "expected_points": selection.expected_points,
        },
        "alerts": [alert.as_dict() for alert in alerts],
        "reconciliation": reconciliation.as_dict() if reconciliation else None,
    }
