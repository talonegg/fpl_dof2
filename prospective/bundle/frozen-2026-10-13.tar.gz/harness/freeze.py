#!/usr/bin/env python3
"""One-off: write manifest.json (create-only). Refuses if it exists."""
import sys; sys.path.insert(0, "/workspace/fpl_prospective/prospective")
from common import MANIFEST, now_utc, write_json_new, canon, sha256_bytes
from freeze_lib import compute, git
from models import FROZEN_TAG
if MANIFEST.exists():
    sys.exit("manifest.json already exists; the freeze is immutable")
if git("status", "--porcelain", "--untracked-files=no"):
    sys.exit("frozen worktree has uncommitted tracked changes")
m = compute(); m["frozen_at"] = now_utc().isoformat()
m["manifest_body_sha256"] = sha256_bytes(canon({k: v for k, v in m.items() if k != "frozen_at"}))
write_json_new(MANIFEST, m)
print("froze", FROZEN_TAG, m["code_commit"]); [print(f"  {k}: config {v['config_sha256'][:12]} source {v['source_sha256'][:12]}") for k, v in m["models"].items()]
