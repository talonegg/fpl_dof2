"""Shared paths, FPL API access (polite, cached per run) and hashing for prospective scoring."""
from __future__ import annotations
import hashlib, json, os, time, urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(os.environ.get("FPL_PROSPECTIVE_ROOT", "/workspace/fpl_prospective"))
FROZEN_REPO = Path("/workspace/fpl_dof2_frozen")
PY = "/workspace/fpl_dof2/.venv/bin/python"
DATA_DIR = Path(os.environ.get("FPL_PROSPECTIVE_DATA", str(ROOT / "data")))
DECISIONS = ROOT / "decisions"
STATE = ROOT / "state"
RAW = ROOT / "raw"
SCORES = ROOT / "scores.csv"
REPORT = ROOT / "report.md"
MANIFEST = ROOT / "manifest.json"
SEASON = "2026/27"
API = "https://fantasy.premierleague.com/api/"
UA = "fpl-dof-prospective/1.0 (personal, low-rate)"
POS = {1: "GKP", 2: "DEF", 3: "MID", 4: "FWD"}
MIN_GAP = 1.0  # seconds between API calls (self-imposed rate limit)
_last = [0.0]


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p: Path) -> str:
    return sha256_bytes(Path(p).read_bytes())


def canon(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()


def get(url: str, retries: int = 3, raw: bool = False):
    for k in range(retries):
        wait = MIN_GAP - (time.time() - _last[0])
        if wait > 0:
            time.sleep(wait)
        _last[0] = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as r:
                b = r.read()
            return b if raw else json.loads(b)
        except Exception:
            if k == retries - 1:
                raise
            time.sleep(5 * (k + 1))


def fpl(path: str):
    return get(API + path)


def events(bootstrap):
    return {e["id"]: e for e in bootstrap["events"]}


def next_event(bootstrap):
    return next((e for e in bootstrap["events"] if e["is_next"]), None)


def parse_ts(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def team_id() -> int:
    """FPL_DOF_TEAM_ID env (same variable the repo pipeline uses), else the repo config entry.team_id."""
    v = os.environ.get("FPL_DOF_TEAM_ID")
    if v:
        return int(v)
    p = ROOT / "team_id.txt"
    if p.exists():
        return int(p.read_text().strip())
    raise SystemExit("No team id: set FPL_DOF_TEAM_ID or write it to team_id.txt")


def write_json_new(p: Path, obj) -> None:
    """Create-only write: never overwrites an existing file."""
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "x") as f:
        json.dump(obj, f, indent=2, sort_keys=True, default=str)
