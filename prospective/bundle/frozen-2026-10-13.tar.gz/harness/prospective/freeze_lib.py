"""Compute every hash the manifest records; shared by freeze.py and verify.py."""
from __future__ import annotations
import subprocess
from pathlib import Path
from common import FROZEN_REPO, ROOT, canon, sha256_bytes, sha256_file
from models import COMMON_DIRS, COMMON_FILES, FROZEN_TAG, HARNESS_FILES, MODELS


def git(*a) -> str:
    return subprocess.check_output(["git", "-C", str(FROZEN_REPO), *a], text=True).strip()


def common_files() -> list[str]:
    out = list(COMMON_FILES)
    for d in COMMON_DIRS:
        out += sorted(str(p.relative_to(FROZEN_REPO)) for p in (FROZEN_REPO / d).rglob("*")
                      if p.suffix in (".py", ".yaml") and "__pycache__" not in p.parts)
    return out


def compute() -> dict:
    repo_files = {f: sha256_file(FROZEN_REPO / f) for f in common_files()}
    harness = {f: sha256_file(ROOT / f) for f in HARNESS_FILES}
    models = {}
    for name, m in MODELS.items():
        files = {f: sha256_file(FROZEN_REPO / f) for f in m["files"]}
        allh = {**{"repo:" + k: v for k, v in repo_files.items()}, **{"repo:" + k: v for k, v in files.items()},
                **{"harness:" + k: v for k, v in harness.items()}}
        models[name] = dict(name=name, description=m["description"], config=m["config"],
                            config_sha256=sha256_bytes(canon(m["config"])),
                            model_files_sha256=files, source_sha256=sha256_bytes(canon(allh)))
    return dict(frozen_tag=FROZEN_TAG, code_commit=git("rev-parse", FROZEN_TAG + "^{commit}"),
                source_commits={"forge/odds-team-layer": "4b11f8f", "forge/autosubs (autosubs.py only)": "3de5329"},
                repo_path=str(FROZEN_REPO), common_files_sha256=repo_files, harness_files_sha256=harness,
                models=models)
