"""Subprocess entry points (one fresh interpreter per model, so no model can leak state into another).

    model_runner.py folds <inputs_dir>          shared walk-forward feature folds -> training/merged parquet
    model_runner.py predict <model> <inputs_dir>  frozen model -> xp_<model>.parquet (player frame)
"""
from __future__ import annotations
import json, logging, sys
from pathlib import Path
sys.path.insert(0, "/workspace/fpl_dof2_frozen/backtest")
sys.path.insert(0, "/workspace/fpl_prospective/prospective")
import os; os.chdir("/workspace/fpl_dof2_frozen")
import numpy as np
import pandas as pd

logging.disable(logging.WARNING)


def _meta(d):
    m = json.loads((d / "meta.json").read_text())
    return m["gw"], pd.Timestamp(m["deadline"]), m["season"]


def folds(d: Path):
    import backtest as bt
    from fpl_dof.forecast.backtest import deadlines_for, fold_rows, training_rows
    from fpl_dof.forecast.features import assert_no_look_ahead
    gw, deadline, season = _meta(d)
    h = pd.read_parquet(d / "history.parquet")
    cfg = bt.CFG()
    cache = {}
    for s, g, dl in deadlines_for(h[h.kickoff_time < deadline]):
        m = fold_rows(h, s, g, dl, cfg.forecast)
        if not m.empty:
            cache[dl] = m
    merged = fold_rows(h, season, gw, deadline, cfg.forecast)
    past = h[h.kickoff_time < deadline]
    assert not merged.empty, "no visible rows for the upcoming GW"
    assert_no_look_ahead(merged, past, as_of=deadline)
    cache[deadline] = merged
    training = training_rows(cache, before=deadline)
    assert (pd.to_datetime(training.get("kickoff_time", pd.Series([], dtype="datetime64[ns, UTC]")), utc=True) < deadline).all()
    training.to_parquet(d / "training.parquet"); merged.to_parquet(d / "merged.parquet")
    print(f"folds: {len(cache)-1} past folds, training {len(training)} rows, visible {len(merged)} rows")


def predict(name: str, d: Path):
    from models import MODELS
    c = MODELS[name]["config"]
    gw, deadline, season = _meta(d)
    h = pd.read_parquet(d / "history.parquet")
    if c["odds_team_layer"]:
        import odds_team as ot
        hist = ot.load()
        live = pd.read_parquet(d / "odds.parquet")
        both = pd.concat([hist, live], ignore_index=True) if len(live) else hist
        ot.load = lambda cache=True: both  # data injection only: historical + this GW's live pre-closing rows
        import ot_models  # noqa: F401  (registers comp_ot; reads ot.load() at import)
    import backtest as bt
    from fpl_dof.forecast.backtest import OUTCOME_COLUMNS
    import availability as av
    cfg = bt.CFG()
    from common import DATA_DIR
    rules, _ = bt.load(str(DATA_DIR), ["2026/27"])
    # history is recoded to stable club codes for every season (live_frame.history), so the D-26
    # current-season guard does not apply; label the season accordingly (only that guard reads it).
    rules = rules.model_copy(update={"season": "2026/27 (club-coded)"})
    training = pd.read_parquet(d / "training.parquet"); merged = pd.read_parquet(d / "merged.parquet")
    visible = merged.drop(columns=list(OUTCOME_COLUMNS) + ["selected_by"], errors="ignore")
    for k, v in c.get("forecast_flags", {}).items():  # explicit, so the frozen config default cannot shift a model
        cfg = cfg.model_copy(update={"forecast": bt._flag(cfg, tuple(k.split(".")), v)})
    model = bt.MODELS[c["factory"]](cfg, rules, h)
    b0 = bt.B0Model(cfg, rules, h)
    for m in (model, b0):
        if hasattr(m, "set_context"):
            m.set_context(season, gw, deadline)
        m.fit(training)
    pf = bt.player_frame(merged, np.asarray(model.predict(visible), dtype=float))
    pb = bt.player_frame(merged, np.asarray(b0.predict(visible), dtype=float)).set_index("player_id")["xp_next"]
    pf["xp_b0"] = pf.player_id.map(pb).fillna(0.0)
    pf["season"], pf["gw"] = season, gw
    names = h[h.season == season].drop_duplicates("player_code", keep="last").set_index("player_code").web_name
    pf["web_name"] = pf.player_id.map(names)
    pf["selected_by"] = pd.to_numeric(pf["selected_by"], errors="coerce")
    if c["deadline_availability"]:
        a = pd.read_parquet(d / "avail.parquet").assign(season=season, gw=gw)
        pf = av.apply(pf, a)
    info = {}
    if hasattr(model, "used"):
        info = {"odds_rows_used": int(model.used), "odds_fallback_rows": int(model.fallback)}
    pf.to_parquet(d / f"xp_{name}.parquet")
    (d / f"xp_{name}.info.json").write_text(json.dumps(info))
    print(f"{name}: {len(pf)} players, top xp {pf.xp_next.max():.2f} {info}")


if __name__ == "__main__":
    if sys.argv[1] == "folds":
        folds(Path(sys.argv[2]))
    else:
        predict(sys.argv[2], Path(sys.argv[3]))
