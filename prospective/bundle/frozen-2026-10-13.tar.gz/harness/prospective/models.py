"""Frozen model registry: what each prospective model is. Changing anything here breaks the freeze
(this file itself is hashed into every model)."""
from __future__ import annotations

FROZEN_TAG = "frozen-2026-10-13"
COMMON_FILES = [
    "backtest/backtest.py", "backtest/availability.py", "backtest/autosubs.py",
    "config/ci-backtest.yaml",
]
COMMON_DIRS = [  # every .py/.yaml under these (pipeline code the models and optimiser import)
    "pipeline/src/fpl_dof/forecast", "pipeline/src/fpl_dof/optimise", "pipeline/src/fpl_dof/rules",
    "pipeline/src/fpl_dof/squad", "pipeline/src/fpl_dof/config",
]
HARNESS_FILES = [  # prospective harness, relative to /workspace/fpl_prospective
    "prospective/models.py", "prospective/common.py", "prospective/live_frame.py",
    "prospective/model_runner.py", "prospective/policy.py", "prospective/scoring.py",
    "prospective/freeze_lib.py", "decide.py", "score.py", "verify.py",
]

MODELS = {
    "engine": dict(
        description="Reference: original engine (xp_v1 ComponentPredictor with minutes_v2 forced OFF, since the frozen config default is now ON), engine captain/vice",
        config=dict(factory="baseline", forecast_flags={"discrimination.minutes_v2": False}, captain_rule="engine", vice_rule="engine", deadline_availability=True,
                    odds_team_layer=False, optimiser_overrides={"enforce_start_probability_floor": False}),
        files=[]),
    "C3": dict(
        description="Champion: engine + minutes_v2 + price/position (B0) captain; vice = 2nd by B0",
        config=dict(factory="minutes_v2", forecast_flags={"discrimination.minutes_v2": True}, captain_rule="b0", vice_rule="b0_second", deadline_availability=True,
                    odds_team_layer=False, optimiser_overrides={"enforce_start_probability_floor": False}),
        files=[]),
    "C1": dict(
        description="Challenger: per-position HistGBM xG model with minutes head (vec_xg2), B0 captain",
        config=dict(factory="vec_xg2", captain_rule="b0", vice_rule="b0_second", deadline_availability=True,
                    odds_team_layer=False, optimiser_overrides={"enforce_start_probability_floor": False}),
        files=["backtest/vector_models.py"]),
    "A": dict(
        description="Component xPts model A (comp_A), B0 captain",
        config=dict(factory="comp_A", captain_rule="b0", vice_rule="b0_second", deadline_availability=True,
                    odds_team_layer=False, optimiser_overrides={"enforce_start_probability_floor": False}),
        files=["backtest/vector_models.py", "backtest/comp_model.py"]),
    "A_odds": dict(
        description="A with the odds-driven team layer (comp_ot, Shin de-vig, pre-closing only), B0 captain",
        config=dict(factory="comp_ot", captain_rule="b0", vice_rule="b0_second", deadline_availability=True,
                    odds_team_layer=True, optimiser_overrides={"enforce_start_probability_floor": False}),
        files=["backtest/vector_models.py", "backtest/comp_model.py", "backtest/ot_models.py",
               "backtest/odds_team.py", "backtest/ds_features.py",
               "backtest/fdcouk/odds_team_fixtures.parquet", "backtest/fdcouk/E0_2324.csv",
               "backtest/fdcouk/E0_2425.csv", "backtest/fdcouk/E0_2526.csv",
               "backtest/fplcache/index.csv"]),
}
CHAMPION = "C3"
