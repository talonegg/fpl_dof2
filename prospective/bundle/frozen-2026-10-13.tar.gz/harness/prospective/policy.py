"""Decision layer, identical to the frozen backtest's simulate() step: the real recommend_transfers
(with the harness's club-cap grandfathering), then the model's captain/vice rule. Plus per-model
hypothetical squad state."""
from __future__ import annotations
import json
from collections import Counter
import pandas as pd
from fpl_dof.optimise.squad import InfeasibleError
from fpl_dof.optimise.transfer import recommend_transfers
from fpl_dof.squad.state import HeldPlayer, Provenance, SquadState, free_transfers_after


def to_state(st: dict, gw: int) -> SquadState:
    return SquadState(entry_id=None, gameweek=gw, players=tuple(
        HeldPlayer(player_id=p["code"], position=p["position"], team_id=p["team_code"],
                   current_price=p["current_price"], purchase_price=p["purchase_price"]) for p in st["players"]),
        bank=st["bank"], free_transfers=st["free_transfers"], chips_used=(), provenance=Provenance.DECLARED)


def decide(pf: pd.DataFrame, st: dict, gw: int, cfgm: dict, cfg, rules) -> tuple[dict, dict]:
    opt = cfg.optimiser.model_copy(update=cfgm["optimiser_overrides"])
    pf = pf.reset_index(drop=True)
    lookup = pf.set_index("player_id")
    missing = [p for p in st["players"] if p["code"] not in lookup.index]
    if missing:  # held player with no fixture this GW (blank) or no visible row: xP 0, as the backtest
        pf = pd.concat([pf, pd.DataFrame([{"player_id": p["code"], "position": p["position"], "team_id": p["team_code"],
                        "price": p["current_price"], "xp_next": 0.0, "xp_horizon": 0.0, "xp_b0": 0.0,
                        "start_probability": 1.0, "actual": 0.0, "minutes": 0, "selected_by": 0} for p in missing])], ignore_index=True)
        lookup = pf.set_index("player_id")
    for p in st["players"]:  # refresh current prices / clubs
        p["current_price"] = float(lookup.loc[p["code"], "price"]); p["team_code"] = int(lookup.loc[p["code"], "team_id"])
    state = to_state(st, gw)
    notes = []
    try:
        rec = recommend_transfers(pf, state, rules, cfg.transfers, opt)
    except InfeasibleError:
        cnt = Counter(p.team_id for p in state.players)
        over = {c for c, n in cnt.items() if n > rules.squad.club_limit}
        if not over:
            raise
        remap, seen = {}, Counter()
        for p in state.players:
            if p.team_id in over:
                seen[p.team_id] += 1
                if seen[p.team_id] > rules.squad.club_limit:
                    remap[p.player_id] = -p.player_id
        notes.append(f"club-cap grandfathering applied to {sorted(remap)}")
        pf = pf.copy(); pf.loc[pf.player_id.isin(remap), "team_id"] = pf.player_id.map(remap)
        lookup = pf.set_index("player_id")
        state = SquadState(entry_id=None, gameweek=gw, players=tuple(
            HeldPlayer(player_id=p.player_id, position=p.position, team_id=remap.get(p.player_id, p.team_id),
                       current_price=p.current_price, purchase_price=p.purchase_price) for p in state.players),
            bank=state.bank, free_transfers=state.free_transfers, chips_used=(), provenance=Provenance.DECLARED)
        rec = recommend_transfers(pf, state, rules, cfg.transfers, opt)
    o = rec.recommended
    xi = list(o.starting)
    key = "xp_b0"
    if cfgm["captain_rule"] == "engine":
        cap, vice = o.captain_id, o.vice_captain_id
    else:
        cap = max(xi, key=lambda i: float(lookup.loc[i, key]))
        vice = max((i for i in xi if i != cap), key=lambda i: float(lookup.loc[i, key]))
    xi_set = set(xi)
    pos = lookup["position"].to_dict()
    bench_gk = next((i for i in o.squad_after if i not in xi_set and pos[i] == "GKP"), None)
    bench = [i for i in o.bench_order if i not in xi_set and pos[i] != "GKP"]
    bench += [i for i in o.squad_after if i not in xi_set and i not in bench and pos[i] != "GKP"]
    name = lambda i: str(lookup.loc[i, "web_name"]) if "web_name" in lookup and pd.notna(lookup.loc[i, "web_name"]) else str(i)
    pick = dict(
        transfers=[{"out": m.player_out_id, "out_name": name(m.player_out_id), "in": m.player_in_id, "in_name": name(m.player_in_id)} for m in o.moves],
        n_transfers=o.transfers, hit_points=o.hit_points, free_transfers_before=st["free_transfers"],
        xi=xi, xi_names=[name(i) for i in xi], bench_order=bench, bench_gk=bench_gk,
        bench_names=[name(i) for i in ([bench_gk] if bench_gk else []) + bench],
        captain=cap, captain_name=name(cap), vice=vice, vice_name=name(vice),
        xp_xi=float(sum(float(lookup.loc[i, "xp_next"]) for i in xi) + float(lookup.loc[cap, "xp_next"]) + o.hit_points),
        gross_expected_points=o.gross_expected_points, bank_after=o.bank_after, squad_after=list(o.squad_after),
        positions={str(i): pos[i] for i in o.squad_after}, notes=notes)
    old = {p["code"]: p for p in st["players"]}
    new_players = [old[i] if i in old else {"code": int(i), "position": str(lookup.loc[i, "position"]),
                   "team_code": int(lookup.loc[i, "team_id"]), "current_price": float(lookup.loc[i, "price"]),
                   "purchase_price": float(lookup.loc[i, "price"])} for i in o.squad_after]
    new_state = dict(model=st["model"], next_gw=gw + 1, players=new_players, bank=o.bank_after,
                     free_transfers=free_transfers_after(st["free_transfers"], o.transfers, rules),
                     log=st.get("log", []) + [{"gw": gw, "transfers": o.transfers, "hit": o.hit_points}])
    return pick, new_state
