"""Score a stored decision with real GW points, using the frozen autosubs.py rules (bench auto-subs in
bench order with formation checks, GK-only GK swap, vice-captain fallback), then add hits."""
from __future__ import annotations
import sys
sys.path.insert(0, "/workspace/fpl_dof2_frozen/backtest")
import autosubs as asb


def live_maps(live: dict, elements: list[dict]):
    """event/{n}/live -> (minutes, points) keyed by player code (DGW stats are already summed)."""
    e2c = {e["id"]: e["code"] for e in elements}
    mins, pts = {}, {}
    for el in live["elements"]:
        c = e2c.get(el["id"])
        if c is None:
            continue
        mins[c] = float(el["stats"]["minutes"]); pts[c] = float(el["stats"]["total_points"])
    return mins, pts


def score_pick(pick: dict, minutes: dict, points: dict, multiplier: int = 2) -> dict:
    pos = {int(k): v for k, v in pick["positions"].items()}
    r = asb.score(list(pick["xi"]), list(pick["bench_order"]), pick["bench_gk"], pick["captain"], pick["vice"],
                  pos, minutes, points, multiplier)
    raw_xi = sum(points.get(i, 0.0) for i in pick["xi"])
    return dict(points=r["xi_points_as"] + pick["hit_points"], points_before_hits=r["xi_points_as"],
                hit_points=pick["hit_points"], n_autosubs=r["n_autosubs"], vice_used=r["vice_used"],
                armband_pts=r["armband_pts"], xi_raw_no_subs=raw_xi)
