#!/usr/bin/env python3
"""Score every decisions/GW{n}.json whose GW is finished AND data_checked and is not yet in scores.csv;
append rows; rebuild report.md. Idempotent."""
from __future__ import annotations
import csv, json, sys
sys.path.insert(0, "/workspace/fpl_prospective/prospective")
import numpy as np
import pandas as pd
from common import DECISIONS, REPORT, SCORES, fpl, now_utc, RAW
from models import CHAMPION, MODELS
from scoring import live_maps, score_pick

FIELDS = ["gw", "model", "points", "points_before_hits", "hit_points", "n_transfers", "n_autosubs", "vice_used",
          "armband_pts", "xi_raw_no_subs", "captain", "captain_name", "xp_xi", "scored_at", "decision_sha"]


def scored():
    if not SCORES.exists():
        return set()
    return {(int(r["gw"]), r["model"]) for r in csv.DictReader(open(SCORES))}


def boot(x, n=5000, seed=0):
    x = np.asarray(x, float); rng = np.random.default_rng(seed)
    m = rng.choice(x, size=(n, len(x)), replace=True).mean(1)
    return float(np.quantile(m, .025)), float(np.quantile(m, .975))


def report():
    if not SCORES.exists():
        REPORT.write_text("# Prospective scoring 2026/27\n\nNo scored GWs yet.\n"); return
    s = pd.read_csv(SCORES)
    w = s.pivot_table(index="gw", columns="model", values="points", aggfunc="first").sort_index()
    order = [m for m in MODELS if m in w.columns]
    w = w[order]
    L = ["# Prospective scoring 2026/27 (frozen models)", "",
         f"Updated {now_utc().isoformat()}. Points = final XI after auto-subs + armband (vice fallback) + hits. Champion: {CHAMPION}.", "",
         "## Per GW", "", "| GW | " + " | ".join(order) + " |", "|---|" + "---|" * len(order)]
    for gw, r in w.iterrows():
        L.append(f"| {gw} | " + " | ".join("" if pd.isna(r[m]) else f"{r[m]:.0f}" for m in order) + " |")
    c = w.cumsum()
    L.append("| **cum** | " + " | ".join(f"**{c[m].iloc[-1]:.0f}**" for m in order) + " |")
    L += ["", f"## Paired deltas vs {CHAMPION} (per GW)", "", "| model | n GWs | mean Δ | 95% GW-bootstrap CI | cum Δ |", "|---|---|---|---|---|"]
    for m in order:
        if m == CHAMPION or CHAMPION not in w:
            continue
        d = (w[m] - w[CHAMPION]).dropna()
        ci = "n<5, not reported" if len(d) < 5 else "[{:+.2f}, {:+.2f}]".format(*boot(d))
        L.append(f"| {m} | {len(d)} | {d.mean():+.2f} | {ci} | {d.sum():+.0f} |" if len(d) else f"| {m} | 0 | | | |")
    L += ["", "Note: GWs are not independent and n is small; CIs are descriptive, not a decision rule."]
    REPORT.write_text("\n".join(L) + "\n")


def main():
    bs = fpl("bootstrap-static/")
    ev = {e["id"]: e for e in bs["events"]}
    done = scored(); new = 0
    for p in sorted(DECISIONS.glob("GW*.json"), key=lambda p: int(p.stem[2:])):
        gw = int(p.stem[2:]); e = ev.get(gw)
        if not (e and e["finished"] and e["data_checked"]):
            continue
        todo = [m for m in json.loads(p.read_text())["models"] if (gw, m) not in done]
        if not todo:
            continue
        dec = json.loads(p.read_text())
        live = fpl(f"event/{gw}/live/")
        (RAW / f"live_GW{gw}.json").write_text(json.dumps(live))
        mins, pts = live_maps(live, bs["elements"])
        import hashlib
        dsha = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
        first = not SCORES.exists()
        with open(SCORES, "a", newline="") as f:
            wr = csv.DictWriter(f, FIELDS)
            if first:
                wr.writeheader()
            for m in todo:
                pk = dec["models"][m]; r = score_pick(pk, mins, pts)
                wr.writerow(dict(gw=gw, model=m, n_transfers=pk["n_transfers"], captain=pk["captain"], captain_name=pk["captain_name"],
                                 xp_xi=round(pk["xp_xi"], 2), scored_at=now_utc().isoformat(), decision_sha=dsha, **r))
                new += 1
        print(f"score: GW{gw} scored for {len(todo)} models")
    report()
    print(f"score: {new} new rows; report at {REPORT}")


if __name__ == "__main__":
    main()
