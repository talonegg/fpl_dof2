#!/usr/bin/env python3
"""Exit non-zero (and print every difference) if anything recorded in manifest.json has changed."""
import json, sys; sys.path.insert(0, "/workspace/fpl_prospective/prospective")
from common import MANIFEST, canon, sha256_bytes
from freeze_lib import compute, git


def diff(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            out += diff(a.get(k), b.get(k), f"{path}/{k}")
        return out
    return [] if a == b else [f"{path}: frozen={str(a)[:70]} now={str(b)[:70]}"]


def main() -> int:
    if not MANIFEST.exists():
        print("VERIFY FAIL: no manifest.json"); return 2
    m = json.loads(MANIFEST.read_text())
    body = {k: v for k, v in m.items() if k not in ("frozen_at", "manifest_body_sha256")}
    errs = []
    if sha256_bytes(canon(body)) != m.get("manifest_body_sha256"):
        errs.append("manifest.json itself was edited")
    head = git("rev-parse", "HEAD")
    if head != m["code_commit"]:
        errs.append(f"frozen worktree HEAD {head[:10]} != frozen commit {m['code_commit'][:10]}")
    if git("status", "--porcelain", "--untracked-files=no"):
        errs.append("frozen worktree has uncommitted tracked changes")
    errs += diff(body, compute())
    if errs:
        print("VERIFY FAIL:"); [print("  " + e) for e in errs]; return 1
    print(f"verify ok: {len(m['models'])} models, commit {m['code_commit'][:10]}"); return 0


if __name__ == "__main__":
    sys.exit(main())
