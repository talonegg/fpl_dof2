# Prospective scoring 2026/27 (frozen models)

Updated 2026-10-22T22:02:55.616941+00:00. Points = final XI after auto-subs + armband (vice fallback) + hits. Champion: C3.

## Per GW

| GW | engine | C3 | C1 | A | A_odds |
|---|---|---|---|---|---|
| 7 | 59 | 59 | 65 | 59 | 63 |
| **cum** | **59** | **59** | **65** | **59** | **63** |

## Paired deltas vs C3 (per GW)

| model | n GWs | mean Δ | 95% GW-bootstrap CI | cum Δ |
|---|---|---|---|---|
| engine | 1 | +0.00 | n<5, not reported | +0 |
| C1 | 1 | +6.00 | n<5, not reported | +6 |
| A | 1 | +0.00 | n<5, not reported | +0 |
| A_odds | 1 | +4.00 | n<5, not reported | +4 |

Note: GWs are not independent and n is small; CIs are descriptive, not a decision rule.
